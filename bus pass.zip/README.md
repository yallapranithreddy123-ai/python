# Bus Pass Expiry Tracker

**Never Miss Your Bus Pass Renewal.**

*GreenFuture Hack | Project #53 — Domain: Travel & Transport*

## Project Introduction

**Bus Pass Expiry Tracker** is a local-first Python application designed for campuses, transit coordinators, and daily commuters to register bus passes, validate records defensively, track upcoming expiry dates automatically, monitor overdue passes, and generate analytical summaries and audit reports.

Python serves as the central backend engine for all business logic, date calculations, input validation, SQLite database persistence, CSV/JSON interoperability, search pagination, analytics, and report generation.

## Problem Statement

Manual tracking of bus passes across spreadsheets or paper logs frequently results in:
- Miscalculated expiry dates and missed renewals.
- Misplaced or duplicated pass records.
- Silent data corruption or overwritten files.
- Slow manual filtering when pass counts grow.

## Key Features

- **Primary Web Application & Modern Dashboard**: Executive KPIs, threshold warning indicators, upcoming expiry notifications, recent additions, status distribution, and 6-month expiry trend charts.
- **Secondary Interactive Terminal CLI (`cli.py`)**: Menu-driven 10-option console interface with ANSI formatting and paginated fixed-width tables sharing the exact same Python services and SQLite database.
- **SQLite Primary Persistence + CSV/JSON Sync**: Automatic WAL-mode SQLite database (`data/bus_pass_tracker.db`) with schema migrations, paired with atomic `.csv` and `.json` synchronization and `.bak` recovery backups.
- **Defensive Server-Side Validation**: Rejects blank fields, malformed dates, leap-year errors, inverted issue/expiry dates, invalid mobile numbers, negative fees, and duplicate Pass IDs.
- **Intelligent Expiry Monitor**: Configurable warning threshold (default 7 days) classifying passes into `Active`, `Expiring Soon`, `Expires Today`, and `Expired`, sorted by nearest deadline.
- **Database-Level Pagination & Multi-Criteria Search**: Indexed `LIMIT`/`OFFSET` queries combining keyword, category, status, and date-range filters.
- **Bulk CSV/JSON Import with Row-Level Diagnostics**: Validates headers and every row individually, reporting exact line numbers and failure reasons without silently discarding invalid rows.
- **Multi-Format Export & Reporting**: Downloadable CSV, schema-versioned JSON, structured Markdown reports, status-enriched CSV reports, and plain-text audit logs.
- **Verified Backup & Corruption Recovery**: Integrity-checked SQLite online backups (`backups/`), pre-restore safety snapshots, and automatic quarantine/recovery for damaged files.
- **OpenAPI 3.0 Documentation**: Interactive API reference accessible at `/docs` and `/openapi.json`.

## Technology Stack

- **Backend**: Python 3.10+ (`sqlite3`, `datetime`, `csv`, `json`, `collections`, `re`, `dataclasses`, `pathlib`, `hmac`, `hashlib`), Flask / Python `ThreadingHTTPServer` fallback.
- **Frontend**: HTML5, CSS3 / Tailwind CSS, TypeScript / React SPA communicating with Python `/api/*` via Fetch API.
- **Testing**: `unittest` & `pytest` + `pytest-cov`.

## Project Directory Structure

```text
bus_pass_expiry_tracker/
├── app.py                     # Python Flask / ThreadingHTTPServer entry point
├── cli.py                     # Interactive 10-option Python CLI
├── config.py                  # Immutable AppConfig & directory paths
├── requirements.txt           # Required & optional Python packages
├── server.ts                  # Node/Express proxy & Vite frontend host (port 3000)
├── backend/
│   ├── models.py              # BusPass, AppSettings, AuditLogEntry dataclasses
│   ├── validation.py          # Centralized defensive field & schema validation
│   ├── expiry.py              # Pure Python datetime expiry engine
│   ├── database.py            # SQLite WAL manager & versioned schema migrations
│   ├── repository.py          # Parameterized CRUD & LIMIT/OFFSET pagination
│   ├── storage.py             # Atomic CSV/JSON writes, .bak & corruption recovery
│   ├── search.py              # Indexed multi-criteria search service
│   ├── analytics.py           # KPI summary, trends & optional Matplotlib charts
│   ├── reports.py             # Markdown, CSV, and plain-text audit generators
│   ├── import_export.py       # Bulk CSV/JSON import diagnostics & exports
│   ├── backup.py              # Verified SQLite backup & restoration
│   ├── security.py            # ensure_confined_path, CSRF HMAC, upload validation
│   ├── seed.py                # 40-record relative-date sample dataset & 10k generator
│   ├── openapi.py             # OpenAPI 3.0.3 spec & interactive /docs UI
│   ├── api_router.py          # Framework-agnostic HTTP API router
│   └── services.py            # ApplicationContainer & BusPassService facade
├── sample_data/
│   ├── sample_bus_passes.csv  # 40 realistic relative-date test records
│   └── sample_bus_passes.json # Matching JSON sample dataset
├── tests/                     # Unit, integration, concurrency, API, security & CLI tests
└── .github/workflows/         # GitHub Actions CI pipeline
```

## Setup & Execution Instructions

### Windows Setup (Python Standalone)

1. Create virtual environment:
   ```bat
   python -m venv venv
   ```
2. Activate virtual environment:
   ```bat
   venv\Scripts\activate
   ```
3. Install dependencies:
   ```bat
   pip install -r requirements.txt
   ```
4. Start the Python web server:
   ```bat
   python app.py
   ```
5. Or start the interactive terminal interface:
   ```bat
   python cli.py
   ```

### Linux / macOS Setup

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 app.py --host 127.0.0.1 --port 5000
```

### Full-Stack Web UI Development (Port 3000)

```bash
npm install
npm run dev
```

## Running Tests

Using Python standard library (`unittest`):
```bash
python3 -m unittest discover -s tests -v
```

Using `pytest` with coverage:
```bash
pytest --cov=backend --cov-report=term-missing tests/
```

## Demonstration Workflow

1. Launch the web application and open the Dashboard to inspect real-time metrics and active threshold warnings.
2. Open **Add New Pass**, submit blank fields or an expiry date earlier than the issue date to observe Python server-side field validation, then submit a valid pass.
3. Visit **Expiry Monitor** and **Analytics & Reports** to inspect deadline buckets, monthly trends, and category breakdowns.
4. Restart the application and confirm the newly created pass persists in `data/bus_pass_tracker.db`, `data/bus_passes.csv`, and `data/bus_passes.json`.
5. Export a Markdown report or run `python cli.py` to manage the exact same dataset from the terminal.
