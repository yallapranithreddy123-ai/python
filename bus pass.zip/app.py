"""Primary Python web server entry point for Bus Pass Expiry Tracker.

Uses Flask when installed (local venv via requirements.txt) and seamlessly falls back
to Python's built-in ThreadingHTTPServer when running in a standard-library-only runtime.
Both modes execute the exact same ApiRouter and Three-Tier Python backend.
"""

from __future__ import annotations

import argparse
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from backend.api_router import ApiRouter
from backend.services import ApplicationContainer
from config import AppConfig


def create_app(config: Optional[AppConfig] = None, enforce_csrf: bool = True):
    """Create a Flask application if Flask is installed, else return (container, router)."""
    container = ApplicationContainer(config=config)
    router = ApiRouter(container, enforce_csrf=enforce_csrf)

    try:
        from flask import Flask, Response, request, send_from_directory
    except ImportError:
        return container, router

    dist_dir = Path(__file__).resolve().parent / "dist"
    app = Flask(__name__, static_folder=str(dist_dir) if dist_dir.exists() else None)
    app.config["MAX_CONTENT_LENGTH"] = container.config.max_upload_bytes

    @app.route("/api/<path:subpath>", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
    @app.route("/openapi.json", methods=["GET"])
    @app.route("/docs", methods=["GET"])
    def dispatch_api(subpath: str = ""):
        res = router.handle(
            method=request.method,
            raw_path=request.path,
            query_string=request.query_string.decode("utf-8", errors="replace"),
            headers=dict(request.headers),
            raw_body=request.get_data(),
        )
        return Response(res.body, status=res.status_code, content_type=res.content_type, headers=res.headers or {})

    @app.route("/", defaults={"path": ""})
    @app.route("/<path:path>")
    def serve_frontend(path: str):
        if dist_dir.exists():
            candidate = dist_dir / path
            if path and candidate.is_file():
                return send_from_directory(str(dist_dir), path)
            return send_from_directory(str(dist_dir), "index.html")
        # Direct standalone fallback redirects browser users to API explorer if frontend hasn't been built
        res = router.handle("GET", "/docs", "", {}, b"")
        return Response(res.body, status=res.status_code, content_type=res.content_type, headers=res.headers or {})

    app.extensions["container"] = container
    app.extensions["router"] = router
    return app


def run_stdlib_server(host: str, port: int, container: ApplicationContainer, router: ApiRouter) -> None:
    """Serve the API and built static assets using Python's built-in ThreadingHTTPServer."""
    dist_dir = Path(__file__).resolve().parent / "dist"

    class TrackerHandler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, format: str, *args) -> None:
            # Keep stdout clean; errors still surface via stderr
            return

        def _dispatch(self) -> None:
            parsed = urlparse(self.path)
            length = int(self.headers.get("Content-Length", "0") or "0")
            if length > container.config.max_upload_bytes:
                self.send_response(413)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                body = b'{"error": "Payload exceeds maximum upload limit.", "code": 413}'
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            raw_body = self.rfile.read(length) if length > 0 else b""
            if (
                parsed.path.startswith("/api/")
                or parsed.path in {"/openapi.json", "/docs"}
            ):
                res = router.handle(
                    method=self.command,
                    raw_path=parsed.path,
                    query_string=parsed.query,
                    headers={k: v for k, v in self.headers.items()},
                    raw_body=raw_body,
                )
                self.send_response(res.status_code)
                self.send_header("Content-Type", res.content_type)
                self.send_header("Content-Length", str(len(res.body)))
                if res.headers:
                    for hk, hv in res.headers.items():
                        self.send_header(hk, hv)
                self.end_headers()
                self.wfile.write(res.body)
                return

            # Serve built SPA if available
            if dist_dir.exists():
                rel = parsed.path.lstrip("/") or "index.html"
                target = (dist_dir / rel).resolve()
                if not str(target).startswith(str(dist_dir.resolve())) or not target.is_file():
                    target = dist_dir / "index.html"
                content = target.read_bytes()
                ctype = "text/html; charset=utf-8"
                if target.suffix == ".js":
                    ctype = "application/javascript; charset=utf-8"
                elif target.suffix == ".css":
                    ctype = "text/css; charset=utf-8"
                elif target.suffix == ".svg":
                    ctype = "image/svg+xml"
                elif target.suffix == ".json":
                    ctype = "application/json"
                self.send_response(200)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return

            # Fallback to API explorer
            res = router.handle("GET", "/docs", "", {}, b"")
            self.send_response(res.status_code)
            self.send_header("Content-Type", res.content_type)
            self.send_header("Content-Length", str(len(res.body)))
            self.end_headers()
            self.wfile.write(res.body)

        def do_GET(self) -> None:
            self._dispatch()

        def do_POST(self) -> None:
            self._dispatch()

        def do_PUT(self) -> None:
            self._dispatch()

        def do_DELETE(self) -> None:
            self._dispatch()

    server = ThreadingHTTPServer((host, port), TrackerHandler)
    print(f"Bus Pass Expiry Tracker Python backend listening on http://{host}:{port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Bus Pass Expiry Tracker Web Backend")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    args = parser.parse_args()

    result = create_app()
    if isinstance(result, tuple):
        container, router = result
        run_stdlib_server(args.host, args.port, container, router)
    else:
        print(f"Bus Pass Expiry Tracker Flask server listening on http://{args.host}:{args.port}", flush=True)
        result.run(host=args.host, port=args.port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
