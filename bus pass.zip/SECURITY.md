# Security Architecture & Safeguards

Bus Pass Expiry Tracker is designed for local execution and college hackathon demonstration with practical defensive safeguards across every input and file boundary.

## Implemented Controls

1. **Centralized Server-Side Validation (`backend/validation.py`)**: All user inputs, API JSON payloads, settings, and imported CSV/JSON rows pass through strict type, regex, calendar date, and boundary validation before reaching SQLite.
2. **Parameterized SQL Queries (`backend/repository.py`)**: Every SQLite query uses `?` parameter bindings; sort columns are strictly allowlisted (`ALLOWED_SORT_COLUMNS`).
3. **CSRF Protection (`backend/security.py`, `backend/api_router.py`)**: State-changing endpoints (`POST`, `PUT`, `DELETE`) verify a stateless HMAC-SHA256 `X-CSRF-Token` signed with `BUS_PASS_SECRET_KEY` (or a runtime 256-bit `secrets.token_hex(32)` fallback).
4. **Path Confinement (`ensure_confined_path`)**: File paths for backups, exports, and CLI imports are normalized with `Path.resolve()` and verified against the approved base directory boundary to prevent directory traversal.
5. **Upload Validation (`validate_upload_payload`)**: Enforces filename sanitization (`sanitize_filename`), `.csv`/`.json` extension allowlisting, 5 MB maximum payload cap, binary null-byte rejection, and UTF-8 decoding.
6. **Atomic File Operations & Corruption Recovery (`backend/storage.py`, `backend/backup.py`)**: Writes occur via temp files + `os.fsync()` + `os.replace()`, preserving `.bak` copies. Damaged files are quarantined with `.corrupted.<timestamp>` rather than silently overwritten.
7. **HTTP Security Headers**: API responses include `X-Content-Type-Options: nosniff`, `Referrer-Policy`, `Permissions-Policy`, and `Cache-Control: no-store`.
8. **Safe Error Handling**: Unexpected exceptions sanitize internal directory paths via `safe_error_message()` before returning JSON error envelopes.
