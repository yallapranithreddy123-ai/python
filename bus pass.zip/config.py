"""Central configuration for the Bus Pass Expiry Tracker application."""

from __future__ import annotations

import os
import secrets
from dataclasses import dataclass
from pathlib import Path


BASE_DIR: Path = Path(__file__).resolve().parent


@dataclass(frozen=True)
class AppConfig:
    """Immutable application configuration resolved from environment variables."""

    base_dir: Path = BASE_DIR
    data_dir: Path = BASE_DIR / "data"
    backup_dir: Path = BASE_DIR / "backups"
    exports_dir: Path = BASE_DIR / "exports"
    sample_data_dir: Path = BASE_DIR / "sample_data"
    db_path: Path = BASE_DIR / "data" / "bus_pass_tracker.db"
    json_path: Path = BASE_DIR / "data" / "bus_passes.json"
    csv_path: Path = BASE_DIR / "data" / "bus_passes.csv"
    audit_log_path: Path = BASE_DIR / "data" / "audit.log"

    default_warning_days: int = int(os.environ.get("EXPIRY_WARNING_DAYS", "7") or "7")
    default_page_size: int = 15
    max_page_size: int = 100
    max_upload_bytes: int = 5 * 1024 * 1024  # 5 MB CSV/JSON upload cap
    sqlite_busy_timeout_ms: int = 5000

    secret_key: str = os.environ.get("BUS_PASS_SECRET_KEY") or secrets.token_hex(32)
    app_name: str = "Bus Pass Expiry Tracker"
    app_tagline: str = "Never Miss Your Bus Pass Renewal."
    app_version: str = "2.0.0"

    @classmethod
    def for_directory(cls, root_dir: Path) -> "AppConfig":
        """Create an isolated configuration rooted at a custom or temporary directory."""
        root = Path(root_dir).resolve()
        return cls(
            base_dir=root,
            data_dir=root / "data",
            backup_dir=root / "backups",
            exports_dir=root / "exports",
            sample_data_dir=BASE_DIR / "sample_data",
            db_path=root / "data" / "bus_pass_tracker.db",
            json_path=root / "data" / "bus_passes.json",
            csv_path=root / "data" / "bus_passes.csv",
            audit_log_path=root / "data" / "audit.log",
        )

    def ensure_directories(self) -> None:
        """Create required application storage directories if they do not exist."""
        for directory in (self.data_dir, self.backup_dir, self.exports_dir):
            directory.mkdir(parents=True, exist_ok=True)
