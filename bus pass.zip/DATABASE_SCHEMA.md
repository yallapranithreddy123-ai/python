# Database Schema & Migration Guide

## Primary Database

- **Engine**: SQLite 3 (`sqlite3` Python standard library)
- **File Path**: `data/bus_pass_tracker.db`
- **Concurrency Settings**:
  - `PRAGMA journal_mode = WAL;`
  - `PRAGMA busy_timeout = 5000;`
  - `PRAGMA foreign_keys = ON;`
  - Short-lived connections bound to each HTTP request or service call; explicit `BEGIN IMMEDIATE` transactions.

## Entity Relationship Diagram

```text
+-----------------------------------+       +-----------------------------------+
|            bus_passes             |       |            audit_logs             |
+-----------------------------------+       +-----------------------------------+
| PK id             INTEGER         |       | PK id             INTEGER         |
| UQ pass_id        TEXT NOT NULL   |       |    action         TEXT NOT NULL   |
|    holder_name    TEXT NOT NULL   |       |    entity_type    TEXT NOT NULL   |
|    mobile_number  TEXT NOT NULL   |       |    entity_id      TEXT NOT NULL   |
|    route          TEXT NOT NULL   |       |    description    TEXT NOT NULL   |
|    category       TEXT NOT NULL   |       |    timestamp      TEXT NOT NULL   |
|    issue_date     TEXT NOT NULL   |       +-----------------------------------+
|    expiry_date    TEXT NOT NULL   |
|    fee            REAL NOT NULL   |       +-----------------------------------+
|    notes          TEXT NOT NULL   |       |       application_settings        |
|    created_at     TEXT NOT NULL   |       +-----------------------------------+
|    updated_at     TEXT NOT NULL   |       | PK id (CHECK=1)   INTEGER         |
+-----------------------------------+       |    expiry_warning_days INTEGER    |
                                            |    storage_sync_mode   TEXT       |
+-----------------------------------+       |    default_page_size   INTEGER    |
|        schema_migrations          |       |    updated_at          TEXT       |
+-----------------------------------+       +-----------------------------------+
| PK version        INTEGER         |
|    name           TEXT NOT NULL   |
|    applied_at     TEXT NOT NULL   |
+-----------------------------------+
```

## Indexes

- `idx_bus_passes_pass_id` on `bus_passes(pass_id)`
- `idx_bus_passes_holder_name` on `bus_passes(holder_name)`
- `idx_bus_passes_route` on `bus_passes(route)`
- `idx_bus_passes_category` on `bus_passes(category)`
- `idx_bus_passes_expiry_date` on `bus_passes(expiry_date)`
- `idx_bus_passes_mobile` on `bus_passes(mobile_number)`
- `idx_bus_passes_created_at` on `bus_passes(created_at DESC)`
- `idx_bus_passes_cat_expiry` on `bus_passes(category, expiry_date)`
- `idx_audit_logs_timestamp` on `audit_logs(timestamp DESC)`
- `idx_audit_logs_entity` on `audit_logs(entity_type, entity_id)`

## Schema Migration Procedure

1. Add a new migration function `(version_int, "description", fn)` to `MIGRATIONS` in `backend/database.py`.
2. Execute DDL statements via `conn.execute(...)` inside the migration function (avoid `executescript`, which commits implicitly).
3. On application startup, `DatabaseManager.initialize()` inspects `schema_migrations` inside an atomic `BEGIN IMMEDIATE` transaction, runs unapplied migrations in ascending version order, and records their timestamps.

## Backup & Restoration Procedure

- **Backup**: `BackupService.create_backup()` uses SQLite's online `Connection.backup()` API into a temporary file, verifies `PRAGMA integrity_check` and required tables, and atomically moves the verified snapshot into `backups/`.
- **Restore**: `BackupService.restore_backup(filename)` verifies path confinement (`ensure_confined_path`), validates backup integrity, creates a `pre_restore_*.db` safety backup of the current live database, restores via `Connection.backup()`, and re-syncs CSV/JSON files.
