# Automated Testing & Coverage Guide

## Test Suite Architecture

All tests run against isolated temporary directories (`tempfile.TemporaryDirectory`) so production records in `data/` are never modified.

| Test Module | Scope |
| --- | --- |
| `tests/test_validation.py` | Blank inputs, regex checks, leap-year dates, inverted ranges, fee bounds, `ensure_confined_path`, upload checks, HMAC CSRF |
| `tests/test_expiry_and_analytics.py` | Boundary days (`-1, 0, 1, 7, 8`), year/month rollovers, leap-year math, configurable thresholds, real analytics, Markdown/TXT/CSV reports |
| `tests/test_database_and_concurrency.py` | CRUD, persistence across restarts, SQLite transaction rollback, 8-thread concurrent uniqueness race test, 10,000-record pagination |
| `tests/test_import_export_and_backup.py` | Bulk CSV row-by-row error diagnostics, JSON/CSV corruption quarantine & rebuild, SQLite online backup/restore & DB corruption recovery |
| `tests/test_api_and_security.py` | HTTP status codes (`200, 201, 403, 404, 409, 422`), multipart CSV upload, OpenAPI `/docs` & `/openapi.json`, report downloads |
| `tests/test_cli_and_persistence.py` | Interactive terminal CLI workflows including retry loops on invalid inputs, summary, search, and SQLite persistence |
| `src/utils/formatters.test.ts` | TypeScript unit tests (`node:test`) for UI display formatters and query builders |

## Running Tests Locally

### Python Standard Library (`unittest`)
```bash
python3 -m unittest discover -s tests -v
```

### Pytest with Coverage Gate (>=90%)
```bash
pytest --cov=backend --cov-report=term-missing --cov-fail-under=90 tests/
```

### TypeScript Formatter Tests
```bash
npx --yes tsx --test src/utils/formatters.test.ts
```
