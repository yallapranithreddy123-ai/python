# User Guide — Bus Pass Expiry Tracker

## 1. Dashboard Overview
Open the application to view:
- **KPI Summary Cards**: Total registered passes, active passes, expiring soon (within your configured threshold), expires today, and already expired passes.
- **Threshold Warning Indicators**: Automatic alerts highlighting passes expiring today, upcoming renewals, high expired ratios, or zero-fee entries.
- **Visualizations**: Real-time Status Distribution and 6-Month Rolling Expiry Trend charts.

## 2. Registering a New Bus Pass
1. Click **Add New Pass** in the sidebar or top header.
2. Complete all required fields (`Pass ID`, `Holder Full Name`, `Mobile Number`, `Bus Route`, `Pass Category`, `Issue Date`, `Expiry Date`). Optionally add `Pass Fee` and `Notes`.
3. Click **Register Bus Pass**. Any invalid inputs (blank fields, invalid mobile format, inverted expiry date, or duplicate Pass ID) are caught by Python validation with inline field-level messages.

## 3. Managing, Searching & Monitoring Passes
- **All Bus Passes**: Browse paginated records, sort by expiry date or name, and click the View or Edit icons to inspect, update, or delete (with confirmation) any pass.
- **Expiry Monitor**: Switch between *All Upcoming Alerts*, *Expires Today*, *Within N Days*, *Expired*, and *Future Active* queues sorted by nearest renewal deadline.
- **Search Records**: Combine keyword search (Pass ID, name, mobile, route) with category, status, and expiry date-range filters.

## 4. Bulk Import, Exports & Reports
- **Import / Export**: Upload `.csv` or `.json` files to bulk-import passes. Valid rows are saved atomically while invalid or duplicate rows appear in the row-by-row diagnostic table.
- **Downloads**: Export raw CSV/JSON backups or generate Executive Markdown Reports, Status-Enriched CSV Reports, and Plain-Text Audit Logs.

## 5. Settings, Backups & CLI Mode
- **Settings & Data**: Adjust the expiry warning threshold (1–90 days), choose CSV/JSON sync mode, create verified SQLite backups, restore from verified backups, or open the **OpenAPI Reference** (`/docs`).
- **Terminal CLI**: Run `python cli.py` to access the 10-option menu-driven terminal console backed by the exact same SQLite database.
