# System Architecture

## Three-Tier Design

Bus Pass Expiry Tracker is engineered using a strict **Three-Tier Architecture** so both the Web API (`app.py`) and Terminal CLI (`cli.py`) share identical business rules without code duplication.

```text
+-------------------------------------------------------------------------+
|                          PRESENTATION LAYER                             |
|   React + Tailwind Web UI (src/)   |   Interactive Terminal CLI (cli.py)|
|   Flask / Stdlib HTTP (app.py)     |   OpenAPI Explorer (/docs)         |
+------------------------------------+------------------------------------+
                                     |
                                     v
+-------------------------------------------------------------------------+
|                         BUSINESS LOGIC LAYER                            |
|   BusPassService (services.py)     |   ValidationService (validation.py)|
|   ExpiryService (expiry.py)        |   AnalyticsService (analytics.py)  |
|   SearchService (search.py)        |   ReportService (reports.py)       |
|   ImportExportService              |   BackupService (backup.py)        |
+------------------------------------+------------------------------------+
                                     |
                                     v
+-------------------------------------------------------------------------+
|                           DATA ACCESS LAYER                             |
|   DatabaseManager (database.py)    |   BusPassRepository (repository.py)|
|   SettingsRepository               |   AuditLogRepository               |
|   FilePersistenceService (storage.py — atomic CSV/JSON + .bak sync)     |
+------------------------------------+------------------------------------+
                                     |
                                     v
      [ data/bus_pass_tracker.db (SQLite WAL) ]  +  [ bus_passes.csv/json ]
```

## Storage Design Decision: SQLite Primary + CSV/JSON Interoperability

- **Why SQLite is Primary**: Flat CSV/JSON files require full-file rewrites on every edit, lack concurrent transaction locking, and degrade linearly as records scale. SQLite provides ACID transactions, unique `pass_id` enforcement under concurrent threads, indexed `LIMIT`/`OFFSET` pagination across 10,000+ rows, and `PRAGMA integrity_check`.
- **Why CSV & JSON Remain Supported**: The GreenFuture Hack #53 specification mandates CSV and JSON support for portability and human inspection. After every validated write or bulk import, `FilePersistenceService` atomically synchronizes `data/bus_passes.csv` and `data/bus_passes.json` via temporary files + `os.fsync()` + `os.replace()`, preserving `.bak` copies before replacement.

## Request & Application Workflow

```text
User Input (Web Form / CSV Upload / CLI Prompt)
   │
   ▼
[ Security Guard ] -> CSRF Token Verification (HMAC-SHA256) + Path Confinement
   │
   ▼
[ ValidationService ] -> Type checks, regex, calendar date & range checks
   │
   ▼
[ BusPassRepository ] -> BEGIN IMMEDIATE SQLite Transaction (Parameterized SQL)
   │
   ├──► [ FilePersistenceService ] -> Atomic temp-file write to CSV & JSON
   ├──► [ AuditLogRepository ]     -> Timestamped operation log (no PII)
   └──► [ ExpiryService ]          -> Compute days_remaining, status & urgency
```
