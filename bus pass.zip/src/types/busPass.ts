export type PassStatus = 'Active' | 'Expiring Soon' | 'Expires Today' | 'Expired';

export interface BusPass {
  id?: number;
  pass_id: string;
  holder_name: string;
  mobile_number: string;
  route: string;
  category: string;
  issue_date: string;
  expiry_date: string;
  fee: number;
  notes: string;
  created_at?: string;
  updated_at?: string;
  days_remaining: number;
  status: PassStatus;
  urgency: string;
  renewal_deadline: string;
}

export interface BusPassPayload {
  pass_id: string;
  holder_name: string;
  mobile_number: string;
  route: string;
  category: string;
  issue_date: string;
  expiry_date: string;
  fee: number | string;
  notes: string;
}

export interface PaginationResponse {
  items: BusPass[];
  total_count: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface DashboardWarning {
  severity: 'critical' | 'warning' | 'danger' | 'info';
  code: string;
  title: string;
  message: string;
}

export interface StatusDistributionItem {
  status: PassStatus;
  count: number;
}

export interface MonthlyTrendItem {
  month: string;
  label: string;
  count: number;
  expired: number;
  upcoming: number;
}

export interface CategoryDistributionItem {
  category: string;
  count: number;
  active_or_pending: number;
  expired: number;
  total_fee: number;
  avg_fee: number;
}

export interface RouteDistributionItem {
  route: string;
  count: number;
  expired: number;
  active_or_pending: number;
}

export interface DashboardSummary {
  current_date: string;
  generated_at: string;
  warning_days: number;
  storage_sync_mode: string;
  kpis: {
    total_passes: number;
    total_stored: number;
    active_passes: number;
    expiring_soon: number;
    expires_today: number;
    expired_passes: number;
    avg_remaining_days_active: number;
    avg_remaining_days_all: number;
    total_fee_collected: number;
    average_fee: number;
  };
  status_distribution: StatusDistributionItem[];
  monthly_expiry_trend: MonthlyTrendItem[];
  upcoming_notifications: BusPass[];
  recent_additions: BusPass[];
  warnings: DashboardWarning[];
}

export interface AnalyticsData extends DashboardSummary {
  active_vs_expired: {
    active_and_valid: number;
    expired: number;
  };
  category_distribution: CategoryDistributionItem[];
  route_distribution: RouteDistributionItem[];
  matplotlib_available: boolean;
}

export interface ExpiryMonitorData {
  warning_days: number;
  counts: {
    expires_today: number;
    expiring_soon: number;
    expired: number;
    future: number;
  };
  expires_today: BusPass[];
  expiring_soon: BusPass[];
  expired: BusPass[];
  future: BusPass[];
}

export interface ImportRowError {
  row_number: number;
  pass_id: string;
  errors: string[];
}

export interface ImportResult {
  total_rows: number;
  imported_count: number;
  failed_count: number;
  skipped_duplicates: number;
  row_errors: ImportRowError[];
  imported_pass_ids: string[];
}

export interface AppSettings {
  expiry_warning_days: number;
  storage_sync_mode: string;
  default_page_size: number;
  updated_at: string;
}

export interface BackupEntry {
  filename: string;
  size_bytes: number;
  modified_at: string;
}

export interface AuditLogEntry {
  id: number;
  action: string;
  entity_type: string;
  entity_id: string;
  description: string;
  timestamp: string;
}

export interface HealthResponse {
  status: string;
  app: string;
  version: string;
  database: {
    ok: boolean;
    details: string[];
    schema_version: number;
  };
  total_records: number;
  startup_notes: string[];
}
