import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildSearchQueryString,
  formatBytes,
  formatCurrency,
  formatDaysRemaining,
} from './formatters';

test('formatDaysRemaining renders overdue, today, singular, and plural labels', () => {
  assert.equal(formatDaysRemaining(-5), '5d overdue');
  assert.equal(formatDaysRemaining(0), 'Expires today');
  assert.equal(formatDaysRemaining(1), '1 day left');
  assert.equal(formatDaysRemaining(14), '14 days left');
});

test('formatCurrency formats fixed 2-decimal currency values', () => {
  assert.equal(formatCurrency(450), '450.00');
  assert.equal(formatCurrency(1234.5), '1,234.50');
});

test('formatBytes formats byte sizes cleanly', () => {
  assert.equal(formatBytes(0), '0 B');
  assert.equal(formatBytes(512), '512 B');
  assert.equal(formatBytes(2048), '2.0 KB');
});

test('buildSearchQueryString omits empty and "all" filter values', () => {
  const qs = buildSearchQueryString({
    q: 'Route 101',
    category: 'all',
    status: 'Expiring Soon',
    page: 2,
    empty: '   ',
  });
  assert.equal(qs, 'q=Route+101&status=Expiring+Soon&page=2');
});
