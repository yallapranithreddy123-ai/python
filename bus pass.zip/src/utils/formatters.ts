export function formatDaysRemaining(days: number): string {
  if (days < 0) {
    const overdue = Math.abs(days);
    return `${overdue}d overdue`;
  }
  if (days === 0) {
    return 'Expires today';
  }
  if (days === 1) {
    return '1 day left';
  }
  return `${days} days left`;
}

export function formatCurrency(amount: number): string {
  const safe = Number.isFinite(amount) ? amount : 0;
  return new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(safe);
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) {
    return '0 B';
  }
  if (bytes < 1024) {
    return `${bytes} B`;
  }
  if (bytes < 1024 * 1024) {
    return `${(bytes / 1024).toFixed(1)} KB`;
  }
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function buildSearchQueryString(params: Record<string, string | number | undefined>): string {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null) {
      continue;
    }
    const str = String(value).trim();
    if (str !== '' && str !== 'all') {
      search.set(key, str);
    }
  }
  return search.toString();
}
