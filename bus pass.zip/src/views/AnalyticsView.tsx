import {useState} from 'react';
import {Download, FileText} from 'lucide-react';
import {apiClient} from '../api/client';
import {
  CategoryBreakdownChart,
  MonthlyExpiryTrendChart,
  RouteDistributionList,
  StatusDistributionChart,
} from '../components/Charts';
import type {AnalyticsData} from '../types/busPass';
import {formatCurrency} from '../utils/formatters';

interface AnalyticsViewProps {
  analytics: AnalyticsData | null;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
}

export function AnalyticsView({analytics, loading, error, onRetry}: AnalyticsViewProps) {
  const [downloading, setDownloading] = useState<string | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  const handleDownload = async (endpoint: string, fallback: string, key: string) => {
    setDownloading(key);
    setDownloadError(null);
    try {
      await apiClient.downloadExport(endpoint, fallback);
    } catch (err) {
      setDownloadError(err instanceof Error ? err.message : 'Download failed.');
    } finally {
      setDownloading(null);
    }
  };

  if (loading && !analytics) {
    return (
      <div className="space-y-6">
        <div className="h-24 animate-pulse rounded-lg border border-slate-200 bg-white" />
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="h-64 animate-pulse rounded-lg border border-slate-200 bg-white" />
          <div className="h-64 animate-pulse rounded-lg border border-slate-200 bg-white" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-lg border border-red-200 bg-red-50 p-6">
        <p className="font-semibold text-red-900">Unable to Load Analytics</p>
        <p className="mt-1 text-sm text-red-800">{error}</p>
        <button
          type="button"
          onClick={onRetry}
          className="mt-3 rounded-md bg-red-700 px-4 py-2 text-xs font-medium text-white hover:bg-red-800"
        >
          Retry
        </button>
      </div>
    );
  }

  if (!analytics) {
    return null;
  }

  const {kpis, active_vs_expired} = analytics;

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 rounded-lg border border-slate-200 bg-white p-6 md:flex-row md:items-center">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">Analytics & Executive Reports</h1>
          <p className="text-sm text-slate-600">
            All metrics, averages, and trends are calculated in real time by Python from SQLite records.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            disabled={downloading !== null}
            onClick={() => void handleDownload('/api/reports/markdown', 'bus_pass_report.md', 'md')}
            className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
          >
            <FileText className="h-3.5 w-3.5" aria-hidden="true" />
            {downloading === 'md' ? 'Generating...' : 'Markdown Report'}
          </button>
          <button
            type="button"
            disabled={downloading !== null}
            onClick={() => void handleDownload('/api/reports/csv', 'bus_pass_report.csv', 'csv')}
            className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
          >
            <Download className="h-3.5 w-3.5" aria-hidden="true" />
            {downloading === 'csv' ? 'Generating...' : 'CSV Report'}
          </button>
          <button
            type="button"
            disabled={downloading !== null}
            onClick={() => void handleDownload('/api/reports/audit', 'audit_report.txt', 'txt')}
            className="inline-flex items-center gap-1.5 rounded-md bg-teal-700 px-3.5 py-2 text-xs font-medium text-white hover:bg-teal-800 whitespace-nowrap"
          >
            <Download className="h-3.5 w-3.5" aria-hidden="true" />
            {downloading === 'txt' ? 'Generating...' : 'Audit Log (.txt)'}
          </button>
        </div>
      </div>

      {downloadError && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-800">
          {downloadError}
        </div>
      )}

      {/* Executive Summary Metrics Table */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Valid vs. Expired Ratio</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
            {active_vs_expired.active_and_valid} / {active_vs_expired.expired}
          </p>
          <p className="mt-1 text-xs text-slate-500">Valid/Pending vs. Overdue</p>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Avg Validity (Non-Expired)</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
            {kpis.avg_remaining_days_active} days
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            Overall mean: {kpis.avg_remaining_days_all} days
          </p>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Total Pass Revenue</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
            {formatCurrency(kpis.total_fee_collected)}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            Mean fee: {formatCurrency(kpis.average_fee)}
          </p>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Matplotlib PNG Export</p>
          <p className="mt-2 text-sm font-semibold text-slate-900">
            {analytics.matplotlib_available ? 'Installed & Ready' : 'SVG Fallback Active'}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            {analytics.matplotlib_available
              ? 'Server-side Matplotlib PNG endpoints active'
              : 'Interactive SVG rendered from Python JSON'}
          </p>
        </div>
      </section>

      {/* Primary Charts */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-slate-200 bg-white p-6">
          <h2 className="mb-1 text-base font-semibold text-slate-900">Expiry Status Distribution</h2>
          <p className="mb-4 text-xs text-slate-500">Breakdown across Active, Expiring Soon, Today, and Expired</p>
          <StatusDistributionChart data={analytics.status_distribution} />
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-6">
          <h2 className="mb-1 text-base font-semibold text-slate-900">Monthly Expiry Forecast</h2>
          <p className="mb-4 text-xs text-slate-500">Upcoming versus already-expired pass counts by calendar month</p>
          <MonthlyExpiryTrendChart data={analytics.monthly_expiry_trend} />
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-6">
          <h2 className="mb-1 text-base font-semibold text-slate-900">Pass Category Distribution</h2>
          <p className="mb-4 text-xs text-slate-500">Active/pending versus expired records per pass category</p>
          <CategoryBreakdownChart data={analytics.category_distribution} />
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-6">
          <h2 className="mb-1 text-base font-semibold text-slate-900">Top Transit Routes</h2>
          <p className="mb-4 text-xs text-slate-500">Volume and expiry exposure by bus corridor</p>
          <RouteDistributionList data={analytics.route_distribution} />
        </div>
      </section>

      {/* Category Summary Table */}
      <section className="overflow-hidden rounded-lg border border-slate-200 bg-white">
        <div className="border-b border-slate-200 px-6 py-4">
          <h2 className="text-base font-semibold text-slate-900">Category Financial & Expiry Summary</h2>
        </div>
        {analytics.category_distribution.length === 0 ? (
          <div className="p-6 text-sm text-slate-500">No records stored to summarize.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
              <thead className="bg-slate-50 text-xs font-semibold text-slate-600">
                <tr>
                  <th scope="col" className="px-6 py-3">Category</th>
                  <th scope="col" className="px-6 py-3 text-right">Total Passes</th>
                  <th scope="col" className="px-6 py-3 text-right">Valid / Pending</th>
                  <th scope="col" className="px-6 py-3 text-right">Expired</th>
                  <th scope="col" className="px-6 py-3 text-right">Total Fee</th>
                  <th scope="col" className="px-6 py-3 text-right">Avg Fee</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {analytics.category_distribution.map((row) => (
                  <tr key={row.category}>
                    <td className="px-6 py-3 font-medium text-slate-900">{row.category}</td>
                    <td className="px-6 py-3 text-right font-mono tabular-nums">{row.count}</td>
                    <td className="px-6 py-3 text-right font-mono text-emerald-700 tabular-nums">
                      {row.active_or_pending}
                    </td>
                    <td className="px-6 py-3 text-right font-mono text-red-700 tabular-nums">{row.expired}</td>
                    <td className="px-6 py-3 text-right font-mono tabular-nums">
                      {formatCurrency(row.total_fee)}
                    </td>
                    <td className="px-6 py-3 text-right font-mono tabular-nums">
                      {formatCurrency(row.avg_fee)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
