import {AlertTriangle, ArrowRight, Calendar, PlusCircle} from 'lucide-react';
import {MonthlyExpiryTrendChart, StatusDistributionChart} from '../components/Charts';
import {StatusBadge} from '../components/StatusBadge';
import type {BusPass, DashboardSummary} from '../types/busPass';
import {formatCurrency, formatDaysRemaining} from '../utils/formatters';

interface DashboardViewProps {
  summary: DashboardSummary | null;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  onNavigate: (tab: string) => void;
  onSelectPass: (pass: BusPass) => void;
}

const WARNING_BOX_STYLE: Record<string, string> = {
  critical: 'border-orange-200 bg-orange-50 text-orange-900',
  warning: 'border-amber-200 bg-amber-50 text-amber-900',
  danger: 'border-red-200 bg-red-50 text-red-900',
  info: 'border-slate-200 bg-slate-50 text-slate-800',
};

export function DashboardView({
  summary,
  loading,
  error,
  onRetry,
  onNavigate,
  onSelectPass,
}: DashboardViewProps) {
  if (loading && !summary) {
    return (
      <div className="space-y-6" aria-busy="true" aria-label="Loading dashboard">
        <div className="h-24 animate-pulse rounded-lg border border-slate-200 bg-white" />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {[1, 2, 3, 4, 5].map((idx) => (
            <div key={idx} className="h-28 animate-pulse rounded-lg border border-slate-200 bg-white" />
          ))}
        </div>
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="h-72 animate-pulse rounded-lg border border-slate-200 bg-white" />
          <div className="h-72 animate-pulse rounded-lg border border-slate-200 bg-white" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-lg border border-red-200 bg-red-50 p-6">
        <h2 className="text-base font-semibold text-red-900">Unable to Load Dashboard Summary</h2>
        <p className="mt-1 text-sm text-red-800">{error}</p>
        <button
          type="button"
          onClick={onRetry}
          className="mt-4 rounded-md bg-red-700 px-4 py-2 text-sm font-medium text-white hover:bg-red-800"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  if (!summary) {
    return null;
  }

  const {kpis} = summary;

  return (
    <div className="space-y-8">
      {/* Welcome & Operational Context */}
      <section className="flex flex-col justify-between gap-4 rounded-lg border border-slate-200 bg-white p-6 md:flex-row md:items-center">
        <div className="space-y-1.5">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            <Calendar className="h-3.5 w-3.5 text-teal-700" aria-hidden="true" />
            <span className="font-mono">{summary.current_date}</span>
            <span aria-hidden="true">·</span>
            <span>Warning threshold: {summary.warning_days} days</span>
            <span aria-hidden="true">·</span>
            <span>Sync: {summary.storage_sync_mode}</span>
          </div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900">
            Transit Pass Operations Overview
          </h1>
          <p className="max-w-2xl text-sm text-slate-600">
            Monitor active commuter passes, upcoming renewal deadlines, expired records, and storage consistency powered by the Python SQLite engine.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('expiry-monitor')}
            className="rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
          >
            Open Expiry Monitor
          </button>
          <button
            type="button"
            onClick={() => onNavigate('add-pass')}
            className="inline-flex items-center gap-2 rounded-md bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800 whitespace-nowrap"
          >
            <PlusCircle className="h-4 w-4" aria-hidden="true" />
            Add Bus Pass
          </button>
        </div>
      </section>

      {/* Primary KPI Grid */}
      <section aria-label="Key bus pass metrics" className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Total Registered</p>
          <p className="mt-2 font-mono text-3xl font-semibold text-slate-900 tabular-nums" data-testid="kpi-total">
            {kpis.total_passes}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            {kpis.total_stored} records stored in SQLite
          </p>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-emerald-700">Currently Active</p>
          <p className="mt-2 font-mono text-3xl font-semibold text-emerald-800 tabular-nums" data-testid="kpi-active">
            {kpis.active_passes}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            Avg {kpis.avg_remaining_days_active}d validity left
          </p>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-amber-700">Expiring Soon</p>
          <p className="mt-2 font-mono text-3xl font-semibold text-amber-800 tabular-nums" data-testid="kpi-soon">
            {kpis.expiring_soon}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Within 1–{summary.warning_days} days
          </p>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-orange-700">Expires Today</p>
          <p className="mt-2 font-mono text-3xl font-semibold text-orange-800 tabular-nums" data-testid="kpi-today">
            {kpis.expires_today}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Immediate renewal due
          </p>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-red-700">Already Expired</p>
          <p className="mt-2 font-mono text-3xl font-semibold text-red-800 tabular-nums" data-testid="kpi-expired">
            {kpis.expired_passes}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            Total fees: {formatCurrency(kpis.total_fee_collected)}
          </p>
        </div>
      </section>

      {/* Threshold Warnings */}
      {summary.warnings.length > 0 && (
        <section aria-label="Threshold warning indicators" className="space-y-3">
          <h2 className="text-base font-semibold text-slate-900">Threshold Warning Indicators</h2>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {summary.warnings.map((w) => (
              <div
                key={w.code}
                className={`flex items-start gap-3 rounded-lg border px-4 py-3 text-sm ${
                  WARNING_BOX_STYLE[w.severity] || WARNING_BOX_STYLE.info
                }`}
              >
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                <div>
                  <p className="font-semibold">{w.title}</p>
                  <p className="mt-0.5 text-xs opacity-90">{w.message}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Visualizations */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-slate-200 bg-white p-6">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Status Distribution</h2>
              <p className="text-xs text-slate-500">Real-time classification computed by Python ExpiryService</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('analytics')}
              className="inline-flex items-center gap-1 text-xs font-medium text-teal-700 hover:text-teal-900 whitespace-nowrap"
            >
              Full Analytics
              <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </button>
          </div>
          <StatusDistributionChart data={summary.status_distribution} />
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-6">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Monthly Expiry Trend</h2>
              <p className="text-xs text-slate-500">6-month rolling forecast across stored pass records</p>
            </div>
          </div>
          <MonthlyExpiryTrendChart data={summary.monthly_expiry_trend} />
        </div>
      </section>

      {/* Upcoming Notifications & Recent Additions */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Upcoming Expiry Notifications</h2>
              <p className="text-xs text-slate-500">Sorted by nearest renewal deadline</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('expiry-monitor')}
              className="text-xs font-medium text-teal-700 hover:text-teal-900 whitespace-nowrap"
            >
              View All
            </button>
          </div>
          {summary.upcoming_notifications.length === 0 ? (
            <div className="p-6 text-sm text-slate-500">
              No passes are expiring within the next {summary.warning_days} days.
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {summary.upcoming_notifications.slice(0, 6).map((item) => (
                <li key={item.pass_id}>
                  <button
                    type="button"
                    onClick={() => onSelectPass(item)}
                    className="flex w-full items-center justify-between gap-4 px-6 py-3.5 text-left hover:bg-slate-50"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-slate-900">
                        {item.holder_name}{' '}
                        <span className="font-mono text-xs text-slate-500">· {item.pass_id}</span>
                      </p>
                      <p className="truncate text-xs text-slate-500">
                        {item.route} · Expires {item.expiry_date}
                      </p>
                    </div>
                    <div className="flex items-center gap-2.5 shrink-0">
                      <span className="font-mono text-xs font-medium text-slate-700 tabular-nums">
                        {formatDaysRemaining(item.days_remaining)}
                      </span>
                      <StatusBadge status={item.status} />
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-lg border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Recent Additions</h2>
              <p className="text-xs text-slate-500">Latest bus pass registrations stored in SQLite</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('all-passes')}
              className="text-xs font-medium text-teal-700 hover:text-teal-900 whitespace-nowrap"
            >
              All Passes
            </button>
          </div>
          {summary.recent_additions.length === 0 ? (
            <div className="p-6 text-sm text-slate-500">
              No bus passes recorded yet. Register your first bus pass to get started.
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {summary.recent_additions.map((item) => (
                <li key={item.pass_id}>
                  <button
                    type="button"
                    onClick={() => onSelectPass(item)}
                    className="flex w-full items-center justify-between gap-4 px-6 py-3.5 text-left hover:bg-slate-50"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-slate-900">
                        {item.holder_name}{' '}
                        <span className="font-mono text-xs text-slate-500">· {item.pass_id}</span>
                      </p>
                      <p className="truncate text-xs text-slate-500">
                        {item.category} · Issued {item.issue_date}
                      </p>
                    </div>
                    <div className="flex items-center gap-2.5 shrink-0">
                      <span className="font-mono text-xs text-slate-600 tabular-nums">
                        {formatCurrency(item.fee)}
                      </span>
                      <StatusBadge status={item.status} />
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}
