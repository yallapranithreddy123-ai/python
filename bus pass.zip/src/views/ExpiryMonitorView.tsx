import {useState} from 'react';
import {AlertTriangle, Clock} from 'lucide-react';
import {StatusBadge} from '../components/StatusBadge';
import type {BusPass, ExpiryMonitorData} from '../types/busPass';
import {formatDaysRemaining} from '../utils/formatters';

interface ExpiryMonitorViewProps {
  monitor: ExpiryMonitorData | null;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  onSelectPass: (pass: BusPass) => void;
}

type MonitorBucket = 'urgent' | 'today' | 'soon' | 'expired' | 'future';

export function ExpiryMonitorView({
  monitor,
  loading,
  error,
  onRetry,
  onSelectPass,
}: ExpiryMonitorViewProps) {
  const [activeBucket, setActiveBucket] = useState<MonitorBucket>('urgent');

  if (loading && !monitor) {
    return (
      <div className="space-y-4">
        <div className="h-20 animate-pulse rounded-lg border border-slate-200 bg-white" />
        <div className="h-80 animate-pulse rounded-lg border border-slate-200 bg-white" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-lg border border-red-200 bg-red-50 p-6">
        <p className="font-semibold text-red-900">Failed to load Expiry Monitor</p>
        <p className="mt-1 text-sm text-red-800">{error}</p>
        <button
          type="button"
          onClick={onRetry}
          className="mt-3 rounded-md bg-red-700 px-4 py-2 text-xs font-medium text-white hover:bg-red-800"
        >
          Retry
        </button>
      </div>
    );
  }

  if (!monitor) {
    return null;
  }

  const urgentList = [...monitor.expires_today, ...monitor.expiring_soon];
  const bucketRows: Record<MonitorBucket, BusPass[]> = {
    urgent: urgentList,
    today: monitor.expires_today,
    soon: monitor.expiring_soon,
    expired: monitor.expired,
    future: monitor.future,
  };

  const currentRows = bucketRows[activeBucket] || [];

  const tabs: {id: MonitorBucket; label: string; count: number}[] = [
    {id: 'urgent', label: 'All Upcoming Alerts', count: urgentList.length},
    {id: 'today', label: 'Expires Today', count: monitor.counts.expires_today},
    {id: 'soon', label: `Within ${monitor.warning_days} Days`, count: monitor.counts.expiring_soon},
    {id: 'expired', label: 'Expired', count: monitor.counts.expired},
    {id: 'future', label: 'Future Active', count: monitor.counts.future},
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-3 rounded-lg border border-slate-200 bg-white p-5 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">Intelligent Expiry Monitor</h1>
          <p className="text-sm text-slate-600">
            Deadline-prioritized queue using your configured <span className="font-mono font-semibold">{monitor.warning_days}-day</span> warning threshold.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-600">
          <Clock className="h-4 w-4 text-amber-600" aria-hidden="true" />
          <span className="font-mono tabular-nums">
            {urgentList.length} upcoming · {monitor.counts.expired} overdue
          </span>
        </div>
      </div>

      {/* Segmented Filter Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-100 p-1.5" role="tablist">
        {tabs.map((tab) => {
          const active = activeBucket === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setActiveBucket(tab.id)}
              className={`inline-flex items-center gap-2 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                active
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>{tab.label}</span>
              <span className="font-mono text-[11px] text-slate-500 tabular-nums">{tab.count}</span>
            </button>
          );
        })}
      </div>

      {/* Prioritized Queue */}
      <div className="overflow-hidden rounded-lg border border-slate-200 bg-white">
        {currentRows.length === 0 ? (
          <div className="p-10 text-center text-sm text-slate-500">
            No bus passes fall into this expiry bucket right now.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full divide-y divide-slate-200 text-left text-sm">
              <thead className="bg-slate-50 text-xs font-semibold text-slate-600">
                <tr>
                  <th scope="col" className="px-3 py-3 whitespace-nowrap">Pass ID</th>
                  <th scope="col" className="px-3 py-3 whitespace-nowrap">Holder & Contact</th>
                  <th scope="col" className="px-3 py-3 whitespace-nowrap">Route</th>
                  <th scope="col" className="px-3 py-3 whitespace-nowrap">Expiry</th>
                  <th scope="col" className="px-3 py-3 whitespace-nowrap">Renewal By</th>
                  <th scope="col" className="px-3 py-3 text-right whitespace-nowrap">Countdown</th>
                  <th scope="col" className="px-3 py-3 whitespace-nowrap">Urgency</th>
                  <th scope="col" className="px-3 py-3 whitespace-nowrap">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {currentRows.map((p) => (
                  <tr
                    key={p.pass_id}
                    onClick={() => onSelectPass(p)}
                    className="cursor-pointer hover:bg-slate-50"
                  >
                    <td className="px-3 py-2.5 font-mono text-xs font-semibold text-teal-800 whitespace-nowrap">
                      {p.pass_id}
                    </td>
                    <td className="px-3 py-2.5 whitespace-nowrap">
                      <div className="font-medium text-slate-900 text-xs">{p.holder_name}</div>
                      <div className="font-mono text-[11px] text-slate-500">{p.mobile_number}</div>
                    </td>
                    <td className="max-w-[180px] truncate px-3 py-2.5 text-xs text-slate-700" title={p.route}>
                      {p.route}
                    </td>
                    <td className="px-3 py-2.5 font-mono text-xs text-slate-700 whitespace-nowrap">
                      {p.expiry_date}
                    </td>
                    <td className="px-3 py-2.5 font-mono text-xs text-slate-600 whitespace-nowrap">
                      {p.renewal_deadline}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-xs font-semibold text-slate-900 whitespace-nowrap tabular-nums">
                      {formatDaysRemaining(p.days_remaining)}
                    </td>
                    <td className="px-3 py-2.5 text-xs font-medium text-slate-700 whitespace-nowrap">
                      {p.urgency === 'Critical' || p.urgency === 'Overdue' ? (
                        <span className="inline-flex items-center gap-1 text-red-700">
                          <AlertTriangle className="h-3.5 w-3.5" aria-hidden="true" />
                          {p.urgency}
                        </span>
                      ) : (
                        p.urgency
                      )}
                    </td>
                    <td className="px-3 py-2.5 whitespace-nowrap">
                      <StatusBadge status={p.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
