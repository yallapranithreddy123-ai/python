import {useState, type ChangeEvent} from 'react';
import {AlertCircle, CheckCircle2, Download, FileSpreadsheet, FileText, Upload} from 'lucide-react';
import {ApiError, apiClient} from '../api/client';
import type {ImportResult} from '../types/busPass';

interface ImportExportViewProps {
  onDataImported: () => void;
}

export function ImportExportView({onDataImported}: ImportExportViewProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [importType, setImportType] = useState<'csv' | 'json'>('csv');
  const [importing, setImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const [downloading, setDownloading] = useState<string | null>(null);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setSelectedFile(file);
    setImportError(null);
    setImportResult(null);
    if (file?.name.toLowerCase().endsWith('.json')) {
      setImportType('json');
    } else if (file?.name.toLowerCase().endsWith('.csv')) {
      setImportType('csv');
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setImportError('Please select a .csv or .json dataset file first.');
      return;
    }
    setImporting(true);
    setImportError(null);
    setImportResult(null);

    try {
      const result =
        importType === 'json'
          ? await apiClient.importJsonFile(selectedFile)
          : await apiClient.importCsvFile(selectedFile);
      setImportResult(result);
      if (result.imported_count > 0) {
        onDataImported();
      }
    } catch (err) {
      if (err instanceof ApiError) {
        setImportError(err.message);
      } else {
        setImportError('Upload failed due to a network or server error.');
      }
    } finally {
      setImporting(false);
    }
  };

  const triggerDownload = async (endpoint: string, fallback: string, key: string) => {
    setDownloading(key);
    try {
      await apiClient.downloadExport(endpoint, fallback);
    } catch (err) {
      setImportError(err instanceof Error ? err.message : 'Download failed.');
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border border-slate-200 bg-white p-6">
        <h1 className="text-xl font-semibold text-slate-900">Import & Multi-Format Export</h1>
        <p className="mt-1 text-sm text-slate-600">
          Bulk import bus pass CSV or JSON datasets with strict row-by-row validation, or export SQLite records and audit reports atomically.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Bulk Import Card */}
        <section className="rounded-lg border border-slate-200 bg-white p-6 lg:col-span-7 space-y-5">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Bulk Dataset Import</h2>
            <p className="mt-1 text-xs text-slate-500">
              Required CSV columns: <span className="font-mono">pass_id, holder_name, mobile_number, route, category, issue_date, expiry_date</span> (optional: <span className="font-mono">fee, notes</span>). Max upload 5 MB.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label htmlFor="bulk-file-input" className="block text-sm font-medium text-slate-700">
                Select Dataset File (.csv or .json)
              </label>
              <input
                id="bulk-file-input"
                type="file"
                accept=".csv,.json"
                onChange={handleFileChange}
                className="mt-1.5 block w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm text-slate-700 file:mr-4 file:rounded file:border-0 file:bg-teal-700 file:px-3 file:py-1.5 file:text-xs file:font-medium file:text-white hover:file:bg-teal-800"
              />
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2 rounded-md border border-slate-200 bg-slate-50 p-1">
                <button
                  type="button"
                  onClick={() => setImportType('csv')}
                  className={`rounded px-3 py-1 text-xs font-medium ${
                    importType === 'csv' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  CSV Format
                </button>
                <button
                  type="button"
                  onClick={() => setImportType('json')}
                  className={`rounded px-3 py-1 text-xs font-medium ${
                    importType === 'json' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  JSON Format
                </button>
              </div>

              <button
                type="button"
                disabled={importing || !selectedFile}
                onClick={() => void handleUpload()}
                className="inline-flex items-center gap-2 rounded-md bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800 disabled:opacity-50"
              >
                <Upload className="h-4 w-4" aria-hidden="true" />
                {importing ? 'Validating & Importing...' : 'Validate & Import'}
              </button>
            </div>
          </div>

          {importError && (
            <div role="alert" className="flex items-start gap-2.5 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-900">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" aria-hidden="true" />
              <div>
                <p className="font-semibold">Import Rejected</p>
                <p className="text-xs text-red-800">{importError}</p>
              </div>
            </div>
          )}

          {importResult && (
            <div className="space-y-4 rounded-lg border border-slate-200 bg-slate-50 p-4" data-testid="import-summary">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                <CheckCircle2 className="h-4 w-4 text-teal-700" aria-hidden="true" />
                <span>Import Diagnostic Summary</span>
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div className="rounded border border-slate-200 bg-white p-3">
                  <p className="text-[11px] text-slate-500">Total Rows</p>
                  <p className="font-mono text-lg font-semibold text-slate-900 tabular-nums">
                    {importResult.total_rows}
                  </p>
                </div>
                <div className="rounded border border-emerald-200 bg-emerald-50 p-3">
                  <p className="text-[11px] text-emerald-700">Imported</p>
                  <p className="font-mono text-lg font-semibold text-emerald-800 tabular-nums">
                    {importResult.imported_count}
                  </p>
                </div>
                <div className="rounded border border-amber-200 bg-amber-50 p-3">
                  <p className="text-[11px] text-amber-800">Duplicates</p>
                  <p className="font-mono text-lg font-semibold text-amber-900 tabular-nums">
                    {importResult.skipped_duplicates}
                  </p>
                </div>
                <div className="rounded border border-red-200 bg-red-50 p-3">
                  <p className="text-[11px] text-red-700">Rejected Rows</p>
                  <p className="font-mono text-lg font-semibold text-red-800 tabular-nums">
                    {importResult.failed_count}
                  </p>
                </div>
              </div>

              {importResult.row_errors.length > 0 && (
                <div className="overflow-x-auto rounded border border-slate-200 bg-white">
                  <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
                    <thead className="bg-slate-100 font-semibold text-slate-700">
                      <tr>
                        <th scope="col" className="px-3 py-2">Row</th>
                        <th scope="col" className="px-3 py-2">Pass ID</th>
                        <th scope="col" className="px-3 py-2">Validation / Conflict Details</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {importResult.row_errors.map((err, i) => (
                        <tr key={`${err.row_number}-${err.pass_id}-${i}`}>
                          <td className="px-3 py-2 font-mono text-slate-600 tabular-nums">
                            {err.row_number > 0 ? err.row_number : 'DB'}
                          </td>
                          <td className="px-3 py-2 font-mono font-medium text-slate-900">{err.pass_id}</td>
                          <td className="px-3 py-2 text-red-700">{err.errors.join(' ')}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </section>

        {/* Exports & Reports Card */}
        <section className="rounded-lg border border-slate-200 bg-white p-6 lg:col-span-5 space-y-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Exports & Generated Reports</h2>
            <p className="mt-1 text-xs text-slate-500">
              All exports are generated on demand by Python using atomic file serialization.
            </p>
          </div>

          <div className="divide-y divide-slate-100 border-t border-slate-100">
            <div className="flex items-center justify-between gap-4 py-3.5">
              <div>
                <p className="text-sm font-medium text-slate-900">Raw CSV Dataset</p>
                <p className="text-xs text-slate-500">Standardized CSV backup compatible with re-import</p>
              </div>
              <button
                type="button"
                disabled={downloading !== null}
                onClick={() => void triggerDownload('/api/export/csv', 'bus_passes_export.csv', 'raw-csv')}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
              >
                <FileSpreadsheet className="h-3.5 w-3.5" aria-hidden="true" />
                {downloading === 'raw-csv' ? 'Exporting...' : 'Export CSV'}
              </button>
            </div>

            <div className="flex items-center justify-between gap-4 py-3.5">
              <div>
                <p className="text-sm font-medium text-slate-900">Schema-Versioned JSON</p>
                <p className="text-xs text-slate-500">Structured JSON payload with metadata envelope</p>
              </div>
              <button
                type="button"
                disabled={downloading !== null}
                onClick={() => void triggerDownload('/api/export/json', 'bus_passes_export.json', 'raw-json')}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
              >
                <Download className="h-3.5 w-3.5" aria-hidden="true" />
                {downloading === 'raw-json' ? 'Exporting...' : 'Export JSON'}
              </button>
            </div>

            <div className="flex items-center justify-between gap-4 py-3.5">
              <div>
                <p className="text-sm font-medium text-slate-900">Executive Markdown Report</p>
                <p className="text-xs text-slate-500">Summary metrics, warnings, and pass registry table</p>
              </div>
              <button
                type="button"
                disabled={downloading !== null}
                onClick={() => void triggerDownload('/api/reports/markdown', 'bus_pass_report.md', 'md')}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
              >
                <FileText className="h-3.5 w-3.5" aria-hidden="true" />
                {downloading === 'md' ? 'Building...' : 'Download .md'}
              </button>
            </div>

            <div className="flex items-center justify-between gap-4 py-3.5">
              <div>
                <p className="text-sm font-medium text-slate-900">Status-Enriched CSV Report</p>
                <p className="text-xs text-slate-500">Includes computed days remaining, status, and urgency</p>
              </div>
              <button
                type="button"
                disabled={downloading !== null}
                onClick={() => void triggerDownload('/api/reports/csv', 'bus_pass_report.csv', 'rep-csv')}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
              >
                <Download className="h-3.5 w-3.5" aria-hidden="true" />
                {downloading === 'rep-csv' ? 'Building...' : 'Download CSV'}
              </button>
            </div>

            <div className="flex items-center justify-between gap-4 py-3.5">
              <div>
                <p className="text-sm font-medium text-slate-900">Plain-Text Audit Log</p>
                <p className="text-xs text-slate-500">Timestamped operations log from SQLite audit_logs</p>
              </div>
              <button
                type="button"
                disabled={downloading !== null}
                onClick={() => void triggerDownload('/api/reports/audit', 'audit_report.txt', 'audit')}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
              >
                <Download className="h-3.5 w-3.5" aria-hidden="true" />
                {downloading === 'audit' ? 'Building...' : 'Download .txt'}
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
