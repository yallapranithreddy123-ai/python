import {useCallback, useEffect, useState} from 'react';
import {ChevronLeft, ChevronRight, Edit3, Eye, Search, X} from 'lucide-react';
import {apiClient} from '../api/client';
import {StatusBadge} from '../components/StatusBadge';
import type {BusPass, PaginationResponse} from '../types/busPass';
import {formatCurrency, formatDaysRemaining} from '../utils/formatters';

interface PassesTableViewProps {
  title: string;
  subtitle: string;
  categories: string[];
  statuses: string[];
  showDateRangeFilter?: boolean;
  refreshSignal: number;
  onSelectPass: (pass: BusPass, editMode?: boolean) => void;
  onAddNew: () => void;
}

export function PassesTableView({
  title,
  subtitle,
  categories,
  statuses,
  showDateRangeFilter = false,
  refreshSignal,
  onSelectPass,
  onAddNew,
}: PassesTableViewProps) {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [status, setStatus] = useState('all');
  const [expiryFrom, setExpiryFrom] = useState('');
  const [expiryTo, setExpiryTo] = useState('');
  const [sortBy, setSortBy] = useState('expiry_date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const [data, setData] = useState<PaginationResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRecords = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiClient.searchPasses({
        q: query,
        category,
        status,
        expiry_from: expiryFrom,
        expiry_to: expiryTo,
        sort_by: sortBy,
        sort_dir: sortDir,
        page,
        page_size: pageSize,
      });
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to query bus pass records.');
    } finally {
      setLoading(false);
    }
  }, [query, category, status, expiryFrom, expiryTo, sortBy, sortDir, page, pageSize, refreshSignal]);

  useEffect(() => {
    const timer = setTimeout(() => {
      void fetchRecords();
    }, 120);
    return () => clearTimeout(timer);
  }, [fetchRecords]);

  const clearFilters = () => {
    setQuery('');
    setCategory('all');
    setStatus('all');
    setExpiryFrom('');
    setExpiryTo('');
    setPage(1);
  };

  const hasFilters =
    query.trim() !== '' ||
    category !== 'all' ||
    status !== 'all' ||
    expiryFrom !== '' ||
    expiryTo !== '';

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-slate-900">{title}</h1>
        <p className="text-sm text-slate-600">{subtitle}</p>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="rounded-lg border border-slate-200 bg-white p-4 space-y-3">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-12">
          <div className="md:col-span-5">
            <label htmlFor="pass-search-input" className="block text-xs font-medium text-slate-600">
              Keyword Search (Name, Pass ID, Mobile, Route)
            </label>
            <div className="relative mt-1">
              <Search
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                aria-hidden="true"
              />
              <input
                id="pass-search-input"
                type="search"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setPage(1);
                }}
                placeholder="Search by passenger, pass ID, phone, or route..."
                className="block w-full rounded-md border border-slate-300 bg-white py-2 pl-9 pr-3 text-sm text-slate-900 focus:border-teal-600 focus:outline-none focus:ring-2 focus:ring-teal-600/20"
              />
            </div>
          </div>

          <div className="md:col-span-3">
            <label htmlFor="category-filter" className="block text-xs font-medium text-slate-600">
              Pass Category
            </label>
            <select
              id="category-filter"
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                setPage(1);
              }}
              className="mt-1 block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
            >
              <option value="all">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <label htmlFor="status-filter" className="block text-xs font-medium text-slate-600">
              Status
            </label>
            <select
              id="status-filter"
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(1);
              }}
              className="mt-1 block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
            >
              <option value="all">All Statuses</option>
              {statuses.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <label htmlFor="sort-select" className="block text-xs font-medium text-slate-600">
              Sort Order
            </label>
            <select
              id="sort-select"
              value={`${sortBy}:${sortDir}`}
              onChange={(e) => {
                const [col, dir] = e.target.value.split(':');
                setSortBy(col);
                setSortDir(dir === 'desc' ? 'desc' : 'asc');
                setPage(1);
              }}
              className="mt-1 block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
            >
              <option value="expiry_date:asc">Expiry (Nearest)</option>
              <option value="expiry_date:desc">Expiry (Furthest)</option>
              <option value="pass_id:asc">Pass ID (A–Z)</option>
              <option value="holder_name:asc">Name (A–Z)</option>
              <option value="fee:desc">Fee (High–Low)</option>
              <option value="created_at:desc">Newest Added</option>
            </select>
          </div>
        </div>

        {showDateRangeFilter && (
          <div className="grid grid-cols-1 gap-3 border-t border-slate-100 pt-3 sm:grid-cols-3">
            <div>
              <label htmlFor="expiry-from" className="block text-xs font-medium text-slate-600">
                Expiry From
              </label>
              <input
                id="expiry-from"
                type="date"
                value={expiryFrom}
                onChange={(e) => {
                  setExpiryFrom(e.target.value);
                  setPage(1);
                }}
                className="mt-1 block w-full rounded-md border border-slate-300 bg-white px-3 py-1.5 font-mono text-sm text-slate-900"
              />
            </div>
            <div>
              <label htmlFor="expiry-to" className="block text-xs font-medium text-slate-600">
                Expiry To
              </label>
              <input
                id="expiry-to"
                type="date"
                value={expiryTo}
                onChange={(e) => {
                  setExpiryTo(e.target.value);
                  setPage(1);
                }}
                className="mt-1 block w-full rounded-md border border-slate-300 bg-white px-3 py-1.5 font-mono text-sm text-slate-900"
              />
            </div>
            <div className="flex items-end">
              {hasFilters && (
                <button
                  type="button"
                  onClick={clearFilters}
                  className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  <X className="h-3.5 w-3.5" aria-hidden="true" />
                  Clear Filters
                </button>
              )}
            </div>
          </div>
        )}

        {!showDateRangeFilter && hasFilters && (
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Filters active</span>
            <button
              type="button"
              onClick={clearFilters}
              className="inline-flex items-center gap-1 font-medium text-teal-700 hover:text-teal-900"
            >
              <X className="h-3.5 w-3.5" aria-hidden="true" />
              Reset filters
            </button>
          </div>
        )}
      </div>

      {/* Results Table */}
      <div className="overflow-hidden rounded-lg border border-slate-200 bg-white">
        {error ? (
          <div className="p-6 text-sm text-red-800">
            <p className="font-medium">Search Error</p>
            <p className="mt-1">{error}</p>
            <button
              type="button"
              onClick={() => void fetchRecords()}
              className="mt-3 rounded-md bg-red-700 px-3 py-1.5 text-xs font-medium text-white hover:bg-red-800"
            >
              Retry
            </button>
          </div>
        ) : loading && !data ? (
          <div className="space-y-2 p-6">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-10 animate-pulse rounded bg-slate-100" />
            ))}
          </div>
        ) : !data || data.items.length === 0 ? (
          <div className="p-10 text-center">
            <p className="text-sm font-medium text-slate-900">No matching bus pass records found</p>
            <p className="mt-1 text-xs text-slate-500">
              {hasFilters
                ? 'Try clearing your active search keywords or date filters.'
                : 'Register a new bus pass or import a CSV dataset to populate the registry.'}
            </p>
            {hasFilters ? (
              <button
                type="button"
                onClick={clearFilters}
                className="mt-4 rounded-md border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                Clear All Filters
              </button>
            ) : (
              <button
                type="button"
                onClick={onAddNew}
                className="mt-4 rounded-md bg-teal-700 px-4 py-2 text-xs font-medium text-white hover:bg-teal-800"
              >
                Register First Pass
              </button>
            )}
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full divide-y divide-slate-200 text-left text-sm">
                <thead className="bg-slate-50 text-xs font-semibold text-slate-600">
                  <tr>
                    <th scope="col" className="px-3 py-3 whitespace-nowrap">Pass ID</th>
                    <th scope="col" className="px-3 py-3 whitespace-nowrap">Holder</th>
                    <th scope="col" className="px-3 py-3 whitespace-nowrap">Route</th>
                    <th scope="col" className="px-3 py-3 whitespace-nowrap">Category</th>
                    <th scope="col" className="px-3 py-3 whitespace-nowrap">Expiry</th>
                    <th scope="col" className="px-3 py-3 text-right whitespace-nowrap">Remaining</th>
                    <th scope="col" className="px-3 py-3 text-right whitespace-nowrap">Fee</th>
                    <th scope="col" className="px-3 py-3 whitespace-nowrap">Status</th>
                    <th scope="col" className="px-3 py-3 text-right whitespace-nowrap">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {data.items.map((item) => (
                    <tr key={item.pass_id} className="hover:bg-slate-50/80">
                      <td className="px-3 py-2.5 font-mono text-xs font-semibold text-slate-900 whitespace-nowrap">
                        {item.pass_id}
                      </td>
                      <td className="px-3 py-2.5 whitespace-nowrap">
                        <div className="font-medium text-slate-900 text-xs">{item.holder_name}</div>
                        <div className="font-mono text-[11px] text-slate-500">{item.mobile_number}</div>
                      </td>
                      <td className="max-w-[165px] truncate px-3 py-2.5 text-xs text-slate-700" title={item.route}>
                        {item.route}
                      </td>
                      <td className="max-w-[125px] truncate px-3 py-2.5 text-xs text-slate-700 whitespace-nowrap">
                        {item.category}
                      </td>
                      <td className="px-3 py-2.5 font-mono text-xs text-slate-700 whitespace-nowrap">
                        {item.expiry_date}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono text-xs font-medium text-slate-800 whitespace-nowrap tabular-nums">
                        {formatDaysRemaining(item.days_remaining)}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono text-xs text-slate-700 whitespace-nowrap tabular-nums">
                        {formatCurrency(item.fee)}
                      </td>
                      <td className="px-3 py-2.5 whitespace-nowrap">
                        <StatusBadge status={item.status} />
                      </td>
                      <td className="px-3 py-2.5 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => onSelectPass(item, false)}
                            aria-label={`View details for ${item.pass_id}`}
                            className="rounded p-1.5 text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                          >
                            <Eye className="h-4 w-4" aria-hidden="true" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onSelectPass(item, true)}
                            aria-label={`Edit pass ${item.pass_id}`}
                            className="rounded p-1.5 text-slate-600 hover:bg-slate-100 hover:text-teal-800"
                          >
                            <Edit3 className="h-4 w-4" aria-hidden="true" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination Footer */}
            <div className="flex flex-wrap items-center justify-between gap-4 border-t border-slate-200 bg-slate-50 px-4 py-3 text-xs text-slate-600">
              <div className="flex items-center gap-3">
                <span className="font-mono tabular-nums">
                  Showing {(data.page - 1) * data.page_size + 1}–
                  {Math.min(data.page * data.page_size, data.total_count)} of {data.total_count}
                </span>
                <label className="inline-flex items-center gap-1.5">
                  <span>Rows:</span>
                  <select
                    aria-label="Rows per page"
                    value={pageSize}
                    onChange={(e) => {
                      setPageSize(Number(e.target.value));
                      setPage(1);
                    }}
                    className="rounded border border-slate-300 bg-white px-2 py-1 font-mono text-xs"
                  >
                    <option value={10}>10</option>
                    <option value={15}>15</option>
                    <option value={25}>25</option>
                    <option value={50}>50</option>
                  </select>
                </label>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={data.page <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  className="inline-flex items-center gap-1 rounded border border-slate-300 bg-white px-2.5 py-1 font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-40"
                >
                  <ChevronLeft className="h-3.5 w-3.5" aria-hidden="true" />
                  Previous
                </button>
                <span className="px-2 font-mono tabular-nums">
                  Page {data.page} / {data.total_pages}
                </span>
                <button
                  type="button"
                  disabled={data.page >= data.total_pages}
                  onClick={() => setPage((p) => Math.min(data.total_pages, p + 1))}
                  className="inline-flex items-center gap-1 rounded border border-slate-300 bg-white px-2.5 py-1 font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-40"
                >
                  Next
                  <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
