import {useCallback, useEffect, useState, type FormEvent} from 'react';
import {CheckCircle2, Database, ExternalLink, RefreshCw, ShieldCheck} from 'lucide-react';
import {ApiError, apiClient} from '../api/client';
import type {AppSettings, AuditLogEntry, BackupEntry, HealthResponse} from '../types/busPass';
import {formatBytes} from '../utils/formatters';

interface SettingsViewProps {
  storageModes: string[];
  onSettingsUpdated: () => void;
}

export function SettingsView({storageModes, onSettingsUpdated}: SettingsViewProps) {
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [warningDays, setWarningDays] = useState('7');
  const [syncMode, setSyncMode] = useState('sqlite+csv+json');
  const [pageSize, setPageSize] = useState('15');

  const [backups, setBackups] = useState<BackupEntry[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [health, setHealth] = useState<HealthResponse | null>(null);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [workingBackup, setWorkingBackup] = useState(false);
  const [confirmRestoreFile, setConfirmRestoreFile] = useState<string | null>(null);
  const [confirmSampleReset, setConfirmSampleReset] = useState(false);

  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [s, b, a, h] = await Promise.all([
        apiClient.getSettings(),
        apiClient.listBackups(),
        apiClient.getAuditLogs(25),
        apiClient.getHealth(),
      ]);
      setSettings(s);
      setWarningDays(String(s.expiry_warning_days));
      setSyncMode(s.storage_sync_mode);
      setPageSize(String(s.default_page_size));
      setBackups(b.backups);
      setAuditLogs(a.logs);
      setHealth(h);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Failed to load settings.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadAll();
  }, [loadAll]);

  const handleSaveSettings = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setStatusMessage(null);
    setErrorMessage(null);
    setFieldErrors({});

    try {
      const updated = await apiClient.updateSettings({
        expiry_warning_days: Number(warningDays),
        storage_sync_mode: syncMode,
        default_page_size: Number(pageSize),
      });
      setSettings(updated);
      setStatusMessage(
        `Settings saved: ${updated.expiry_warning_days}-day warning threshold, mode '${updated.storage_sync_mode}'.`,
      );
      onSettingsUpdated();
      await loadAll();
    } catch (err) {
      if (err instanceof ApiError) {
        setErrorMessage(err.message);
        setFieldErrors(err.fieldErrors);
      } else {
        setErrorMessage('Failed to save settings.');
      }
    } finally {
      setSaving(false);
    }
  };

  const handleCreateBackup = async () => {
    setWorkingBackup(true);
    setStatusMessage(null);
    setErrorMessage(null);
    try {
      const created = await apiClient.createBackup();
      setStatusMessage(`Created verified SQLite backup: ${created.filename} (${formatBytes(created.size_bytes)}).`);
      await loadAll();
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Backup creation failed.');
    } finally {
      setWorkingBackup(false);
    }
  };

  const handleRestoreBackup = async (filename: string) => {
    setWorkingBackup(true);
    setStatusMessage(null);
    setErrorMessage(null);
    try {
      const res = await apiClient.restoreBackup(filename);
      setStatusMessage(`Database restored from ${res.restored_from} (${res.record_count} pass records).`);
      setConfirmRestoreFile(null);
      onSettingsUpdated();
      await loadAll();
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Backup restore failed.');
    } finally {
      setWorkingBackup(false);
    }
  };

  const handleResetSample = async () => {
    setWorkingBackup(true);
    setStatusMessage(null);
    setErrorMessage(null);
    try {
      const res = await apiClient.resetToSampleDataset();
      setStatusMessage(res.message);
      setConfirmSampleReset(false);
      onSettingsUpdated();
      await loadAll();
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Failed to reset sample dataset.');
    } finally {
      setWorkingBackup(false);
    }
  };

  if (loading && !settings) {
    return (
      <div className="space-y-4">
        <div className="h-32 animate-pulse rounded-lg border border-slate-200 bg-white" />
        <div className="h-64 animate-pulse rounded-lg border border-slate-200 bg-white" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 rounded-lg border border-slate-200 bg-white p-6 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">Settings, Backups & Data Integrity</h1>
          <p className="text-sm text-slate-600">
            Configure expiry warning thresholds, local CSV/JSON sync, SQLite backups, and review audit history.
          </p>
        </div>
        <a
          href="/docs"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap self-start sm:self-auto"
        >
          OpenAPI / Swagger UI
          <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
        </a>
      </div>

      {statusMessage && (
        <div role="status" className="flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-900">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
          <span>{statusMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div role="alert" className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-900">
          {errorMessage}
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Configuration Form */}
        <section className="rounded-lg border border-slate-200 bg-white p-6 lg:col-span-6">
          <h2 className="text-base font-semibold text-slate-900">Threshold & Storage Configuration</h2>
          <form onSubmit={handleSaveSettings} className="mt-4 space-y-4">
            <div>
              <label htmlFor="expiry-warning-days" className="block text-sm font-medium text-slate-700">
                Expiry Warning Threshold (Days)
              </label>
              <input
                id="expiry-warning-days"
                type="number"
                min={1}
                max={90}
                value={warningDays}
                onChange={(e) => setWarningDays(e.target.value)}
                className="mt-1.5 block w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900"
              />
              <p className="mt-1 text-xs text-slate-500">
                Passes within 1 to N days remaining are classified as &quot;Expiring Soon&quot;.
              </p>
              {fieldErrors.expiry_warning_days && (
                <p className="mt-1 text-xs text-red-700">{fieldErrors.expiry_warning_days}</p>
              )}
            </div>

            <div>
              <label htmlFor="storage-sync-mode" className="block text-sm font-medium text-slate-700">
                Persistence Sync Strategy
              </label>
              <select
                id="storage-sync-mode"
                value={syncMode}
                onChange={(e) => setSyncMode(e.target.value)}
                className="mt-1.5 block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900"
              >
                {storageModes.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
              <p className="mt-1 text-xs text-slate-500">
                SQLite remains the primary database while atomically keeping CSV and JSON files synchronized.
              </p>
            </div>

            <div>
              <label htmlFor="default-page-size" className="block text-sm font-medium text-slate-700">
                Default Table Page Size
              </label>
              <input
                id="default-page-size"
                type="number"
                min={5}
                max={100}
                value={pageSize}
                onChange={(e) => setPageSize(e.target.value)}
                className="mt-1.5 block w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900"
              />
              {fieldErrors.default_page_size && (
                <p className="mt-1 text-xs text-red-700">{fieldErrors.default_page_size}</p>
              )}
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={saving}
                className="rounded-md bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800 disabled:opacity-60"
              >
                {saving ? 'Saving Configuration...' : 'Save Settings'}
              </button>
            </div>
          </form>
        </section>

        {/* Health & Backup Management */}
        <section className="rounded-lg border border-slate-200 bg-white p-6 lg:col-span-6 space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-slate-900">SQLite Integrity & Backups</h2>
            <button
              type="button"
              disabled={workingBackup}
              onClick={() => void handleCreateBackup()}
              className="inline-flex items-center gap-1.5 rounded-md bg-teal-700 px-3.5 py-2 text-xs font-medium text-white hover:bg-teal-800 disabled:opacity-60 whitespace-nowrap"
            >
              <Database className="h-3.5 w-3.5" aria-hidden="true" />
              Create Backup
            </button>
          </div>

          {health && (
            <div className="rounded-md border border-slate-200 bg-slate-50 p-4 text-xs text-slate-700 space-y-1">
              <div className="flex items-center gap-2 font-semibold text-slate-900">
                <ShieldCheck className="h-4 w-4 text-emerald-700" aria-hidden="true" />
                <span>
                  SQLite PRAGMA integrity_check: {health.database.ok ? 'OK' : 'Attention Required'}
                </span>
              </div>
              <p className="font-mono text-slate-600">
                Schema v{health.database.schema_version} · {health.total_records} records · App v{health.version}
              </p>
            </div>
          )}

          <div>
            <h3 className="text-xs font-semibold text-slate-600">Verified Backups (backups/)</h3>
            {backups.length === 0 ? (
              <p className="mt-2 text-xs text-slate-500">
                No backups created yet. Click &quot;Create Backup&quot; to archive a verified SQLite snapshot.
              </p>
            ) : (
              <ul className="mt-2 divide-y divide-slate-100 border-t border-slate-100">
                {backups.slice(0, 6).map((b) => (
                  <li key={b.filename} className="flex items-center justify-between gap-3 py-2.5 text-xs">
                    <div className="min-w-0">
                      <p className="truncate font-mono font-medium text-slate-900">{b.filename}</p>
                      <p className="font-mono text-slate-500">
                        {formatBytes(b.size_bytes)} · {b.modified_at}
                      </p>
                    </div>
                    {confirmRestoreFile === b.filename ? (
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => setConfirmRestoreFile(null)}
                          className="rounded border border-slate-300 bg-white px-2 py-1 text-xs text-slate-700"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          disabled={workingBackup}
                          onClick={() => void handleRestoreBackup(b.filename)}
                          className="rounded bg-amber-700 px-2 py-1 text-xs font-medium text-white hover:bg-amber-800"
                        >
                          Confirm Restore
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmRestoreFile(b.filename)}
                        className="rounded border border-slate-300 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 shrink-0"
                      >
                        Restore
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="border-t border-slate-200 pt-4">
            {confirmSampleReset ? (
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-amber-200 bg-amber-50 p-3 text-xs">
                <span className="font-medium text-amber-900">
                  Creates a safety backup first, then resets to 40 sample records. Proceed?
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setConfirmSampleReset(false)}
                    className="rounded border border-slate-300 bg-white px-2.5 py-1 text-slate-700"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={workingBackup}
                    onClick={() => void handleResetSample()}
                    className="rounded bg-amber-700 px-2.5 py-1 font-medium text-white hover:bg-amber-800"
                  >
                    Confirm Reset
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmSampleReset(true)}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                Reset to 40-Record Sample Dataset
              </button>
            )}
          </div>
        </section>
      </div>

      {/* Audit Log Viewer */}
      <section className="overflow-hidden rounded-lg border border-slate-200 bg-white">
        <div className="border-b border-slate-200 px-6 py-4">
          <h2 className="text-base font-semibold text-slate-900">Recent Audit History</h2>
          <p className="text-xs text-slate-500">Tracked operations stored in SQLite audit_logs without personal PII</p>
        </div>
        {auditLogs.length === 0 ? (
          <div className="p-6 text-sm text-slate-500">No audit events recorded yet.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
              <thead className="bg-slate-50 font-semibold text-slate-600">
                <tr>
                  <th scope="col" className="px-6 py-3">Timestamp</th>
                  <th scope="col" className="px-6 py-3">Action</th>
                  <th scope="col" className="px-6 py-3">Entity</th>
                  <th scope="col" className="px-6 py-3">Description</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {auditLogs.map((log) => (
                  <tr key={log.id}>
                    <td className="px-6 py-2.5 font-mono text-slate-500 whitespace-nowrap">{log.timestamp}</td>
                    <td className="px-6 py-2.5 font-mono font-semibold text-slate-800 whitespace-nowrap">
                      {log.action}
                    </td>
                    <td className="px-6 py-2.5 font-mono text-slate-600 whitespace-nowrap">
                      {log.entity_type}:{log.entity_id}
                    </td>
                    <td className="px-6 py-2.5 text-slate-700">{log.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
