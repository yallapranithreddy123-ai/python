import type {
  AnalyticsData,
  AppSettings,
  AuditLogEntry,
  BackupEntry,
  BusPass,
  BusPassPayload,
  DashboardSummary,
  ExpiryMonitorData,
  HealthResponse,
  ImportResult,
  PaginationResponse,
} from '../types/busPass';
import {buildSearchQueryString} from '../utils/formatters';

export class ApiError extends Error {
  status: number;
  fieldErrors: Record<string, string>;

  constructor(message: string, status: number, fieldErrors: Record<string, string> = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

let cachedCsrfToken: string | null = null;

async function ensureCsrfToken(): Promise<string> {
  if (cachedCsrfToken) {
    return cachedCsrfToken;
  }
  const res = await fetch('/api/csrf-token');
  if (!res.ok) {
    throw new ApiError('Unable to acquire CSRF session token.', res.status);
  }
  const data = (await res.json()) as {csrf_token: string};
  cachedCsrfToken = data.csrf_token;
  return cachedCsrfToken;
}

async function requestJson<T>(
  url: string,
  options: RequestInit = {},
  requiresCsrf = false,
): Promise<T> {
  const headers = new Headers(options.headers || {});
  if (requiresCsrf) {
    const token = await ensureCsrfToken();
    headers.set('X-CSRF-Token', token);
  }

  let response = await fetch(url, {...options, headers});

  // Refresh CSRF token once if expired/invalidated after backend restart
  if (requiresCsrf && response.status === 403) {
    cachedCsrfToken = null;
    const freshToken = await ensureCsrfToken();
    headers.set('X-CSRF-Token', freshToken);
    response = await fetch(url, {...options, headers});
  }

  if (!response.ok) {
    let message = `Request failed with HTTP ${response.status}`;
    let fieldErrors: Record<string, string> = {};
    try {
      const errBody = (await response.json()) as {
        error?: string;
        field_errors?: Record<string, string>;
      };
      if (errBody.error) {
        message = errBody.error;
      }
      if (errBody.field_errors) {
        fieldErrors = errBody.field_errors;
      }
    } catch {
      // Ignore non-JSON error body
    }
    throw new ApiError(message, response.status, fieldErrors);
  }

  return (await response.json()) as T;
}

export const apiClient = {
  getHealth: () => requestJson<HealthResponse>('/api/health'),
  getMeta: () =>
    requestJson<{
      categories: string[];
      statuses: string[];
      storage_modes: string[];
      matplotlib_available: boolean;
    }>('/api/meta'),
  getDashboardSummary: () => requestJson<DashboardSummary>('/api/dashboard/summary'),
  getAnalytics: () => requestJson<AnalyticsData>('/api/analytics'),
  getExpiryMonitor: () => requestJson<ExpiryMonitorData>('/api/expiry/upcoming'),
  getExpiredPasses: () => requestJson<{count: number; expired: BusPass[]}>('/api/expiry/expired'),

  searchPasses: (params: {
    q?: string;
    category?: string;
    status?: string;
    expiry_from?: string;
    expiry_to?: string;
    sort_by?: string;
    sort_dir?: string;
    page?: number;
    page_size?: number;
  }) => {
    const qs = buildSearchQueryString(params);
    return requestJson<PaginationResponse>(`/api/passes${qs ? `?${qs}` : ''}`);
  },

  getPass: (passId: string) =>
    requestJson<BusPass>(`/api/passes/${encodeURIComponent(passId)}`),

  createPass: (payload: BusPassPayload) =>
    requestJson<BusPass>(
      '/api/passes',
      {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload),
      },
      true,
    ),

  updatePass: (passId: string, payload: Omit<BusPassPayload, 'pass_id'>) =>
    requestJson<BusPass>(
      `/api/passes/${encodeURIComponent(passId)}`,
      {
        method: 'PUT',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload),
      },
      true,
    ),

  deletePass: (passId: string) =>
    requestJson<{deleted: boolean; pass_id: string}>(
      `/api/passes/${encodeURIComponent(passId)}`,
      {method: 'DELETE'},
      true,
    ),

  importCsvFile: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return requestJson<ImportResult>(
      '/api/import/csv',
      {
        method: 'POST',
        body: formData,
      },
      true,
    );
  },

  importJsonFile: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return requestJson<ImportResult>(
      '/api/import/json',
      {
        method: 'POST',
        body: formData,
      },
      true,
    );
  },

  getSettings: () => requestJson<AppSettings>('/api/settings'),

  updateSettings: (settings: Omit<AppSettings, 'updated_at'>) =>
    requestJson<AppSettings>(
      '/api/settings',
      {
        method: 'PUT',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(settings),
      },
      true,
    ),

  listBackups: () => requestJson<{backups: BackupEntry[]}>('/api/backups'),

  createBackup: () =>
    requestJson<{filename: string; size_bytes: number; verified: boolean}>(
      '/api/backups',
      {method: 'POST'},
      true,
    ),

  restoreBackup: (filename: string) =>
    requestJson<{restored_from: string; record_count: number}>(
      '/api/backups/restore',
      {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({filename}),
      },
      true,
    ),

  resetToSampleDataset: () =>
    requestJson<{message: string; count: number}>(
      '/api/system/reset-sample',
      {method: 'POST'},
      true,
    ),

  getAuditLogs: (limit = 50) =>
    requestJson<{logs: AuditLogEntry[]}>(`/api/audit-logs?limit=${limit}`),

  downloadExport: async (endpoint: string, fallbackFilename: string) => {
    const res = await fetch(endpoint);
    if (!res.ok) {
      throw new ApiError(`Failed to generate download (${res.status}).`, res.status);
    }
    const disposition = res.headers.get('Content-Disposition') || '';
    const match = /filename="([^"]+)"/.exec(disposition);
    const filename = match ? match[1] : fallbackFilename;
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(objectUrl);
  },
};
