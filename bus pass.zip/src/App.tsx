import {useCallback, useEffect, useState} from 'react';
import {
  BarChart3,
  Clock,
  ExternalLink,
  FileSpreadsheet,
  LayoutDashboard,
  List,
  Menu,
  PlusCircle,
  Search,
  Settings,
  X,
} from 'lucide-react';
import {apiClient} from './api/client';
import {PassDetailsModal} from './components/PassDetailsModal';
import {PassForm} from './components/PassForm';
import type {
  AnalyticsData,
  BusPass,
  DashboardSummary,
  ExpiryMonitorData,
} from './types/busPass';
import {AnalyticsView} from './views/AnalyticsView';
import {DashboardView} from './views/DashboardView';
import {ExpiryMonitorView} from './views/ExpiryMonitorView';
import {ImportExportView} from './views/ImportExportView';
import {PassesTableView} from './views/PassesTableView';
import {SettingsView} from './views/SettingsView';

type NavTab =
  | 'dashboard'
  | 'add-pass'
  | 'all-passes'
  | 'expiry-monitor'
  | 'search'
  | 'analytics'
  | 'import-export'
  | 'settings';

const NAV_ITEMS: {id: NavTab; label: string; icon: typeof LayoutDashboard}[] = [
  {id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard},
  {id: 'add-pass', label: 'Add New Pass', icon: PlusCircle},
  {id: 'all-passes', label: 'All Bus Passes', icon: List},
  {id: 'expiry-monitor', label: 'Expiry Monitor', icon: Clock},
  {id: 'search', label: 'Search Records', icon: Search},
  {id: 'analytics', label: 'Analytics & Reports', icon: BarChart3},
  {id: 'import-export', label: 'Import / Export', icon: FileSpreadsheet},
  {id: 'settings', label: 'Settings & Data', icon: Settings},
];

const DEFAULT_CATEGORIES = [
  'Student',
  'General Commuter',
  'Senior Citizen',
  'Employee',
  'Differently Abled',
  'Express Route',
];
const DEFAULT_STATUSES = ['Active', 'Expiring Soon', 'Expires Today', 'Expired'];
const DEFAULT_STORAGE_MODES = ['sqlite+csv+json', 'sqlite+json', 'sqlite+csv', 'sqlite'];

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [categories, setCategories] = useState<string[]>(DEFAULT_CATEGORIES);
  const [statuses, setStatuses] = useState<string[]>(DEFAULT_STATUSES);
  const [storageModes, setStorageModes] = useState<string[]>(DEFAULT_STORAGE_MODES);

  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [summaryLoading, setSummaryLoading] = useState(true);
  const [summaryError, setSummaryError] = useState<string | null>(null);

  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);
  const [analyticsError, setAnalyticsError] = useState<string | null>(null);

  const [monitor, setMonitor] = useState<ExpiryMonitorData | null>(null);
  const [monitorLoading, setMonitorLoading] = useState(false);
  const [monitorError, setMonitorError] = useState<string | null>(null);

  const [refreshSignal, setRefreshSignal] = useState(0);
  const [selectedPass, setSelectedPass] = useState<BusPass | null>(null);
  const [modalEditMode, setModalEditMode] = useState(false);

  const loadMeta = useCallback(async () => {
    try {
      const meta = await apiClient.getMeta();
      if (meta.categories.length > 0) setCategories(meta.categories);
      if (meta.statuses.length > 0) setStatuses(meta.statuses);
      if (meta.storage_modes.length > 0) setStorageModes(meta.storage_modes);
    } catch {
      // Defaults remain valid
    }
  }, []);

  const loadDashboard = useCallback(async () => {
    setSummaryLoading(true);
    setSummaryError(null);
    try {
      const data = await apiClient.getDashboardSummary();
      setSummary(data);
    } catch (err) {
      setSummaryError(err instanceof Error ? err.message : 'Unable to fetch dashboard summary.');
    } finally {
      setSummaryLoading(false);
    }
  }, []);

  const loadAnalytics = useCallback(async () => {
    setAnalyticsLoading(true);
    setAnalyticsError(null);
    try {
      const data = await apiClient.getAnalytics();
      setAnalytics(data);
    } catch (err) {
      setAnalyticsError(err instanceof Error ? err.message : 'Unable to load analytics.');
    } finally {
      setAnalyticsLoading(false);
    }
  }, []);

  const loadMonitor = useCallback(async () => {
    setMonitorLoading(true);
    setMonitorError(null);
    try {
      const data = await apiClient.getExpiryMonitor();
      setMonitor(data);
    } catch (err) {
      setMonitorError(err instanceof Error ? err.message : 'Unable to load expiry monitor.');
    } finally {
      setMonitorLoading(false);
    }
  }, []);

  const refreshAllData = useCallback(() => {
    setRefreshSignal((n) => n + 1);
    void loadDashboard();
    if (activeTab === 'analytics') void loadAnalytics();
    if (activeTab === 'expiry-monitor') void loadMonitor();
  }, [activeTab, loadDashboard, loadAnalytics, loadMonitor]);

  useEffect(() => {
    void loadMeta();
    void loadDashboard();
  }, [loadMeta, loadDashboard]);

  useEffect(() => {
    if (activeTab === 'analytics') {
      void loadAnalytics();
    } else if (activeTab === 'expiry-monitor') {
      void loadMonitor();
    }
  }, [activeTab, loadAnalytics, loadMonitor]);

  const navigateTo = (tab: string) => {
    setActiveTab(tab as NavTab);
    setMobileMenuOpen(false);
  };

  const openPassModal = (pass: BusPass, editMode = false) => {
    setSelectedPass(pass);
    setModalEditMode(editMode);
  };

  const currentNavLabel = NAV_ITEMS.find((n) => n.id === activeTab)?.label || 'Dashboard';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 lg:flex">
      {/* Mobile Sidebar Backdrop */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Left Sidebar Navigation (256px) */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-slate-200 bg-white lg:static lg:translate-x-0 lg:visible lg:pointer-events-auto ${
          mobileMenuOpen
            ? 'translate-x-0 visible pointer-events-auto transition-transform duration-200'
            : '-translate-x-full invisible pointer-events-none'
        }`}
        aria-label="Primary sidebar navigation"
      >
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
          <div className="min-w-0">
            <span className="font-display block truncate text-base font-bold tracking-tight text-slate-900">
              Bus Pass Tracker
            </span>
            <span className="block truncate text-xs text-slate-500">
              Never Miss Your Renewal
            </span>
          </div>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(false)}
            aria-label="Close navigation menu"
            className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 lg:hidden"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => navigateTo(item.id)}
                aria-current={active ? 'page' : undefined}
                className={`flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-teal-50 text-teal-900'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon
                  className={`h-4 w-4 shrink-0 ${active ? 'text-teal-700' : 'text-slate-400'}`}
                  aria-hidden="true"
                />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-200 p-4">
          <a
            href="/docs"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100"
          >
            <span>OpenAPI Reference</span>
            <ExternalLink className="h-3.5 w-3.5 text-slate-400" aria-hidden="true" />
          </a>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Top Bar Contract: Breadcrumb Left · 1 Primary Action Right */}
        <header className="sticky top-0 z-30 flex items-center justify-between gap-4 border-b border-slate-200 bg-white px-4 py-3.5 sm:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation menu"
              className="rounded-md p-1.5 text-slate-600 hover:bg-slate-100 lg:hidden"
            >
              <Menu className="h-5 w-5" aria-hidden="true" />
            </button>
            <div className="flex min-w-0 items-center gap-2 text-sm">
              <span className="hidden font-medium text-slate-500 sm:inline whitespace-nowrap">
                Bus Pass Expiry Tracker
              </span>
              <span className="hidden text-slate-300 sm:inline" aria-hidden="true">/</span>
              <span className="truncate font-semibold text-slate-900">{currentNavLabel}</span>
            </div>
          </div>

          <div className="shrink-0">
            <button
              type="button"
              onClick={() => navigateTo('add-pass')}
              className="inline-flex items-center gap-1.5 rounded-md bg-teal-700 px-3.5 py-2 text-xs font-medium text-white hover:bg-teal-800 whitespace-nowrap"
            >
              <PlusCircle className="h-3.5 w-3.5" aria-hidden="true" />
              Add New Pass
            </button>
          </div>
        </header>

        <main className="mx-auto w-full max-w-[1280px] flex-1 p-4 sm:p-8">
          {activeTab === 'dashboard' && (
            <DashboardView
              summary={summary}
              loading={summaryLoading}
              error={summaryError}
              onRetry={() => void loadDashboard()}
              onNavigate={navigateTo}
              onSelectPass={(p) => openPassModal(p, false)}
            />
          )}

          {activeTab === 'add-pass' && (
            <div className="mx-auto max-w-3xl space-y-5">
              <div>
                <h1 className="text-xl font-semibold text-slate-900">Register New Bus Pass</h1>
                <p className="text-sm text-slate-600">
                  All fields are validated server-side by Python before persistence to SQLite, CSV, and JSON.
                </p>
              </div>
              <div className="rounded-lg border border-slate-200 bg-white p-6">
                <PassForm
                  categories={categories}
                  mode="create"
                  onSubmit={(payload) => apiClient.createPass(payload)}
                  onSuccess={() => refreshAllData()}
                />
              </div>
            </div>
          )}

          {activeTab === 'all-passes' && (
            <PassesTableView
              title="All Bus Passes"
              subtitle="Complete SQLite registry with database-level LIMIT/OFFSET pagination and sorting."
              categories={categories}
              statuses={statuses}
              refreshSignal={refreshSignal}
              onSelectPass={openPassModal}
              onAddNew={() => navigateTo('add-pass')}
            />
          )}

          {activeTab === 'expiry-monitor' && (
            <ExpiryMonitorView
              monitor={monitor}
              loading={monitorLoading}
              error={monitorError}
              onRetry={() => void loadMonitor()}
              onSelectPass={(p) => openPassModal(p, false)}
            />
          )}

          {activeTab === 'search' && (
            <PassesTableView
              title="Search Bus Pass Records"
              subtitle="Combine keyword search, pass category, status, and expiry date ranges."
              categories={categories}
              statuses={statuses}
              showDateRangeFilter
              refreshSignal={refreshSignal}
              onSelectPass={openPassModal}
              onAddNew={() => navigateTo('add-pass')}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsView
              analytics={analytics}
              loading={analyticsLoading}
              error={analyticsError}
              onRetry={() => void loadAnalytics()}
            />
          )}

          {activeTab === 'import-export' && (
            <ImportExportView onDataImported={refreshAllData} />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              storageModes={storageModes}
              onSettingsUpdated={refreshAllData}
            />
          )}
        </main>
      </div>

      {selectedPass && (
        <PassDetailsModal
          pass={selectedPass}
          categories={categories}
          initialEditMode={modalEditMode}
          onClose={() => setSelectedPass(null)}
          onUpdated={(updated) => {
            setSelectedPass(updated);
            refreshAllData();
          }}
          onDeleted={() => {
            setSelectedPass(null);
            refreshAllData();
          }}
        />
      )}
    </div>
  );
}
