import type {
  CategoryDistributionItem,
  MonthlyTrendItem,
  RouteDistributionItem,
  StatusDistributionItem,
} from '../types/busPass';

const STATUS_BAR_COLORS: Record<string, string> = {
  Active: '#15803d',
  'Expiring Soon': '#d97706',
  'Expires Today': '#ea580c',
  Expired: '#dc2626',
};

export function StatusDistributionChart({data}: {data: StatusDistributionItem[]}) {
  const total = data.reduce((acc, item) => acc + item.count, 0);
  if (total === 0) {
    return (
      <div className="flex h-48 items-center justify-center rounded-md border border-dashed border-slate-200 bg-slate-50 text-sm text-slate-500">
        No bus passes stored yet to display status distribution.
      </div>
    );
  }

  const maxCount = Math.max(1, ...data.map((d) => d.count));

  return (
    <div className="space-y-3" data-testid="status-distribution-chart">
      {data.map((item) => {
        const pct = Math.round((item.count / total) * 100);
        const widthPct = Math.max(2, Math.round((item.count / maxCount) * 100));
        return (
          <div key={item.status} className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-700">{item.status}</span>
              <span className="font-mono text-slate-600 tabular-nums">
                {item.count} ({pct}%)
              </span>
            </div>
            <div className="h-3 w-full overflow-hidden rounded bg-slate-100">
              <div
                className="h-full rounded transition-all duration-300"
                style={{
                  width: `${item.count === 0 ? 0 : widthPct}%`,
                  backgroundColor: STATUS_BAR_COLORS[item.status] || '#0f766e',
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function MonthlyExpiryTrendChart({data}: {data: MonthlyTrendItem[]}) {
  const hasAny = data.some((d) => d.count > 0);
  if (!hasAny) {
    return (
      <div className="flex h-48 items-center justify-center rounded-md border border-dashed border-slate-200 bg-slate-50 text-sm text-slate-500">
        Insufficient expiry dates in the 6-month window to chart monthly trends.
      </div>
    );
  }

  const maxCount = Math.max(1, ...data.map((d) => d.count));
  const chartHeight = 160;
  const barWidth = 34;
  const gap = 36;
  const leftPad = 30;
  const svgWidth = leftPad + data.length * (barWidth + gap);

  return (
    <div className="overflow-x-auto" data-testid="monthly-trend-chart">
      <svg
        viewBox={`0 0 ${svgWidth} 210`}
        className="h-52 w-full min-w-[420px]"
        role="img"
        aria-label="Monthly bus pass expiry trend bar chart"
      >
        {[0, 0.5, 1].map((tick) => {
          const y = chartHeight - tick * (chartHeight - 20) + 10;
          const val = Math.round(tick * maxCount);
          return (
            <g key={tick}>
              <line x1={leftPad - 4} x2={svgWidth - 10} y1={y} y2={y} stroke="#e2e8f0" strokeDasharray="3 3" />
              <text x={leftPad - 8} y={y + 4} textAnchor="end" className="fill-slate-400 text-[10px] font-mono">
                {val}
              </text>
            </g>
          );
        })}

        {data.map((item, idx) => {
          const x = leftPad + idx * (barWidth + gap) + 8;
          const totalH = Math.round((item.count / maxCount) * (chartHeight - 24));
          const expiredH = item.count > 0 ? Math.round((item.expired / item.count) * totalH) : 0;
          const upcomingH = totalH - expiredH;
          const baseY = chartHeight + 10;

          return (
            <g key={item.month}>
              {upcomingH > 0 && (
                <rect
                  x={x}
                  y={baseY - upcomingH - expiredH}
                  width={barWidth}
                  height={upcomingH}
                  rx={3}
                  fill="#0f766e"
                />
              )}
              {expiredH > 0 && (
                <rect
                  x={x}
                  y={baseY - expiredH}
                  width={barWidth}
                  height={expiredH}
                  rx={3}
                  fill="#dc2626"
                />
              )}
              <text
                x={x + barWidth / 2}
                y={baseY - totalH - 5}
                textAnchor="middle"
                className="fill-slate-700 text-[10px] font-mono font-semibold"
              >
                {item.count}
              </text>
              <text
                x={x + barWidth / 2}
                y={baseY + 18}
                textAnchor="middle"
                className="fill-slate-500 text-[10px]"
              >
                {item.label}
              </text>
            </g>
          );
        })}
      </svg>
      <div className="mt-2 flex items-center gap-4 text-xs text-slate-600">
        <span className="inline-flex items-center gap-1.5">
          <span className="inline-block h-2.5 w-2.5 rounded-sm bg-teal-700" aria-hidden="true" />
          Upcoming Expiries
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="inline-block h-2.5 w-2.5 rounded-sm bg-red-600" aria-hidden="true" />
          Already Expired
        </span>
      </div>
    </div>
  );
}

export function CategoryBreakdownChart({data}: {data: CategoryDistributionItem[]}) {
  if (!data.length) {
    return (
      <div className="flex h-40 items-center justify-center rounded-md border border-dashed border-slate-200 bg-slate-50 text-sm text-slate-500">
        No category data available.
      </div>
    );
  }
  const max = Math.max(1, ...data.map((d) => d.count));
  return (
    <div className="space-y-3">
      {data.map((cat) => (
        <div key={cat.category} className="space-y-1">
          <div className="flex items-center justify-between text-xs">
            <span className="font-medium text-slate-700">{cat.category}</span>
            <span className="font-mono text-slate-600 tabular-nums">
              {cat.count} passes · {cat.expired} expired
            </span>
          </div>
          <div className="flex h-2.5 w-full overflow-hidden rounded bg-slate-100">
            <div
              className="bg-teal-700"
              style={{width: `${Math.round((cat.active_or_pending / max) * 100)}%`}}
            />
            <div
              className="bg-red-500"
              style={{width: `${Math.round((cat.expired / max) * 100)}%`}}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

export function RouteDistributionList({data}: {data: RouteDistributionItem[]}) {
  if (!data.length) {
    return (
      <div className="flex h-40 items-center justify-center rounded-md border border-dashed border-slate-200 bg-slate-50 text-sm text-slate-500">
        No route data available.
      </div>
    );
  }
  const max = Math.max(1, ...data.map((d) => d.count));
  return (
    <div className="space-y-2.5">
      {data.map((r) => (
        <div key={r.route} className="space-y-1">
          <div className="flex items-center justify-between gap-3 text-xs">
            <span className="truncate font-medium text-slate-700" title={r.route}>
              {r.route}
            </span>
            <span className="font-mono text-slate-600 whitespace-nowrap tabular-nums">
              {r.count} ({r.expired} exp)
            </span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded bg-slate-100">
            <div
              className="h-full rounded bg-slate-700"
              style={{width: `${Math.round((r.count / max) * 100)}%`}}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
