import {useState} from 'react';
import {Edit3, Trash2, X} from 'lucide-react';
import {apiClient} from '../api/client';
import type {BusPass, BusPassPayload} from '../types/busPass';
import {formatCurrency, formatDaysRemaining} from '../utils/formatters';
import {PassForm} from './PassForm';
import {StatusBadge} from './StatusBadge';

interface PassDetailsModalProps {
  pass: BusPass;
  categories: string[];
  initialEditMode?: boolean;
  onClose: () => void;
  onUpdated: (updated: BusPass) => void;
  onDeleted: (passId: string) => void;
}

export function PassDetailsModal({
  pass,
  categories,
  initialEditMode = false,
  onClose,
  onUpdated,
  onDeleted,
}: PassDetailsModalProps) {
  const [editing, setEditing] = useState(initialEditMode);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const handleDelete = async () => {
    setDeleting(true);
    setDeleteError(null);
    try {
      await apiClient.deletePass(pass.pass_id);
      onDeleted(pass.pass_id);
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : 'Failed to delete bus pass.');
      setDeleting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pass-detail-title"
    >
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-lg border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div className="flex flex-wrap items-center gap-3">
            <h2 id="pass-detail-title" className="font-mono text-lg font-semibold text-slate-900">
              {pass.pass_id}
            </h2>
            <StatusBadge status={pass.status} />
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close pass details dialog"
            className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <div className="p-6">
          {editing ? (
            <PassForm
              categories={categories}
              mode="edit"
              initialPass={pass}
              onSubmit={(payload: BusPassPayload) =>
                apiClient.updatePass(pass.pass_id, {
                  holder_name: payload.holder_name,
                  mobile_number: payload.mobile_number,
                  route: payload.route,
                  category: payload.category,
                  issue_date: payload.issue_date,
                  expiry_date: payload.expiry_date,
                  fee: payload.fee,
                  notes: payload.notes,
                })
              }
              onSuccess={(updated) => {
                onUpdated(updated);
                setEditing(false);
              }}
              onCancel={() => setEditing(false)}
            />
          ) : (
            <div className="space-y-6">
              <dl className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="border-b border-slate-100 pb-3">
                  <dt className="text-xs font-medium text-slate-500">Pass Holder</dt>
                  <dd className="mt-1 text-sm font-medium text-slate-900">{pass.holder_name}</dd>
                </div>
                <div className="border-b border-slate-100 pb-3">
                  <dt className="text-xs font-medium text-slate-500">Mobile Number</dt>
                  <dd className="mt-1 font-mono text-sm text-slate-900">{pass.mobile_number}</dd>
                </div>
                <div className="border-b border-slate-100 pb-3 sm:col-span-2">
                  <dt className="text-xs font-medium text-slate-500">Bus Route</dt>
                  <dd className="mt-1 text-sm text-slate-900">{pass.route}</dd>
                </div>
                <div className="border-b border-slate-100 pb-3">
                  <dt className="text-xs font-medium text-slate-500">Category</dt>
                  <dd className="mt-1 text-sm text-slate-900">{pass.category}</dd>
                </div>
                <div className="border-b border-slate-100 pb-3">
                  <dt className="text-xs font-medium text-slate-500">Pass Fee</dt>
                  <dd className="mt-1 font-mono text-sm text-slate-900">{formatCurrency(pass.fee)}</dd>
                </div>
                <div className="border-b border-slate-100 pb-3">
                  <dt className="text-xs font-medium text-slate-500">Issue Date</dt>
                  <dd className="mt-1 font-mono text-sm text-slate-900">{pass.issue_date}</dd>
                </div>
                <div className="border-b border-slate-100 pb-3">
                  <dt className="text-xs font-medium text-slate-500">Expiry Date</dt>
                  <dd className="mt-1 font-mono text-sm text-slate-900">{pass.expiry_date}</dd>
                </div>
                <div className="border-b border-slate-100 pb-3">
                  <dt className="text-xs font-medium text-slate-500">Remaining Validity</dt>
                  <dd className="mt-1 font-mono text-sm font-semibold text-slate-900">
                    {formatDaysRemaining(pass.days_remaining)} · Urgency: {pass.urgency}
                  </dd>
                </div>
                <div className="border-b border-slate-100 pb-3">
                  <dt className="text-xs font-medium text-slate-500">Recommended Renewal Deadline</dt>
                  <dd className="mt-1 font-mono text-sm text-slate-900">{pass.renewal_deadline}</dd>
                </div>
                <div className="sm:col-span-2">
                  <dt className="text-xs font-medium text-slate-500">Notes</dt>
                  <dd className="mt-1 text-sm text-slate-700">{pass.notes || 'No additional notes recorded.'}</dd>
                </div>
              </dl>

              {deleteError && (
                <p className="rounded border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-800">
                  {deleteError}
                </p>
              )}

              {confirmDelete ? (
                <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-red-200 bg-red-50 p-4">
                  <p className="text-sm font-medium text-red-900">
                    Confirm permanent deletion of pass {pass.pass_id}?
                  </p>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setConfirmDelete(false)}
                      className="rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
                    >
                      Keep Record
                    </button>
                    <button
                      type="button"
                      disabled={deleting}
                      onClick={handleDelete}
                      className="rounded-md bg-red-700 px-3 py-1.5 text-xs font-medium text-white hover:bg-red-800 disabled:opacity-60"
                    >
                      {deleting ? 'Deleting...' : 'Confirm Delete'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 pt-4">
                  <button
                    type="button"
                    onClick={() => setConfirmDelete(true)}
                    className="inline-flex items-center gap-1.5 rounded-md border border-red-200 bg-white px-4 py-2 text-sm font-medium text-red-700 hover:bg-red-50 whitespace-nowrap"
                  >
                    <Trash2 className="h-4 w-4" aria-hidden="true" />
                    Delete Pass
                  </button>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setEditing(true)}
                      className="inline-flex items-center gap-1.5 rounded-md bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800 whitespace-nowrap"
                    >
                      <Edit3 className="h-4 w-4" aria-hidden="true" />
                      Edit Pass
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
