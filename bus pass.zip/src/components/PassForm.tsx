import {useState, type FormEvent} from 'react';
import {AlertCircle, CheckCircle2, RotateCcw} from 'lucide-react';
import {ApiError} from '../api/client';
import type {BusPass, BusPassPayload} from '../types/busPass';

interface PassFormProps {
  categories: string[];
  mode: 'create' | 'edit';
  initialPass?: BusPass;
  onSubmit: (payload: BusPassPayload) => Promise<BusPass>;
  onSuccess?: (saved: BusPass) => void;
  onCancel?: () => void;
}

const EMPTY_FORM: BusPassPayload = {
  pass_id: '',
  holder_name: '',
  mobile_number: '',
  route: '',
  category: 'Student',
  issue_date: '',
  expiry_date: '',
  fee: '0',
  notes: '',
};

export function PassForm({
  categories,
  mode,
  initialPass,
  onSubmit,
  onSuccess,
  onCancel,
}: PassFormProps) {
  const [form, setForm] = useState<BusPassPayload>(() =>
    initialPass
      ? {
          pass_id: initialPass.pass_id,
          holder_name: initialPass.holder_name,
          mobile_number: initialPass.mobile_number,
          route: initialPass.route,
          category: initialPass.category,
          issue_date: initialPass.issue_date,
          expiry_date: initialPass.expiry_date,
          fee: String(initialPass.fee),
          notes: initialPass.notes || '',
        }
      : {
          ...EMPTY_FORM,
          category: categories[0] || 'Student',
        },
  );

  const [submitting, setSubmitting] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [bannerError, setBannerError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const updateField = (key: keyof BusPassPayload, value: string) => {
    setForm((prev) => ({...prev, [key]: value}));
    if (fieldErrors[key]) {
      setFieldErrors((prev) => {
        const next = {...prev};
        delete next[key];
        return next;
      });
    }
    if (bannerError) {
      setBannerError(null);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setFieldErrors({});
    setBannerError(null);
    setSuccessMsg(null);

    try {
      const saved = await onSubmit(form);
      setSuccessMsg(
        mode === 'create'
          ? `Registered bus pass ${saved.pass_id} (${saved.status}, ${saved.days_remaining} days remaining).`
          : `Updated bus pass ${saved.pass_id} (${saved.status}).`,
      );
      if (mode === 'create') {
        setForm({...EMPTY_FORM, category: categories[0] || 'Student'});
      }
      onSuccess?.(saved);
    } catch (err) {
      if (err instanceof ApiError) {
        setBannerError(err.message);
        setFieldErrors(err.fieldErrors || {});
      } else {
        setBannerError('Unable to reach the Python backend. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleReset = () => {
    setFieldErrors({});
    setBannerError(null);
    setSuccessMsg(null);
    if (initialPass) {
      setForm({
        pass_id: initialPass.pass_id,
        holder_name: initialPass.holder_name,
        mobile_number: initialPass.mobile_number,
        route: initialPass.route,
        category: initialPass.category,
        issue_date: initialPass.issue_date,
        expiry_date: initialPass.expiry_date,
        fee: String(initialPass.fee),
        notes: initialPass.notes || '',
      });
    } else {
      setForm({...EMPTY_FORM, category: categories[0] || 'Student'});
    }
  };

  const inputClass = (field: string) =>
    `mt-1.5 block w-full rounded-md border px-3 py-2 text-sm text-slate-900 bg-white focus:outline-none focus:ring-2 ${
      fieldErrors[field]
        ? 'border-red-400 focus:border-red-500 focus:ring-red-200'
        : 'border-slate-300 focus:border-teal-600 focus:ring-teal-600/20'
    }`;

  return (
    <form onSubmit={handleSubmit} noValidate className="space-y-6">
      {bannerError && (
        <div
          role="alert"
          className="flex items-start gap-2.5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-900"
        >
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" aria-hidden="true" />
          <div>
            <p className="font-medium">Validation Error</p>
            <p className="text-red-800">{bannerError}</p>
          </div>
        </div>
      )}

      {successMsg && (
        <div
          role="status"
          className="flex items-start gap-2.5 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-900"
        >
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
          <div>
            <p className="font-medium">Saved to SQLite Registry</p>
            <p className="text-emerald-800">{successMsg}</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        <div>
          <label htmlFor="pass_id" className="block text-sm font-medium text-slate-700">
            Pass ID <span className="text-red-600">*</span>
          </label>
          <input
            id="pass_id"
            name="pass_id"
            type="text"
            value={form.pass_id}
            disabled={mode === 'edit'}
            onChange={(e) => updateField('pass_id', e.target.value)}
            placeholder="e.g., BP-2026-101"
            className={`${inputClass('pass_id')} font-mono uppercase disabled:bg-slate-100 disabled:text-slate-500`}
          />
          {fieldErrors.pass_id && (
            <p className="mt-1 text-xs text-red-700">{fieldErrors.pass_id}</p>
          )}
        </div>

        <div>
          <label htmlFor="holder_name" className="block text-sm font-medium text-slate-700">
            Pass Holder Full Name <span className="text-red-600">*</span>
          </label>
          <input
            id="holder_name"
            name="holder_name"
            type="text"
            value={form.holder_name}
            onChange={(e) => updateField('holder_name', e.target.value)}
            placeholder="e.g., Aarav Sharma"
            className={inputClass('holder_name')}
          />
          {fieldErrors.holder_name && (
            <p className="mt-1 text-xs text-red-700">{fieldErrors.holder_name}</p>
          )}
        </div>

        <div>
          <label htmlFor="mobile_number" className="block text-sm font-medium text-slate-700">
            Mobile Number <span className="text-red-600">*</span>
          </label>
          <input
            id="mobile_number"
            name="mobile_number"
            type="tel"
            value={form.mobile_number}
            onChange={(e) => updateField('mobile_number', e.target.value)}
            placeholder="e.g., +919876543210"
            className={`${inputClass('mobile_number')} font-mono`}
          />
          {fieldErrors.mobile_number && (
            <p className="mt-1 text-xs text-red-700">{fieldErrors.mobile_number}</p>
          )}
        </div>

        <div>
          <label htmlFor="category" className="block text-sm font-medium text-slate-700">
            Pass Category <span className="text-red-600">*</span>
          </label>
          <select
            id="category"
            name="category"
            value={form.category}
            onChange={(e) => updateField('category', e.target.value)}
            className={inputClass('category')}
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
          {fieldErrors.category && (
            <p className="mt-1 text-xs text-red-700">{fieldErrors.category}</p>
          )}
        </div>

        <div className="md:col-span-2">
          <label htmlFor="route" className="block text-sm font-medium text-slate-700">
            Bus Route / Corridor <span className="text-red-600">*</span>
          </label>
          <input
            id="route"
            name="route"
            type="text"
            value={form.route}
            onChange={(e) => updateField('route', e.target.value)}
            placeholder="e.g., Route 101 - Central Station to University Campus"
            className={inputClass('route')}
          />
          {fieldErrors.route && (
            <p className="mt-1 text-xs text-red-700">{fieldErrors.route}</p>
          )}
        </div>

        <div>
          <label htmlFor="issue_date" className="block text-sm font-medium text-slate-700">
            Issue Date <span className="text-red-600">*</span>
          </label>
          <input
            id="issue_date"
            name="issue_date"
            type="date"
            value={form.issue_date}
            onChange={(e) => updateField('issue_date', e.target.value)}
            className={`${inputClass('issue_date')} font-mono`}
          />
          {fieldErrors.issue_date && (
            <p className="mt-1 text-xs text-red-700">{fieldErrors.issue_date}</p>
          )}
        </div>

        <div>
          <label htmlFor="expiry_date" className="block text-sm font-medium text-slate-700">
            Expiry Date <span className="text-red-600">*</span>
          </label>
          <input
            id="expiry_date"
            name="expiry_date"
            type="date"
            value={form.expiry_date}
            onChange={(e) => updateField('expiry_date', e.target.value)}
            className={`${inputClass('expiry_date')} font-mono`}
          />
          {fieldErrors.expiry_date && (
            <p className="mt-1 text-xs text-red-700">{fieldErrors.expiry_date}</p>
          )}
        </div>

        <div>
          <label htmlFor="fee" className="block text-sm font-medium text-slate-700">
            Pass Amount / Fee
          </label>
          <input
            id="fee"
            name="fee"
            type="text"
            inputMode="decimal"
            value={form.fee}
            onChange={(e) => updateField('fee', e.target.value)}
            placeholder="0.00"
            className={`${inputClass('fee')} font-mono`}
          />
          {fieldErrors.fee && (
            <p className="mt-1 text-xs text-red-700">{fieldErrors.fee}</p>
          )}
        </div>

        <div>
          <label htmlFor="notes" className="block text-sm font-medium text-slate-700">
            Additional Notes
          </label>
          <input
            id="notes"
            name="notes"
            type="text"
            value={form.notes}
            onChange={(e) => updateField('notes', e.target.value)}
            placeholder="Optional concession or renewal note"
            className={inputClass('notes')}
          />
          {fieldErrors.notes && (
            <p className="mt-1 text-xs text-red-700">{fieldErrors.notes}</p>
          )}
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-end gap-3 border-t border-slate-200 pt-4">
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-teal-700 whitespace-nowrap"
          >
            Cancel
          </button>
        )}
        <button
          type="button"
          onClick={handleReset}
          className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-teal-700 whitespace-nowrap"
        >
          <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
          Reset
        </button>
        <button
          type="submit"
          disabled={submitting}
          className="rounded-md bg-teal-700 px-5 py-2 text-sm font-medium text-white hover:bg-teal-800 disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-teal-700 whitespace-nowrap"
        >
          {submitting
            ? 'Validating & Saving...'
            : mode === 'create'
              ? 'Register Bus Pass'
              : 'Save Changes'}
        </button>
      </div>
    </form>
  );
}
