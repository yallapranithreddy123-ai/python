import {AlertTriangle, CheckCircle2, Clock, XCircle} from 'lucide-react';
import type {PassStatus} from '../types/busPass';

interface StatusBadgeProps {
  status: PassStatus;
}

const STATUS_STYLE: Record<PassStatus, string> = {
  Active: 'bg-emerald-50 text-emerald-800 border-emerald-200',
  'Expiring Soon': 'bg-amber-50 text-amber-800 border-amber-200',
  'Expires Today': 'bg-orange-50 text-orange-800 border-orange-200',
  Expired: 'bg-red-50 text-red-800 border-red-200',
};

export function StatusBadge({status}: StatusBadgeProps) {
  const style = STATUS_STYLE[status] || 'bg-slate-100 text-slate-700 border-slate-200';
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded border px-2 py-0.5 text-xs font-medium whitespace-nowrap ${style}`}
    >
      {status === 'Active' && <CheckCircle2 className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />}
      {status === 'Expiring Soon' && <Clock className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />}
      {status === 'Expires Today' && <AlertTriangle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />}
      {status === 'Expired' && <XCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />}
      <span>{status}</span>
    </span>
  );
}
