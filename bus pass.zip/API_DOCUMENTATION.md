# API Documentation (OpenAPI 3.0.3)

Interactive OpenAPI documentation is served directly by the Python backend:
- **Interactive Explorer**: `/docs`
- **OpenAPI JSON Spec**: `/openapi.json`

## CSRF Token Requirement

All state-changing requests (`POST`, `PUT`, `DELETE`) require a valid HMAC-signed `X-CSRF-Token` header issued by:

```http
GET /api/csrf-token
```

Response (`200 OK`):
```json
{ "csrf_token": "1795526761.a1b2c3...signature" }
```

## Endpoints Reference

### Bus Passes CRUD & Search

| Method | Endpoint | Purpose | Status Codes |
| --- | --- | --- | --- |
| `GET` | `/api/passes` | List passes with SQLite `LIMIT`/`OFFSET` pagination | `200`, `400` |
| `POST` | `/api/passes` | Register a validated bus pass | `201`, `403`, `409`, `422` |
| `GET` | `/api/passes/{pass_id}` | Fetch single pass details + computed expiry | `200`, `404` |
| `PUT` | `/api/passes/{pass_id}` | Update an existing bus pass | `200`, `403`, `404`, `422` |
| `DELETE` | `/api/passes/{pass_id}` | Delete a bus pass | `200`, `403`, `404` |
| `GET` | `/api/search` | Multi-criteria search (`q`, `category`, `status`, `expiry_from`, `expiry_to`, `page`, `page_size`) | `200`, `400` |

### Monitoring, Analytics & Reports

| Method | Endpoint | Purpose | Status Codes |
| --- | --- | --- | --- |
| `GET` | `/api/dashboard/summary` | Dashboard KPIs, warnings, recent additions, trend data | `200` |
| `GET` | `/api/expiry/upcoming` | Passes expiring today and within warning threshold | `200` |
| `GET` | `/api/expiry/expired` | Expired passes sorted by most recently overdue | `200` |
| `GET` | `/api/analytics` | Full category, route, status & monthly analytics | `200` |
| `GET` | `/api/analytics/chart?type=status` | Matplotlib PNG chart (`501` if Matplotlib absent) | `200`, `501` |
| `GET` | `/api/reports/markdown` | Download Markdown executive summary report | `200` |
| `GET` | `/api/reports/audit` | Download plain-text audit trail report | `200` |
| `GET` | `/api/reports/csv` | Download status-enriched CSV report | `200` |

### Import, Export, Backups & Settings

| Method | Endpoint | Purpose | Status Codes |
| --- | --- | --- | --- |
| `POST` | `/api/import/csv` | Bulk CSV upload with row-by-row validation diagnostics | `200`, `400`, `403` |
| `POST` | `/api/import/json` | Bulk JSON upload with schema validation | `200`, `400`, `403` |
| `GET` | `/api/export/csv` | Export all records as standardized CSV | `200` |
| `GET` | `/api/export/json` | Export all records as schema-versioned JSON | `200` |
| `GET` / `PUT` | `/api/settings` | Read or update warning threshold, sync mode, page size | `200`, `403`, `422` |
| `GET` / `POST` | `/api/backups` | List or create integrity-verified SQLite backup | `200`, `201`, `403` |
| `POST` | `/api/backups/restore` | Restore SQLite database from verified backup | `200`, `400`, `403`, `404` |
| `GET` | `/api/audit-logs` | Retrieve recent audit trail records | `200` |
| `GET` | `/api/health` | Health check + SQLite `PRAGMA integrity_check` | `200` |

## Example Error Envelope (`422 Unprocessable Entity`)

```json
{
  "error": "One or more bus pass fields failed validation.",
  "code": 422,
  "field_errors": {
    "expiry_date": "Expiry date cannot be earlier than the issue date."
  }
}
```
