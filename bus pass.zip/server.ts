import 'dotenv/config';
import {spawn, type ChildProcess} from 'node:child_process';
import http from 'node:http';
import path from 'node:path';
import express, {type Request, type Response} from 'express';

const PORT = Number(process.env.PORT || 3000);
const PYTHON_PORT = Number(process.env.PYTHON_BACKEND_PORT || 5050);
const PYTHON_HOST = '127.0.0.1';
const IS_PROD = process.env.NODE_ENV === 'production';

let pythonProc: ChildProcess | null = null;

function startPythonBackend(): ChildProcess {
  const proc = spawn('python3', ['app.py', '--host', PYTHON_HOST, '--port', String(PYTHON_PORT)], {
    cwd: process.cwd(),
    stdio: ['ignore', 'pipe', 'pipe'],
    env: {...process.env},
  });

  proc.stdout?.on('data', (chunk: Buffer) => {
    process.stdout.write(`[python] ${chunk.toString()}`);
  });
  proc.stderr?.on('data', (chunk: Buffer) => {
    process.stderr.write(`[python] ${chunk.toString()}`);
  });
  proc.on('exit', (code) => {
    console.error(`[python] process exited with code ${code}`);
  });
  return proc;
}

async function waitForPythonReady(timeoutMs = 15000): Promise<void> {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const ok = await new Promise<boolean>((resolve) => {
        const req = http.get(
          {host: PYTHON_HOST, port: PYTHON_PORT, path: '/api/health', timeout: 1000},
          (res) => {
            res.resume();
            resolve(res.statusCode === 200);
          },
        );
        req.on('error', () => resolve(false));
        req.on('timeout', () => {
          req.destroy();
          resolve(false);
        });
      });
      if (ok) {
        return;
      }
    } catch {
      // keep polling until backend is up
    }
    await new Promise((r) => setTimeout(r, 150));
  }
  throw new Error('Python backend failed to become healthy within startup timeout.');
}

function proxyToPython(req: Request, res: Response): void {
  const proxyHeaders: http.OutgoingHttpHeaders = {...req.headers};
  delete proxyHeaders.host;
  delete proxyHeaders.connection;

  const upstream = http.request(
    {
      host: PYTHON_HOST,
      port: PYTHON_PORT,
      path: req.originalUrl,
      method: req.method,
      headers: proxyHeaders,
    },
    (upstreamRes) => {
      res.status(upstreamRes.statusCode || 502);
      for (const [key, val] of Object.entries(upstreamRes.headers)) {
        if (val !== undefined && key.toLowerCase() !== 'transfer-encoding') {
          res.setHeader(key, val);
        }
      }
      upstreamRes.pipe(res);
    },
  );

  upstream.on('error', (err) => {
    if (!res.headersSent) {
      res.status(502).json({
        error: 'Python backend service unavailable.',
        detail: err.message,
      });
    }
  });

  req.pipe(upstream);
}

async function bootstrap(): Promise<void> {
  pythonProc = startPythonBackend();
  await waitForPythonReady();

  const app = express();

  app.use((req, res, next) => {
    if (
      req.path.startsWith('/api/') ||
      req.path === '/openapi.json' ||
      req.path === '/docs'
    ) {
      proxyToPython(req, res);
      return;
    }
    next();
  });

  if (!IS_PROD) {
    const {createServer: createViteServer} = await import('vite');
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Bus Pass Expiry Tracker listening on http://0.0.0.0:${PORT}`);
  });

  const shutdown = () => {
    server.close();
    if (pythonProc && !pythonProc.killed) {
      pythonProc.kill('SIGTERM');
    }
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

bootstrap().catch((err) => {
  console.error('Failed to start server:', err);
  if (pythonProc && !pythonProc.killed) {
    pythonProc.kill('SIGTERM');
  }
  process.exit(1);
});
