"""Python analytics, executive summary, and optional Matplotlib visualization service."""

from __future__ import annotations

import io
from collections import Counter, defaultdict
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional

from backend.expiry import ExpiryService
from backend.models import PASS_STATUSES, BusPass
from backend.repository import BusPassRepository, SettingsRepository


class AnalyticsService:
    """Computes real summary metrics, distributions, forecasts, and threshold warnings."""

    def __init__(self, pass_repo: BusPassRepository, settings_repo: SettingsRepository) -> None:
        self.pass_repo = pass_repo
        self.settings_repo = settings_repo

    def get_dashboard_summary(self, reference_date: Optional[date] = None) -> Dict[str, Any]:
        """Compute executive KPI summary, recent additions, and prioritized warnings."""
        today = reference_date or date.today()
        settings = self.settings_repo.get()
        warning_days = settings.expiry_warning_days

        all_passes = self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC")
        enriched = ExpiryService.enrich_many(all_passes, warning_days=warning_days, reference_date=today)

        status_counts: Counter[str] = Counter(p.status or "Active" for p in enriched)
        active_count = status_counts.get("Active", 0)
        expiring_soon_count = status_counts.get("Expiring Soon", 0)
        expires_today_count = status_counts.get("Expires Today", 0)
        expired_count = status_counts.get("Expired", 0)
        total_passes = len(enriched)

        non_expired_days = [p.days_remaining for p in enriched if p.days_remaining is not None and p.days_remaining >= 0]
        all_days = [p.days_remaining for p in enriched if p.days_remaining is not None]
        avg_remaining_active = round(sum(non_expired_days) / len(non_expired_days), 1) if non_expired_days else 0.0
        avg_remaining_all = round(sum(all_days) / len(all_days), 1) if all_days else 0.0

        total_fees = round(sum(float(p.fee) for p in enriched), 2)
        avg_fee = round(total_fees / total_passes, 2) if total_passes else 0.0

        # Recent additions (sorted by created_at DESC)
        recent = sorted(enriched, key=lambda p: (p.created_at or "", p.id or 0), reverse=True)[:5]

        # Upcoming notifications (Expires Today + Expiring Soon, sorted nearest first)
        upcoming_alerts = [
            p for p in enriched if p.status in {"Expires Today", "Expiring Soon"}
        ]
        upcoming_alerts.sort(key=lambda p: (p.days_remaining if p.days_remaining is not None else 0, p.pass_id))

        # Threshold warnings & anomaly indicators
        warnings = self._build_threshold_warnings(enriched, warning_days)

        return {
            "current_date": today.strftime("%Y-%m-%d"),
            "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "warning_days": warning_days,
            "storage_sync_mode": settings.storage_sync_mode,
            "kpis": {
                "total_passes": total_passes,
                "total_stored": total_passes,
                "active_passes": active_count,
                "expiring_soon": expiring_soon_count,
                "expires_today": expires_today_count,
                "expired_passes": expired_count,
                "avg_remaining_days_active": avg_remaining_active,
                "avg_remaining_days_all": avg_remaining_all,
                "total_fee_collected": total_fees,
                "average_fee": avg_fee,
            },
            "status_distribution": [
                {"status": status, "count": status_counts.get(status, 0)}
                for status in PASS_STATUSES
            ],
            "monthly_expiry_trend": self._compute_monthly_trend(enriched, today),
            "upcoming_notifications": [p.to_api_dict() for p in upcoming_alerts[:10]],
            "recent_additions": [p.to_api_dict() for p in recent],
            "warnings": warnings,
        }

    def get_full_analytics(self, reference_date: Optional[date] = None) -> Dict[str, Any]:
        """Compute complete analytics payload including category and route breakdowns."""
        today = reference_date or date.today()
        settings = self.settings_repo.get()
        warning_days = settings.expiry_warning_days
        summary = self.get_dashboard_summary(reference_date=today)

        all_passes = ExpiryService.enrich_many(
            self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC"),
            warning_days=warning_days,
            reference_date=today,
        )

        cat_counts: Counter[str] = Counter(p.category for p in all_passes)
        cat_fees: Dict[str, float] = defaultdict(float)
        cat_active: Counter[str] = Counter()
        cat_expired: Counter[str] = Counter()

        route_counts: Counter[str] = Counter()
        route_expired: Counter[str] = Counter()

        for p in all_passes:
            cat_fees[p.category] += float(p.fee)
            if p.status == "Expired":
                cat_expired[p.category] += 1
                route_expired[p.route] += 1
            else:
                cat_active[p.category] += 1
            route_counts[p.route] += 1

        category_breakdown = [
            {
                "category": cat,
                "count": count,
                "active_or_pending": cat_active[cat],
                "expired": cat_expired[cat],
                "total_fee": round(cat_fees[cat], 2),
                "avg_fee": round(cat_fees[cat] / count, 2) if count else 0.0,
            }
            for cat, count in cat_counts.most_common()
        ]

        route_breakdown = [
            {
                "route": route,
                "count": count,
                "expired": route_expired[route],
                "active_or_pending": count - route_expired[route],
            }
            for route, count in route_counts.most_common(12)
        ]

        active_vs_expired = {
            "active_and_valid": summary["kpis"]["active_passes"]
            + summary["kpis"]["expiring_soon"]
            + summary["kpis"]["expires_today"],
            "expired": summary["kpis"]["expired_passes"],
        }

        return {
            **summary,
            "active_vs_expired": active_vs_expired,
            "category_distribution": category_breakdown,
            "route_distribution": route_breakdown,
            "matplotlib_available": self.is_matplotlib_available(),
        }

    @staticmethod
    def _compute_monthly_trend(enriched: List[BusPass], today: date) -> List[Dict[str, Any]]:
        """Aggregate expiries across a 6-month rolling window centered around current month."""
        month_buckets: Dict[str, Dict[str, Any]] = {}
        # Generate 6 months starting from 1 month ago through +4 months ahead
        start_month_index = today.year * 12 + (today.month - 1) - 1
        for offset in range(6):
            idx = start_month_index + offset
            year = idx // 12
            month = (idx % 12) + 1
            ym_key = f"{year:04d}-{month:02d}"
            label = date(year, month, 1).strftime("%b %Y")
            month_buckets[ym_key] = {"month": ym_key, "label": label, "count": 0, "expired": 0, "upcoming": 0}

        for p in enriched:
            ym = p.expiry_date[:7]
            if ym in month_buckets:
                month_buckets[ym]["count"] += 1
                if p.status == "Expired":
                    month_buckets[ym]["expired"] += 1
                else:
                    month_buckets[ym]["upcoming"] += 1

        return list(month_buckets.values())

    @staticmethod
    def _build_threshold_warnings(enriched: List[BusPass], warning_days: int) -> List[Dict[str, str]]:
        """Generate actionable warning indicators for dashboard & expiry monitor."""
        warnings: List[Dict[str, str]] = []
        today_list = [p for p in enriched if p.status == "Expires Today"]
        soon_list = [p for p in enriched if p.status == "Expiring Soon"]
        expired_list = [p for p in enriched if p.status == "Expired"]
        zero_fee = [p for p in enriched if float(p.fee) == 0.0 and p.category in {"Employee", "General Commuter", "Express Route"}]

        if today_list:
            warnings.append(
                {
                    "severity": "critical",
                    "code": "EXPIRES_TODAY",
                    "title": f"{len(today_list)} pass(es) expire today",
                    "message": "Immediate renewal is required today to avoid travel disruption.",
                }
            )
        if soon_list:
            warnings.append(
                {
                    "severity": "warning",
                    "code": "EXPIRING_SOON",
                    "title": f"{len(soon_list)} pass(es) within {warning_days}-day threshold",
                    "message": f"Passes expiring within the next {warning_days} days should be scheduled for renewal.",
                }
            )
        if expired_list:
            warnings.append(
                {
                    "severity": "danger",
                    "code": "OVERDUE_PASSES",
                    "title": f"{len(expired_list)} overdue/expired pass(es) in registry",
                    "message": "Expired passes remain stored for auditability and require renewal or archival review.",
                }
            )
        if len(expired_list) > max(5, len(enriched) // 2) and len(enriched) > 0:
            warnings.append(
                {
                    "severity": "danger",
                    "code": "CRITICAL_EXPIRED_RATIO",
                    "title": "High expired pass ratio (>50%)",
                    "message": "More than half of stored passes are expired. Consider running a renewal outreach export.",
                }
            )
        if zero_fee:
            warnings.append(
                {
                    "severity": "info",
                    "code": "ZERO_FEE_ANOMALY",
                    "title": f"{len(zero_fee)} commercial/employee pass(es) with 0.00 fee",
                    "message": "Verify whether zero-fee entries reflect subsidized waivers or missing fee data.",
                }
            )
        return warnings

    @staticmethod
    def is_matplotlib_available() -> bool:
        try:
            import matplotlib  # noqa: F401
            return True
        except ImportError:
            return False

    def generate_matplotlib_chart(self, chart_type: str = "status") -> Optional[bytes]:
        """Render a PNG chart via Matplotlib if installed, returning PNG bytes or None."""
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ImportError:
            return None

        analytics = self.get_full_analytics()
        fig, ax = plt.subplots(figsize=(7.5, 4.2), dpi=140)
        fig.patch.set_facecolor("#FFFFFF")
        ax.set_facecolor("#F8FAFC")

        if chart_type == "monthly":
            trend = analytics["monthly_expiry_trend"]
            labels = [item["label"] for item in trend]
            counts = [item["count"] for item in trend]
            ax.bar(labels, counts, color="#0F766E", width=0.55)
            ax.set_title("Monthly Bus Pass Expiry Trend", fontsize=12, fontweight="bold", color="#0F172A")
            ax.set_ylabel("Passes Expiring")
            plt.xticks(rotation=20, ha="right")
        elif chart_type == "category":
            cats = analytics["category_distribution"]
            labels = [c["category"] for c in cats] or ["No Data"]
            counts = [c["count"] for c in cats] or [0]
            ax.barh(labels, counts, color="#1D4ED8")
            ax.set_title("Passes by Category", fontsize=12, fontweight="bold", color="#0F172A")
            ax.set_xlabel("Pass Count")
        else:
            dist = analytics["status_distribution"]
            labels = [d["status"] for d in dist]
            counts = [d["count"] for d in dist]
            colors = ["#15803D", "#D97706", "#EA580C", "#DC2626"]
            ax.bar(labels, counts, color=colors, width=0.55)
            ax.set_title("Bus Pass Status Distribution", fontsize=12, fontweight="bold", color="#0F172A")
            ax.set_ylabel("Number of Passes")

        ax.grid(axis="y", linestyle="--", alpha=0.4)
        plt.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png")
        plt.close(fig)
        buf.seek(0)
        return buf.read()
