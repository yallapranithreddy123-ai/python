"""Atomic CSV/JSON persistence, .bak backup preservation, and corruption recovery."""

from __future__ import annotations

import csv
import io
import json
import os
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

from backend.models import CSV_FIELDNAMES, BusPass
from backend.validation import ValidationService
from config import AppConfig


class CorruptedStorageError(ValueError):
    """Raised when a CSV or JSON file is malformed or fails schema validation."""


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class FilePersistenceService:
    """Handles atomic flat-file writes, schema validation, and corruption quarantine."""

    def __init__(self, config: AppConfig) -> None:
        self.config = config

    @staticmethod
    def atomic_write_text(target_path: Path, content: str, create_bak: bool = True) -> None:
        """Write text to a temp file, flush/fsync, preserve .bak, and replace atomically."""
        target_path.parent.mkdir(parents=True, exist_ok=True)
        if create_bak and target_path.exists():
            bak_path = target_path.with_name(f"{target_path.name}.bak")
            shutil.copy2(str(target_path), str(bak_path))

        fd, tmp_name = tempfile.mkstemp(
            prefix=f".{target_path.name}.",
            suffix=".tmp",
            dir=str(target_path.parent),
        )
        tmp_path = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(str(tmp_path), str(target_path))
        except Exception:
            if tmp_path.exists():
                tmp_path.unlink(missing_ok=True)
            raise

    @staticmethod
    def quarantine_corrupted_file(file_path: Path) -> Path | None:
        """Move corrupted storage file to a timestamped quarantine filename without overwriting it."""
        if not file_path.exists():
            return None
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        quarantined = file_path.with_name(f"{file_path.stem}.corrupted.{ts}{file_path.suffix}")
        shutil.move(str(file_path), str(quarantined))
        return quarantined

    def serialize_csv(self, passes: List[BusPass]) -> str:
        """Serialize BusPass records into standardized CSV text."""
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=list(CSV_FIELDNAMES), lineterminator="\n")
        writer.writeheader()
        for item in passes:
            writer.writerow(item.to_storage_dict())
        return output.getvalue()

    def serialize_json(self, passes: List[BusPass]) -> str:
        """Serialize BusPass records into schema-versioned JSON text."""
        payload = {
            "schema_version": 1,
            "generated_at": _utc_now_iso(),
            "record_count": len(passes),
            "records": [item.to_storage_dict() for item in passes],
        }
        return json.dumps(payload, indent=2, ensure_ascii=False) + "\n"

    def sync_files(self, passes: List[BusPass], mode: str = "sqlite+csv+json") -> None:
        """Synchronize local CSV and/or JSON files atomically based on configured storage mode."""
        self.config.ensure_directories()
        if "csv" in mode:
            self.atomic_write_text(self.config.csv_path, self.serialize_csv(passes), create_bak=True)
        if "json" in mode:
            self.atomic_write_text(self.config.json_path, self.serialize_json(passes), create_bak=True)

    def ensure_initial_files(self, passes: List[BusPass]) -> None:
        """Create clean initial CSV/JSON files if missing."""
        self.config.ensure_directories()
        if not self.config.csv_path.exists():
            self.atomic_write_text(self.config.csv_path, self.serialize_csv(passes), create_bak=False)
        if not self.config.json_path.exists():
            self.atomic_write_text(self.config.json_path, self.serialize_json(passes), create_bak=False)

    def append_audit_log_file(self, action: str, entity_type: str, entity_id: str, description: str) -> None:
        """Append a single-line structured entry to data/audit.log."""
        self.config.ensure_directories()
        ts = _utc_now_iso()
        line = f"[{ts}] {action} | {entity_type}:{entity_id} | {description}\n"
        with open(self.config.audit_log_path, "a", encoding="utf-8") as handle:
            handle.write(line)

    def load_json_records(self, file_path: Path) -> Tuple[List[BusPass], List[str]]:
        """Load and validate BusPass records from JSON, raising CorruptedStorageError on bad files."""
        if not file_path.exists():
            raise FileNotFoundError(f"JSON file not found: {file_path.name}")

        try:
            raw_text = file_path.read_text(encoding="utf-8-sig")
            parsed = json.loads(raw_text)
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise CorruptedStorageError(f"Malformed JSON in {file_path.name}: {exc}") from exc

        try:
            raw_records = ValidationService.validate_json_records_schema(parsed)
        except ValueError as exc:
            raise CorruptedStorageError(str(exc)) from exc

        valid_passes: List[BusPass] = []
        warnings: List[str] = []
        seen_ids: set[str] = set()

        for idx, rec in enumerate(raw_records, start=1):
            try:
                cleaned = ValidationService.validate_pass_payload(rec)
                if cleaned["pass_id"] in seen_ids:
                    warnings.append(f"Row {idx}: duplicate pass_id '{cleaned['pass_id']}' skipped.")
                    continue
                seen_ids.add(cleaned["pass_id"])
                valid_passes.append(
                    BusPass(
                        pass_id=cleaned["pass_id"],
                        holder_name=cleaned["holder_name"],
                        mobile_number=cleaned["mobile_number"],
                        route=cleaned["route"],
                        category=cleaned["category"],
                        issue_date=cleaned["issue_date"],
                        expiry_date=cleaned["expiry_date"],
                        fee=cleaned["fee"],
                        notes=cleaned["notes"],
                        created_at=str(rec.get("created_at") or ""),
                        updated_at=str(rec.get("updated_at") or ""),
                    )
                )
            except Exception as exc:
                warnings.append(f"Row {idx}: {exc}")

        return valid_passes, warnings

    def load_csv_records(self, file_path: Path) -> Tuple[List[BusPass], List[str]]:
        """Load and validate BusPass records from CSV, raising CorruptedStorageError on bad files."""
        if not file_path.exists():
            raise FileNotFoundError(f"CSV file not found: {file_path.name}")

        try:
            raw_text = file_path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeDecodeError) as exc:
            raise CorruptedStorageError(f"Unreadable CSV file {file_path.name}: {exc}") from exc

        return self.parse_csv_text(raw_text)

    @staticmethod
    def parse_csv_text(raw_text: str) -> Tuple[List[BusPass], List[str]]:
        """Parse CSV text with header and row-level schema validation."""
        if not raw_text.strip():
            raise CorruptedStorageError("CSV file is empty.")
        try:
            reader = csv.DictReader(io.StringIO(raw_text))
            ValidationService.validate_csv_headers(list(reader.fieldnames) if reader.fieldnames else None)
        except (csv.Error, ValueError) as exc:
            raise CorruptedStorageError(f"Invalid CSV structure: {exc}") from exc

        valid_passes: List[BusPass] = []
        warnings: List[str] = []
        seen_ids: set[str] = set()

        try:
            for idx, row in enumerate(reader, start=2):  # 1-indexed including header
                # Normalize header case
                normalized_row: Dict[str, Any] = {
                    (k.strip().lower() if isinstance(k, str) else ""): v
                    for k, v in row.items()
                    if k is not None
                }
                try:
                    cleaned = ValidationService.validate_pass_payload(normalized_row)
                    if cleaned["pass_id"] in seen_ids:
                        warnings.append(f"Row {idx} ({cleaned['pass_id']}): duplicate pass_id in file.")
                        continue
                    seen_ids.add(cleaned["pass_id"])
                    valid_passes.append(
                        BusPass(
                            pass_id=cleaned["pass_id"],
                            holder_name=cleaned["holder_name"],
                            mobile_number=cleaned["mobile_number"],
                            route=cleaned["route"],
                            category=cleaned["category"],
                            issue_date=cleaned["issue_date"],
                            expiry_date=cleaned["expiry_date"],
                            fee=cleaned["fee"],
                            notes=cleaned["notes"],
                            created_at=str(normalized_row.get("created_at") or ""),
                            updated_at=str(normalized_row.get("updated_at") or ""),
                        )
                    )
                except Exception as exc:
                    warnings.append(f"Row {idx}: {exc}")
        except csv.Error as exc:
            raise CorruptedStorageError(f"Malformed CSV row encountered: {exc}") from exc

        return valid_passes, warnings

    def recover_if_corrupted(self, passes_from_db: List[BusPass], mode: str = "sqlite+csv+json") -> List[str]:
        """Verify local JSON/CSV files; quarantine damaged files and regenerate clean copies from SQLite."""
        recovery_notes: List[str] = []
        if "json" in mode and self.config.json_path.exists():
            try:
                self.load_json_records(self.config.json_path)
            except CorruptedStorageError as exc:
                quarantined = self.quarantine_corrupted_file(self.config.json_path)
                self.atomic_write_text(self.config.json_path, self.serialize_json(passes_from_db), create_bak=False)
                recovery_notes.append(
                    f"Corrupted JSON quarantined as {quarantined.name if quarantined else 'backup'} and rebuilt ({exc})."
                )

        if "csv" in mode and self.config.csv_path.exists():
            try:
                self.load_csv_records(self.config.csv_path)
            except CorruptedStorageError as exc:
                quarantined = self.quarantine_corrupted_file(self.config.csv_path)
                self.atomic_write_text(self.config.csv_path, self.serialize_csv(passes_from_db), create_bak=False)
                recovery_notes.append(
                    f"Corrupted CSV quarantined as {quarantined.name if quarantined else 'backup'} and rebuilt ({exc})."
                )
        return recovery_notes
