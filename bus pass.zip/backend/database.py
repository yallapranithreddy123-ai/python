"""SQLite database connection manager, schema initialization, and migrations."""

from __future__ import annotations

import shutil
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, Iterator, List, Tuple

from config import AppConfig


class DatabaseCorruptionError(RuntimeError):
    """Raised when SQLite fails integrity verification or cannot be opened."""


class DatabaseBusyError(RuntimeError):
    """Raised when SQLite remains locked past the configured busy timeout."""


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


MigrationFn = Callable[[sqlite3.Connection], None]


def _migration_001_initial_schema(conn: sqlite3.Connection) -> None:
    """Create core tables, constraints, and search indexes."""
    statements = [
        """
        CREATE TABLE IF NOT EXISTS bus_passes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pass_id TEXT NOT NULL UNIQUE,
            holder_name TEXT NOT NULL,
            mobile_number TEXT NOT NULL,
            route TEXT NOT NULL,
            category TEXT NOT NULL,
            issue_date TEXT NOT NULL,
            expiry_date TEXT NOT NULL,
            fee REAL NOT NULL DEFAULT 0.0 CHECK (fee >= 0),
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        """,
        "CREATE INDEX IF NOT EXISTS idx_bus_passes_pass_id ON bus_passes(pass_id);",
        "CREATE INDEX IF NOT EXISTS idx_bus_passes_holder_name ON bus_passes(holder_name);",
        "CREATE INDEX IF NOT EXISTS idx_bus_passes_route ON bus_passes(route);",
        "CREATE INDEX IF NOT EXISTS idx_bus_passes_category ON bus_passes(category);",
        "CREATE INDEX IF NOT EXISTS idx_bus_passes_expiry_date ON bus_passes(expiry_date);",
        "CREATE INDEX IF NOT EXISTS idx_bus_passes_mobile ON bus_passes(mobile_number);",
        """
        CREATE TABLE IF NOT EXISTS application_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            expiry_warning_days INTEGER NOT NULL DEFAULT 7 CHECK (expiry_warning_days BETWEEN 1 AND 90),
            storage_sync_mode TEXT NOT NULL DEFAULT 'sqlite+csv+json',
            default_page_size INTEGER NOT NULL DEFAULT 15 CHECK (default_page_size BETWEEN 5 AND 100),
            updated_at TEXT NOT NULL
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            description TEXT NOT NULL,
            timestamp TEXT NOT NULL
        );
        """,
        "CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp DESC);",
    ]
    for stmt in statements:
        conn.execute(stmt)


def _migration_002_audit_and_pass_indexes(conn: sqlite3.Connection) -> None:
    """Add composite indexes for high-volume pagination and audit entity lookups."""
    statements = [
        "CREATE INDEX IF NOT EXISTS idx_bus_passes_created_at ON bus_passes(created_at DESC);",
        "CREATE INDEX IF NOT EXISTS idx_bus_passes_cat_expiry ON bus_passes(category, expiry_date);",
        "CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON audit_logs(entity_type, entity_id);",
    ]
    for stmt in statements:
        conn.execute(stmt)


MIGRATIONS: List[Tuple[int, str, MigrationFn]] = [
    (1, "initial_schema", _migration_001_initial_schema),
    (2, "audit_and_pass_indexes", _migration_002_audit_and_pass_indexes),
]


class DatabaseManager:
    """Thread-safe SQLite connection factory with WAL mode and schema migrations."""

    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.db_path: Path = config.db_path

    def _connect(self) -> sqlite3.Connection:
        self.config.ensure_directories()
        timeout_sec = max(1.0, self.config.sqlite_busy_timeout_ms / 1000.0)
        conn = sqlite3.connect(
            str(self.db_path),
            timeout=timeout_sec,
            isolation_level=None,  # Explicit transaction control
            check_same_thread=True,
        )
        conn.row_factory = sqlite3.Row
        conn.execute(f"PRAGMA busy_timeout = {int(self.config.sqlite_busy_timeout_ms)};")
        conn.execute("PRAGMA foreign_keys = ON;")
        try:
            conn.execute("PRAGMA journal_mode = WAL;")
            conn.execute("PRAGMA synchronous = NORMAL;")
        except sqlite3.OperationalError:
            # Fallback silently if filesystem does not support WAL
            pass
        return conn

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        """Yield a short-lived connection for the current operation/request boundary."""
        conn = self._connect()
        try:
            yield conn
        finally:
            conn.close()

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Execute database mutations inside an atomic SQLite transaction with rollback on error."""
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE;")
            yield conn
            conn.execute("COMMIT;")
        except sqlite3.OperationalError as exc:
            try:
                conn.execute("ROLLBACK;")
            except sqlite3.Error:
                pass
            if "locked" in str(exc).lower() or "busy" in str(exc).lower():
                raise DatabaseBusyError("Database is temporarily busy. Please retry.") from exc
            raise
        except Exception:
            try:
                conn.execute("ROLLBACK;")
            except sqlite3.Error:
                pass
            raise
        finally:
            conn.close()

    def initialize(self) -> List[int]:
        """Initialize schema_migrations table, apply pending migrations, and seed default settings."""
        self.config.ensure_directories()
        applied_now: List[int] = []
        with self.transaction() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS schema_migrations (
                    version INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    applied_at TEXT NOT NULL
                );
                """
            )
            rows = conn.execute("SELECT version FROM schema_migrations;").fetchall()
            existing_versions = {int(r["version"]) for r in rows}

            for version, name, migration_fn in MIGRATIONS:
                if version not in existing_versions:
                    migration_fn(conn)
                    conn.execute(
                        "INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?);",
                        (version, name, _utc_now_iso()),
                    )
                    applied_now.append(version)

            # Ensure singleton settings row exists
            conn.execute(
                """
                INSERT OR IGNORE INTO application_settings (
                    id, expiry_warning_days, storage_sync_mode, default_page_size, updated_at
                ) VALUES (1, ?, 'sqlite+csv+json', ?, ?);
                """,
                (
                    self.config.default_warning_days,
                    self.config.default_page_size,
                    _utc_now_iso(),
                ),
            )
        return applied_now

    def get_schema_version(self) -> int:
        """Return highest applied schema migration version."""
        with self.connection() as conn:
            row = conn.execute("SELECT COALESCE(MAX(version), 0) AS ver FROM schema_migrations;").fetchone()
            return int(row["ver"]) if row else 0

    def check_integrity(self) -> Dict[str, object]:
        """Run SQLite PRAGMA integrity_check and return structured verification result."""
        if not self.db_path.exists():
            return {"ok": False, "details": ["Database file does not exist."]}
        try:
            with self.connection() as conn:
                rows = conn.execute("PRAGMA integrity_check;").fetchall()
                messages = [str(r[0]) for r in rows]
                ok = len(messages) == 1 and messages[0].lower() == "ok"
                return {"ok": ok, "details": messages, "schema_version": self.get_schema_version()}
        except sqlite3.DatabaseError as exc:
            return {"ok": False, "details": [str(exc)], "schema_version": 0}

    def quarantine_corrupted_db(self) -> Path | None:
        """Preserve a corrupted database file before initializing a clean replacement."""
        if not self.db_path.exists():
            return None
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        quarantine_path = self.db_path.with_name(f"{self.db_path.stem}.corrupted.{ts}.db")
        shutil.move(str(self.db_path), str(quarantine_path))
        for suffix in ("-wal", "-shm"):
            sidecar = Path(f"{self.db_path}{suffix}")
            if sidecar.exists():
                sidecar.unlink(missing_ok=True)
        return quarantine_path
