"""Realistic relative-date sample dataset (40 records) and synthetic benchmark generator."""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional

from backend.models import PASS_CATEGORIES, BusPass
from backend.storage import FilePersistenceService
from config import AppConfig


SAMPLE_HOLDERS = [
    ("Aarav Sharma", "+919876543210", "Route 101 - Central Station to University Campus", "Student", 450.0, "Semester transit pass"),
    ("Priya Nair", "+919845012345", "Route 204 - Tech Park Express", "Employee", 1200.0, "Corporate monthly shuttle"),
    ("Rohan Kulkarni", "+919822334455", "Route 12 - Market Square Loop", "General Commuter", 650.0, "Standard monthly pass"),
    ("Meera Iyer", "+919900112233", "Route 305 - Civic Hospital Connector", "Senior Citizen", 250.0, "Senior concession verified"),
    ("Vikram Desai", "+919811223344", "Route 108 - North Terminal to Science Block", "Student", 450.0, "Engineering department student"),
    ("Ananya Verma", "+919765432109", "Route 402 - Airport Corridor Express", "Express Route", 1800.0, "Priority express lane"),
    ("Kabir Malhotra", "+919988776655", "Route 15 - Old Town to Harbor", "General Commuter", 600.0, "Weekday commuter"),
    ("Sneha Joshi", "+919833445566", "Route 204 - Tech Park Express", "Employee", 1200.0, "Includes feeder transfer"),
    ("Arjun Menon", "+919871234560", "Route 501 - Accessible Metro Feeder", "Differently Abled", 0.0, "Zero-fee municipal concession"),
    ("Divya Krishnan", "+919890123456", "Route 101 - Central Station to University Campus", "Student", 450.0, "Postgraduate scholar"),
    ("Siddharth Rao", "+919820987654", "Route 309 - Ring Road Outer", "General Commuter", 750.0, "All-zone access"),
    ("Neha Gupta", "+919818273645", "Route 402 - Airport Corridor Express", "Express Route", 1850.0, "AC Express service"),
    ("Karthik Subramanian", "+919840556677", "Route 204 - Tech Park Express", "Employee", 1150.0, "Quarterly renewal cycle"),
    ("Pooja Patel", "+919825112299", "Route 12 - Market Square Loop", "General Commuter", 650.0, "Evening shift commuter"),
    ("Aditya Joshi", "+919911223388", "Route 108 - North Terminal to Science Block", "Student", 400.0, "Lab assistant pass"),
    ("Lakshmi Narayanan", "+919841223344", "Route 305 - Civic Hospital Connector", "Senior Citizen", 250.0, "Concession ID verified"),
    ("Nikhil Kapoor", "+919810998877", "Route 210 - Industrial Estate Shuttle", "Employee", 1050.0, "Plant B route"),
    ("Ritu Chatterjee", "+919830112244", "Route 15 - Old Town to Harbor", "General Commuter", 600.0, "Standard pass"),
    ("Manish Tiwari", "+919826778899", "Route 501 - Accessible Metro Feeder", "Differently Abled", 0.0, "Mobility pass"),
    ("Kavya Reddy", "+919849334455", "Route 101 - Central Station to University Campus", "Student", 450.0, "Library shuttle included"),
    ("Suresh Babu", "+919848223311", "Route 309 - Ring Road Outer", "Senior Citizen", 300.0, "Annual senior card"),
    ("Ishita Banerjee", "+919831445566", "Route 402 - Airport Corridor Express", "Express Route", 1800.0, "Fast-track boarding"),
    ("Pranav Gokhale", "+919823556677", "Route 210 - Industrial Estate Shuttle", "Employee", 1100.0, "Shift A transit"),
    ("Tanvi Deshmukh", "+919822667788", "Route 108 - North Terminal to Science Block", "Student", 450.0, "Honors block"),
    ("Deepak Chawla", "+919811445599", "Route 12 - Market Square Loop", "General Commuter", 650.0, "City center zone"),
    ("Swati Kulkarni", "+919890776655", "Route 204 - Tech Park Express", "Employee", 1200.0, "Renewable online"),
    ("Harish Gowda", "+919900445511", "Route 15 - Old Town to Harbor", "General Commuter", 620.0, "Coastal route"),
    ("Nandini Pillai", "+919847112200", "Route 305 - Civic Hospital Connector", "Senior Citizen", 250.0, "Priority seating"),
    ("Varun Saxena", "+919819334422", "Route 402 - Airport Corridor Express", "Express Route", 1750.0, "Monthly express"),
    ("Bhavna Mehta", "+919824556600", "Route 101 - Central Station to University Campus", "Student", 450.0, "Freshman orientation pass"),
    ("Gaurav Mishra", "+919827665544", "Route 210 - Industrial Estate Shuttle", "Employee", 0.0, "Employer-sponsored zero fee"),
    ("Shreya Sengupta", "+919836778811", "Route 309 - Ring Road Outer", "General Commuter", 750.0, "Outer ring corridor"),
    ("Rajesh Khanna", "+919815889922", "Route 305 - Civic Hospital Connector", "Senior Citizen", 250.0, "Medical clinic route"),
    ("Aparna Menon", "+919846990033", "Route 501 - Accessible Metro Feeder", "Differently Abled", 0.0, "Concession renewed"),
    ("Kunal Bhatia", "+919814001122", "Route 402 - Airport Corridor Express", "Express Route", 1900.0, "Weekend express add-on"),
    ("Pallavi Rao", "+919844112233", "Route 108 - North Terminal to Science Block", "Student", 450.0, "Research wing shuttle"),
    ("Tarun Nair", "+919895223344", "Route 204 - Tech Park Express", "Employee", 1200.0, "Campus 2 shuttle"),
    ("Vidya Iyer", "+919842334455", "Route 12 - Market Square Loop", "General Commuter", 650.0, "Single-day boundary check"),
    ("Sandeep Verma", "+919813445566", "Route 15 - Old Town to Harbor", "General Commuter", 680.0, "Multi-month renewal"),
    ("Ayesha Siddiqui", "+919829556677", "Route 101 - Central Station to University Campus", "Student", 900.0, "Annual student pass"),
]

# Offsets relative to today (days_until_expiry, duration_days)
# Covers: Expired (-65 to -1), Expires Today (0), Expiring Soon (1 to 7), Boundary (8), Active (12 to 180)
RELATIVE_OFFSETS = [
    (45, 90),    # 1 Active
    (3, 30),     # 2 Expiring Soon (3d)
    (0, 30),     # 3 Expires Today (0d)
    (-5, 30),    # 4 Expired (-5d)
    (7, 30),     # 5 Boundary Expiring Soon (7d exact)
    (18, 60),    # 6 Active
    (-14, 30),   # 7 Expired
    (1, 30),     # 8 Expiring Soon (1d)
    (90, 180),   # 9 Active zero-fee
    (5, 30),     # 10 Expiring Soon (5d)
    (-1, 30),    # 11 Boundary Expired (-1d yesterday)
    (28, 30),    # 12 Active
    (0, 90),     # 13 Expires Today (0d)
    (-32, 30),   # 14 Expired
    (8, 30),     # 15 Boundary Active (8d, just above 7d default threshold)
    (62, 180),   # 16 Active
    (2, 30),     # 17 Expiring Soon (2d)
    (-22, 30),   # 18 Expired
    (120, 365),  # 19 Active annual
    (6, 30),     # 20 Expiring Soon (6d)
    (150, 365),  # 21 Active annual
    (-45, 60),   # 22 Expired
    (4, 30),     # 23 Expiring Soon (4d)
    (35, 90),    # 24 Active
    (-8, 30),    # 25 Expired
    (15, 30),    # 26 Active
    (0, 1),      # 27 Boundary 1-day pass expiring today
    (75, 180),   # 28 Active
    (11, 30),    # 29 Active
    (-60, 90),   # 30 Expired
    (30, 30),    # 31 Active (issued today, 0-fee employee anomaly check)
    (-3, 30),    # 32 Expired
    (55, 180),   # 33 Active
    (95, 365),   # 34 Active
    (7, 60),     # 35 Boundary Expiring Soon (7d)
    (22, 90),    # 36 Active
    (-19, 30),   # 37 Expired
    (0, 0),      # 38 Boundary 0-day single-day pass issued & expiring today
    (40, 60),    # 39 Active
    (240, 365),  # 40 Active annual
]


def build_sample_passes(reference_date: Optional[date] = None) -> List[BusPass]:
    """Build 40 deterministic, internally consistent bus pass records relative to reference_date."""
    today = reference_date or date.today()
    now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    passes: List[BusPass] = []

    for idx, (holder, offset) in enumerate(zip(SAMPLE_HOLDERS, RELATIVE_OFFSETS), start=1):
        name, mobile, route, category, fee, notes = holder
        days_delta, duration = offset
        expiry_dt = today + timedelta(days=days_delta)
        issue_dt = expiry_dt - timedelta(days=duration)
        passes.append(
            BusPass(
                pass_id=f"BP-{today.year}-{idx:03d}",
                holder_name=name,
                mobile_number=mobile,
                route=route,
                category=category,
                issue_date=issue_dt.strftime("%Y-%m-%d"),
                expiry_date=expiry_dt.strftime("%Y-%m-%d"),
                fee=fee,
                notes=notes,
                created_at=now_iso,
                updated_at=now_iso,
            )
        )
    return passes


def write_sample_dataset_files(config: AppConfig, reference_date: Optional[date] = None) -> List[BusPass]:
    """Write sample_bus_passes.csv and sample_bus_passes.json into sample_data/."""
    passes = build_sample_passes(reference_date=reference_date)
    config.sample_data_dir.mkdir(parents=True, exist_ok=True)
    file_service = FilePersistenceService(config)
    FilePersistenceService.atomic_write_text(
        config.sample_data_dir / "sample_bus_passes.csv",
        file_service.serialize_csv(passes),
        create_bak=False,
    )
    FilePersistenceService.atomic_write_text(
        config.sample_data_dir / "sample_bus_passes.json",
        file_service.serialize_json(passes),
        create_bak=False,
    )
    return passes


def generate_synthetic_passes(count: int = 10000, reference_date: Optional[date] = None) -> List[BusPass]:
    """Generate a synthetic dataset (e.g., 10,000 records) for performance and pagination tests."""
    today = reference_date or date.today()
    now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    routes = (
        "Route 101 - Central Station",
        "Route 204 - Tech Park Express",
        "Route 305 - Civic Hospital",
        "Route 402 - Airport Corridor",
        "Route 501 - Metro Feeder",
    )
    records: List[BusPass] = []
    for i in range(1, count + 1):
        delta = ((i * 7) % 180) - 45
        expiry_dt = today + timedelta(days=delta)
        issue_dt = expiry_dt - timedelta(days=30 + (i % 60))
        category = PASS_CATEGORIES[i % len(PASS_CATEGORIES)]
        route = routes[i % len(routes)]
        records.append(
            BusPass(
                pass_id=f"SYN-{i:06d}",
                holder_name=f"Commuter {i:05d}",
                mobile_number=f"+9198{i:08d}"[:13],
                route=route,
                category=category,
                issue_date=issue_dt.strftime("%Y-%m-%d"),
                expiry_date=expiry_dt.strftime("%Y-%m-%d"),
                fee=float(300 + (i % 10) * 100),
                notes="Synthetic load test record",
                created_at=now_iso,
                updated_at=now_iso,
            )
        )
    return records
