"""Unified Business Logic facade shared by the Flask/HTTP API and CLI interfaces."""

from __future__ import annotations

from datetime import date
from typing import Any, Dict, List, Optional

from backend.analytics import AnalyticsService
from backend.backup import BackupService
from backend.database import DatabaseManager
from backend.expiry import ExpiryService
from backend.import_export import ImportExportService
from backend.models import AppSettings, BusPass, PaginationResult
from backend.reports import ReportService
from backend.repository import (
    AuditLogRepository,
    BusPassRepository,
    PassNotFoundError,
    SettingsRepository,
)
from backend.search import SearchService
from backend.seed import build_sample_passes, write_sample_dataset_files
from backend.storage import FilePersistenceService
from backend.validation import ValidationService
from config import AppConfig


class BusPassService:
    """High-level application service enforcing validation, expiry enrichment, persistence sync, and audit logs."""

    def __init__(
        self,
        config: AppConfig,
        db: DatabaseManager,
        pass_repo: BusPassRepository,
        settings_repo: SettingsRepository,
        audit_repo: AuditLogRepository,
        file_service: FilePersistenceService,
    ) -> None:
        self.config = config
        self.db = db
        self.pass_repo = pass_repo
        self.settings_repo = settings_repo
        self.audit_repo = audit_repo
        self.file_service = file_service

    def initialize_app(self, seed_if_empty: bool = True) -> List[str]:
        """Initialize SQLite schema, recover any corrupted files, and optionally seed sample data on first run."""
        self.config.ensure_directories()
        db_existed_before = self.config.db_path.exists()
        recovery_notes = BackupService(
            self.config, self.db, self.pass_repo, self.settings_repo, self.audit_repo, self.file_service
        ).verify_and_recover_startup()

        # Ensure sample_data artifacts exist on disk
        if not (self.config.sample_data_dir / "sample_bus_passes.csv").exists():
            write_sample_dataset_files(self.config)

        if seed_if_empty and not db_existed_before and self.pass_repo.count_all() == 0:
            sample_passes = build_sample_passes()
            self.pass_repo.bulk_insert_ignore_duplicates(sample_passes)
            self.audit_repo.record(
                action="SEED_INITIAL",
                entity_type="system",
                entity_id="sample_dataset",
                description=f"Initialized database with {len(sample_passes)} sample bus pass records.",
            )
            self.file_service.append_audit_log_file(
                "SEED_INITIAL",
                "system",
                "sample_dataset",
                f"Seeded {len(sample_passes)} sample records on first run.",
            )

        settings = self.settings_repo.get()
        all_passes = self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC")
        self.file_service.ensure_initial_files(all_passes)
        self.file_service.sync_files(all_passes, mode=settings.storage_sync_mode)
        return recovery_notes

    def create_pass(self, payload: Dict[str, Any], reference_date: Optional[date] = None) -> BusPass:
        cleaned = ValidationService.validate_pass_payload(payload, is_update=False)
        new_pass = BusPass(
            pass_id=cleaned["pass_id"],
            holder_name=cleaned["holder_name"],
            mobile_number=cleaned["mobile_number"],
            route=cleaned["route"],
            category=cleaned["category"],
            issue_date=cleaned["issue_date"],
            expiry_date=cleaned["expiry_date"],
            fee=cleaned["fee"],
            notes=cleaned["notes"],
        )
        created = self.pass_repo.create(new_pass)
        self._sync_after_mutation(
            action="CREATE_PASS",
            entity_id=created.pass_id,
            description=f"Registered bus pass {created.pass_id} ({created.category}, expires {created.expiry_date}).",
        )
        settings = self.settings_repo.get()
        return ExpiryService.enrich_pass(
            created, warning_days=settings.expiry_warning_days, reference_date=reference_date
        )

    def get_pass(self, pass_id: str, reference_date: Optional[date] = None) -> BusPass:
        cleaned_id = ValidationService.validate_pass_id(pass_id)
        found = self.pass_repo.get_by_pass_id(cleaned_id)
        if not found:
            raise PassNotFoundError(f"Bus pass '{cleaned_id}' was not found.")
        settings = self.settings_repo.get()
        return ExpiryService.enrich_pass(
            found, warning_days=settings.expiry_warning_days, reference_date=reference_date
        )

    def update_pass(
        self, pass_id: str, payload: Dict[str, Any], reference_date: Optional[date] = None
    ) -> BusPass:
        cleaned_id = ValidationService.validate_pass_id(pass_id)
        cleaned = ValidationService.validate_pass_payload(payload, is_update=True, existing_pass_id=cleaned_id)
        updated = self.pass_repo.update(cleaned_id, cleaned)
        self._sync_after_mutation(
            action="UPDATE_PASS",
            entity_id=updated.pass_id,
            description=f"Updated bus pass {updated.pass_id} (route '{updated.route}', expires {updated.expiry_date}).",
        )
        settings = self.settings_repo.get()
        return ExpiryService.enrich_pass(
            updated, warning_days=settings.expiry_warning_days, reference_date=reference_date
        )

    def delete_pass(self, pass_id: str) -> BusPass:
        cleaned_id = ValidationService.validate_pass_id(pass_id)
        deleted = self.pass_repo.delete(cleaned_id)
        self._sync_after_mutation(
            action="DELETE_PASS",
            entity_id=deleted.pass_id,
            description=f"Deleted bus pass {deleted.pass_id}.",
        )
        return deleted

    def list_passes_paginated(
        self,
        *,
        page: int = 1,
        page_size: Optional[int] = None,
        query: str = "",
        category: str = "",
        status: str = "",
        expiry_from: str = "",
        expiry_to: str = "",
        sort_by: str = "expiry_date",
        sort_dir: str = "asc",
        reference_date: Optional[date] = None,
    ) -> PaginationResult:
        settings = self.settings_repo.get()
        effective_size = page_size if page_size is not None else settings.default_page_size
        res = self.pass_repo.query_paginated(
            page=page,
            page_size=effective_size,
            query=query,
            category=category,
            status=status,
            expiry_from=expiry_from,
            expiry_to=expiry_to,
            sort_by=sort_by,
            sort_dir=sort_dir,
            warning_days=settings.expiry_warning_days,
            reference_date=reference_date,
        )
        ExpiryService.enrich_many(
            res.items, warning_days=settings.expiry_warning_days, reference_date=reference_date
        )
        return res

    def get_expiry_monitor(self, reference_date: Optional[date] = None) -> Dict[str, Any]:
        settings = self.settings_repo.get()
        all_passes = self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC")
        buckets = ExpiryService.partition_for_monitor(
            all_passes, warning_days=settings.expiry_warning_days, reference_date=reference_date
        )
        return {
            "warning_days": settings.expiry_warning_days,
            "counts": {k: len(v) for k, v in buckets.items()},
            "expires_today": [p.to_api_dict() for p in buckets["expires_today"]],
            "expiring_soon": [p.to_api_dict() for p in buckets["expiring_soon"]],
            "expired": [p.to_api_dict() for p in buckets["expired"]],
            "future": [p.to_api_dict() for p in buckets["future"]],
        }

    def get_settings(self) -> AppSettings:
        return self.settings_repo.get()

    def update_settings(self, payload: Dict[str, Any]) -> AppSettings:
        cleaned = ValidationService.validate_settings_payload(payload)
        updated = self.settings_repo.update(cleaned)
        all_passes = self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC")
        self.file_service.sync_files(all_passes, mode=updated.storage_sync_mode)
        self.audit_repo.record(
            action="UPDATE_SETTINGS",
            entity_type="settings",
            entity_id="global",
            description=(
                f"Updated warning threshold={updated.expiry_warning_days}d, "
                f"storage_mode={updated.storage_sync_mode}, page_size={updated.default_page_size}."
            ),
        )
        self.file_service.append_audit_log_file(
            "UPDATE_SETTINGS",
            "settings",
            "global",
            f"Warning={updated.expiry_warning_days}d, mode={updated.storage_sync_mode}.",
        )
        return updated

    def reset_to_sample_dataset(self) -> int:
        """Reset database to fresh relative-date 40-record sample dataset (after creating a backup)."""
        backup_service = BackupService(
            self.config, self.db, self.pass_repo, self.settings_repo, self.audit_repo, self.file_service
        )
        if self.config.db_path.exists():
            backup_service.create_backup(prefix="pre_sample_reset")
        samples = build_sample_passes()
        count = self.pass_repo.replace_all(samples)
        settings = self.settings_repo.get()
        self.file_service.sync_files(samples, mode=settings.storage_sync_mode)
        self.audit_repo.record(
            action="RESET_SAMPLE_DATA",
            entity_type="system",
            entity_id="sample_dataset",
            description=f"Reset registry to {count} sample bus pass records.",
        )
        return count

    def _sync_after_mutation(self, action: str, entity_id: str, description: str) -> None:
        settings = self.settings_repo.get()
        all_passes = self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC")
        self.file_service.sync_files(all_passes, mode=settings.storage_sync_mode)
        self.audit_repo.record(
            action=action,
            entity_type="bus_pass",
            entity_id=entity_id,
            description=description,
        )
        self.file_service.append_audit_log_file(action, "bus_pass", entity_id, description)


class ApplicationContainer:
    """Dependency injection container assembling the Three-Tier architecture."""

    def __init__(self, config: Optional[AppConfig] = None, seed_if_empty: bool = True) -> None:
        self.config = config or AppConfig()
        self.db = DatabaseManager(self.config)
        self.pass_repo = BusPassRepository(self.db)
        self.settings_repo = SettingsRepository(self.db)
        self.audit_repo = AuditLogRepository(self.db)
        self.file_service = FilePersistenceService(self.config)

        self.bus_pass_service = BusPassService(
            self.config,
            self.db,
            self.pass_repo,
            self.settings_repo,
            self.audit_repo,
            self.file_service,
        )
        self.search_service = SearchService(self.pass_repo, self.settings_repo)
        self.analytics_service = AnalyticsService(self.pass_repo, self.settings_repo)
        self.report_service = ReportService(
            self.config,
            self.pass_repo,
            self.settings_repo,
            self.audit_repo,
            self.analytics_service,
        )
        self.import_export_service = ImportExportService(
            self.config,
            self.pass_repo,
            self.settings_repo,
            self.audit_repo,
            self.file_service,
        )
        self.backup_service = BackupService(
            self.config,
            self.db,
            self.pass_repo,
            self.settings_repo,
            self.audit_repo,
            self.file_service,
        )

        self.startup_notes = self.bus_pass_service.initialize_app(seed_if_empty=seed_if_empty)
