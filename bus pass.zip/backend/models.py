"""Domain models and constants for Bus Pass Expiry Tracker."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional


PASS_CATEGORIES: tuple[str, ...] = (
    "Student",
    "General Commuter",
    "Senior Citizen",
    "Employee",
    "Differently Abled",
    "Express Route",
)

PASS_STATUSES: tuple[str, ...] = (
    "Active",
    "Expiring Soon",
    "Expires Today",
    "Expired",
)

STORAGE_FORMATS: tuple[str, ...] = (
    "sqlite+csv+json",
    "sqlite+json",
    "sqlite+csv",
    "sqlite",
)

CSV_FIELDNAMES: tuple[str, ...] = (
    "pass_id",
    "holder_name",
    "mobile_number",
    "route",
    "category",
    "issue_date",
    "expiry_date",
    "fee",
    "notes",
    "created_at",
    "updated_at",
)


@dataclass
class BusPass:
    """Core domain entity representing a registered bus pass."""

    pass_id: str
    holder_name: str
    mobile_number: str
    route: str
    category: str
    issue_date: str  # YYYY-MM-DD
    expiry_date: str  # YYYY-MM-DD
    fee: float = 0.0
    notes: str = ""
    id: Optional[int] = None
    created_at: str = ""
    updated_at: str = ""

    # Computed fields populated by ExpiryService
    days_remaining: Optional[int] = None
    status: Optional[str] = None
    urgency: Optional[str] = None
    renewal_deadline: Optional[str] = None

    def to_storage_dict(self) -> Dict[str, Any]:
        """Serialize core persistent attributes for CSV/JSON and DB storage."""
        return {
            "pass_id": self.pass_id,
            "holder_name": self.holder_name,
            "mobile_number": self.mobile_number,
            "route": self.route,
            "category": self.category,
            "issue_date": self.issue_date,
            "expiry_date": self.expiry_date,
            "fee": round(float(self.fee), 2),
            "notes": self.notes,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    def to_api_dict(self) -> Dict[str, Any]:
        """Serialize full domain representation including computed expiry metadata."""
        data = asdict(self)
        data["fee"] = round(float(self.fee), 2)
        return data


@dataclass
class AppSettings:
    """Application settings persisted in SQLite."""

    expiry_warning_days: int = 7
    storage_sync_mode: str = "sqlite+csv+json"
    default_page_size: int = 15
    updated_at: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AuditLogEntry:
    """Audit trail record tracking system operations without sensitive PII."""

    action: str
    entity_type: str
    entity_id: str
    description: str
    timestamp: str
    id: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ImportRowError:
    """Row-level error diagnostic produced during bulk CSV or JSON import."""

    row_number: int
    pass_id: str
    errors: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ImportResult:
    """Summary of a bulk import operation."""

    total_rows: int
    imported_count: int
    failed_count: int
    skipped_duplicates: int
    row_errors: List[ImportRowError] = field(default_factory=list)
    imported_pass_ids: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_rows": self.total_rows,
            "imported_count": self.imported_count,
            "failed_count": self.failed_count,
            "skipped_duplicates": self.skipped_duplicates,
            "row_errors": [err.to_dict() for err in self.row_errors],
            "imported_pass_ids": list(self.imported_pass_ids),
        }


@dataclass
class PaginationResult:
    """Database-level paginated query envelope."""

    items: List[BusPass]
    total_count: int
    page: int
    page_size: int
    total_pages: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "items": [item.to_api_dict() for item in self.items],
            "total_count": self.total_count,
            "page": self.page,
            "page_size": self.page_size,
            "total_pages": self.total_pages,
        }
