"""OpenAPI 3.0.3 specification builder and Swagger UI HTML renderer."""

from __future__ import annotations

from typing import Any, Dict


def build_openapi_spec() -> Dict[str, Any]:
    """Return complete OpenAPI 3.0.3 JSON specification for Bus Pass Expiry Tracker."""
    pass_schema = {
        "type": "object",
        "properties": {
            "id": {"type": "integer", "example": 1},
            "pass_id": {"type": "string", "example": "BP-2026-001"},
            "holder_name": {"type": "string", "example": "Aarav Sharma"},
            "mobile_number": {"type": "string", "example": "+919876543210"},
            "route": {"type": "string", "example": "Route 101 - Central Station to University Campus"},
            "category": {
                "type": "string",
                "enum": [
                    "Student",
                    "General Commuter",
                    "Senior Citizen",
                    "Employee",
                    "Differently Abled",
                    "Express Route",
                ],
                "example": "Student",
            },
            "issue_date": {"type": "string", "format": "date", "example": "2026-10-01"},
            "expiry_date": {"type": "string", "format": "date", "example": "2027-01-08"},
            "fee": {"type": "number", "format": "float", "example": 450.0},
            "notes": {"type": "string", "example": "Semester transit pass"},
            "days_remaining": {"type": "integer", "example": 45},
            "status": {
                "type": "string",
                "enum": ["Active", "Expiring Soon", "Expires Today", "Expired"],
                "example": "Active",
            },
            "urgency": {"type": "string", "example": "Normal"},
            "renewal_deadline": {"type": "string", "format": "date", "example": "2027-01-07"},
        },
    }

    pass_input_schema = {
        "type": "object",
        "required": ["pass_id", "holder_name", "mobile_number", "route", "category", "issue_date", "expiry_date"],
        "properties": {
            "pass_id": {"type": "string", "example": "BP-2026-105"},
            "holder_name": {"type": "string", "example": "Riya Sen"},
            "mobile_number": {"type": "string", "example": "+919876543210"},
            "route": {"type": "string", "example": "Route 204 - Tech Park Express"},
            "category": {"type": "string", "example": "Employee"},
            "issue_date": {"type": "string", "format": "date", "example": "2026-11-01"},
            "expiry_date": {"type": "string", "format": "date", "example": "2026-12-31"},
            "fee": {"type": "number", "example": 1200.0},
            "notes": {"type": "string", "example": "Monthly commuter pass"},
        },
    }

    error_schema = {
        "type": "object",
        "properties": {
            "error": {"type": "string", "example": "Validation failed."},
            "code": {"type": "integer", "example": 422},
            "field_errors": {
                "type": "object",
                "additionalProperties": {"type": "string"},
                "example": {"expiry_date": "Expiry date cannot be earlier than the issue date."},
            },
        },
    }

    return {
        "openapi": "3.0.3",
        "info": {
            "title": "Bus Pass Expiry Tracker API",
            "version": "2.0.0",
            "description": (
                "Python Three-Tier REST API backed by SQLite (WAL mode) with automated expiry calculation, "
                "CSV/JSON interoperability, verified database backups, and analytical reporting."
            ),
        },
        "servers": [{"url": "/"}],
        "tags": [
            {"name": "Passes", "description": "CRUD and paginated management for bus passes"},
            {"name": "Monitoring & Search", "description": "Expiry buckets and multi-criteria search"},
            {"name": "Analytics & Reports", "description": "Executive metrics and downloadable reports"},
            {"name": "Import & Export", "description": "Bulk CSV/JSON import and export"},
            {"name": "System & Backups", "description": "Settings, backups, audit logs, and health"},
        ],
        "components": {
            "schemas": {
                "BusPass": pass_schema,
                "BusPassInput": pass_input_schema,
                "ErrorResponse": error_schema,
            },
            "securitySchemes": {
                "CsrfToken": {
                    "type": "apiKey",
                    "in": "header",
                    "name": "X-CSRF-Token",
                }
            },
        },
        "paths": {
            "/api/health": {
                "get": {
                    "tags": ["System & Backups"],
                    "summary": "Health and database integrity probe",
                    "responses": {"200": {"description": "Service and SQLite healthy"}},
                }
            },
            "/api/csrf-token": {
                "get": {
                    "tags": ["System & Backups"],
                    "summary": "Issue HMAC-signed CSRF token for browser mutations",
                    "responses": {"200": {"description": "CSRF token issued"}},
                }
            },
            "/api/passes": {
                "get": {
                    "tags": ["Passes"],
                    "summary": "List bus passes with SQLite LIMIT/OFFSET pagination",
                    "parameters": [
                        {"name": "page", "in": "query", "schema": {"type": "integer", "default": 1}},
                        {"name": "page_size", "in": "query", "schema": {"type": "integer", "default": 15}},
                        {"name": "q", "in": "query", "schema": {"type": "string"}},
                        {"name": "category", "in": "query", "schema": {"type": "string"}},
                        {"name": "status", "in": "query", "schema": {"type": "string"}},
                        {"name": "sort_by", "in": "query", "schema": {"type": "string", "default": "expiry_date"}},
                        {"name": "sort_dir", "in": "query", "schema": {"type": "string", "default": "asc"}},
                    ],
                    "responses": {
                        "200": {"description": "Paginated bus pass list"},
                    },
                },
                "post": {
                    "tags": ["Passes"],
                    "summary": "Create a new validated bus pass",
                    "security": [{"CsrfToken": []}],
                    "requestBody": {
                        "required": True,
                        "content": {"application/json": {"schema": {"$ref": "#/components/schemas/BusPassInput"}}},
                    },
                    "responses": {
                        "201": {"description": "Bus pass created", "content": {"application/json": {"schema": {"$ref": "#/components/schemas/BusPass"}}}},
                        "409": {"description": "Duplicate pass_id conflict"},
                        "422": {"description": "Validation error", "content": {"application/json": {"schema": {"$ref": "#/components/schemas/ErrorResponse"}}}},
                    },
                },
            },
            "/api/passes/{pass_id}": {
                "get": {
                    "tags": ["Passes"],
                    "summary": "Get details for a single bus pass",
                    "parameters": [{"name": "pass_id", "in": "path", "required": True, "schema": {"type": "string"}}],
                    "responses": {
                        "200": {"description": "Pass found"},
                        "404": {"description": "Pass not found"},
                    },
                },
                "put": {
                    "tags": ["Passes"],
                    "summary": "Update an existing bus pass",
                    "security": [{"CsrfToken": []}],
                    "parameters": [{"name": "pass_id", "in": "path", "required": True, "schema": {"type": "string"}}],
                    "requestBody": {
                        "required": True,
                        "content": {"application/json": {"schema": {"$ref": "#/components/schemas/BusPassInput"}}},
                    },
                    "responses": {
                        "200": {"description": "Pass updated"},
                        "404": {"description": "Pass not found"},
                        "422": {"description": "Validation failure"},
                    },
                },
                "delete": {
                    "tags": ["Passes"],
                    "summary": "Delete a bus pass by pass_id",
                    "security": [{"CsrfToken": []}],
                    "parameters": [{"name": "pass_id", "in": "path", "required": True, "schema": {"type": "string"}}],
                    "responses": {
                        "200": {"description": "Pass deleted"},
                        "404": {"description": "Pass not found"},
                    },
                },
            },
            "/api/dashboard/summary": {
                "get": {
                    "tags": ["Analytics & Reports"],
                    "summary": "Get dashboard KPI metrics, warnings, recent additions, and trend data",
                    "responses": {"200": {"description": "Dashboard summary payload"}},
                }
            },
            "/api/expiry/upcoming": {
                "get": {
                    "tags": ["Monitoring & Search"],
                    "summary": "Get passes expiring today and within configured warning threshold",
                    "responses": {"200": {"description": "Upcoming expiry buckets"}},
                }
            },
            "/api/expiry/expired": {
                "get": {
                    "tags": ["Monitoring & Search"],
                    "summary": "Get expired bus passes sorted by most recently expired",
                    "responses": {"200": {"description": "Expired bus passes"}},
                }
            },
            "/api/analytics": {
                "get": {
                    "tags": ["Analytics & Reports"],
                    "summary": "Get full analytical breakdowns (status, monthly trend, category, route)",
                    "responses": {"200": {"description": "Analytics payload"}},
                }
            },
            "/api/search": {
                "get": {
                    "tags": ["Monitoring & Search"],
                    "summary": "Multi-criteria search with category, status, and expiry date range filters",
                    "parameters": [
                        {"name": "q", "in": "query", "schema": {"type": "string"}},
                        {"name": "category", "in": "query", "schema": {"type": "string"}},
                        {"name": "status", "in": "query", "schema": {"type": "string"}},
                        {"name": "expiry_from", "in": "query", "schema": {"type": "string", "format": "date"}},
                        {"name": "expiry_to", "in": "query", "schema": {"type": "string", "format": "date"}},
                        {"name": "page", "in": "query", "schema": {"type": "integer", "default": 1}},
                        {"name": "page_size", "in": "query", "schema": {"type": "integer", "default": 15}},
                    ],
                    "responses": {"200": {"description": "Paginated search results"}},
                }
            },
            "/api/import/csv": {
                "post": {
                    "tags": ["Import & Export"],
                    "summary": "Bulk import bus passes from a CSV file or CSV text body with row-by-row diagnostics",
                    "security": [{"CsrfToken": []}],
                    "responses": {
                        "200": {"description": "Import completed with summary and row_errors"},
                        "400": {"description": "Invalid file or malformed CSV headers"},
                    },
                }
            },
            "/api/export/csv": {
                "get": {
                    "tags": ["Import & Export"],
                    "summary": "Download all bus passes as a standardized CSV file",
                    "responses": {"200": {"description": "text/csv file download"}},
                }
            },
            "/api/export/json": {
                "get": {
                    "tags": ["Import & Export"],
                    "summary": "Download all bus passes as a schema-versioned JSON file",
                    "responses": {"200": {"description": "application/json file download"}},
                }
            },
            "/api/reports/markdown": {
                "get": {
                    "tags": ["Analytics & Reports"],
                    "summary": "Generate and download structured Markdown summary report",
                    "responses": {"200": {"description": "text/markdown report"}},
                }
            },
            "/api/reports/audit": {
                "get": {
                    "tags": ["Analytics & Reports"],
                    "summary": "Generate and download plain-text audit trail report",
                    "responses": {"200": {"description": "text/plain audit report"}},
                }
            },
            "/api/reports/csv": {
                "get": {
                    "tags": ["Analytics & Reports"],
                    "summary": "Generate and download status-enriched CSV report",
                    "responses": {"200": {"description": "text/csv enriched report"}},
                }
            },
            "/api/settings": {
                "get": {
                    "tags": ["System & Backups"],
                    "summary": "Get warning threshold, storage sync mode, and pagination defaults",
                    "responses": {"200": {"description": "Current settings"}},
                },
                "put": {
                    "tags": ["System & Backups"],
                    "summary": "Update application settings",
                    "security": [{"CsrfToken": []}],
                    "responses": {"200": {"description": "Updated settings"}, "422": {"description": "Invalid settings"}},
                },
            },
            "/api/backups": {
                "get": {
                    "tags": ["System & Backups"],
                    "summary": "List verified SQLite backups",
                    "responses": {"200": {"description": "Backup inventory"}},
                },
                "post": {
                    "tags": ["System & Backups"],
                    "summary": "Create a new integrity-verified SQLite backup",
                    "security": [{"CsrfToken": []}],
                    "responses": {"201": {"description": "Backup created"}},
                },
            },
            "/api/backups/restore": {
                "post": {
                    "tags": ["System & Backups"],
                    "summary": "Restore database from a verified backup file",
                    "security": [{"CsrfToken": []}],
                    "responses": {"200": {"description": "Database restored"}, "404": {"description": "Backup not found"}},
                },
            },
            "/api/audit-logs": {
                "get": {
                    "tags": ["System & Backups"],
                    "summary": "Retrieve recent system audit trail events",
                    "responses": {"200": {"description": "Audit log entries"}},
                }
            },
        },
    }


def render_swagger_ui_html(spec_url: str = "/openapi.json") -> str:
    """Render a self-contained interactive API explorer (works offline and with Swagger CDN fallback)."""
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Bus Pass Expiry Tracker — OpenAPI Documentation</title>
  <style>
    body {{ font-family: system-ui, -apple-system, sans-serif; margin: 0; background: #f8fafc; color: #0f172a; }}
    .topbar {{ background: #0f172a; color: #fff; padding: 14px 24px; display: flex; justify-content: space-between; align-items: center; }}
    .topbar a {{ color: #5eead4; text-decoration: none; font-size: 14px; font-weight: 600; }}
    .container {{ max-width: 1120px; margin: 24px auto; padding: 0 20px; }}
    .endpoint {{ background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 12px; padding: 14px 18px; }}
    .method {{ display: inline-block; font-family: monospace; font-weight: 700; font-size: 12px; padding: 3px 8px; border-radius: 4px; margin-right: 10px; }}
    .GET {{ background: #dcfce7; color: #166534; }}
    .POST {{ background: #dbeafe; color: #1e40af; }}
    .PUT {{ background: #fef3c7; color: #92400e; }}
    .DELETE {{ background: #fee2e2; color: #991b1b; }}
    .path {{ font-family: monospace; font-weight: 600; font-size: 14px; }}
    .summary {{ color: #475569; margin-top: 6px; font-size: 14px; }}
    .try-btn {{ margin-top: 8px; background: #0f766e; color: #fff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 12px; cursor: pointer; }}
    pre {{ background: #0f172a; color: #e2e8f0; padding: 12px; border-radius: 6px; overflow-x: auto; font-size: 12px; margin-top: 8px; }}
  </style>
</head>
<body>
  <div class="topbar">
    <div><strong>Bus Pass Expiry Tracker</strong> · OpenAPI 3.0.3 Reference</div>
    <div><a href="{spec_url}">Download openapi.json</a> &nbsp;|&nbsp; <a href="/">Return to App</a></div>
  </div>
  <div class="container">
    <div id="api-root">Loading OpenAPI specification...</div>
  </div>
  <script>
    fetch("{spec_url}")
      .then(r => r.json())
      .then(spec => {{
        const root = document.getElementById("api-root");
        let html = `<p style="color:#475569;margin-bottom:20px;">${{spec.info.description}}</p>`;
        for (const [path, methods] of Object.entries(spec.paths || {{}})) {{
          for (const [method, meta] of Object.entries(methods)) {{
            const upper = method.toUpperCase();
            const id = btoa(upper + path).replace(/[^a-zA-Z0-9]/g, "");
            html += `<div class="endpoint">
              <div><span class="method ${{upper}}">${{upper}}</span><span class="path">${{path}}</span></div>
              <div class="summary">${{meta.summary || ""}}</div>
              ${{upper === "GET" && !path.includes("{{") ? `<button class="try-btn" onclick="tryGet('${{path}}', '${{id}}')">Try GET</button><pre id="out-${{id}}" style="display:none"></pre>` : ""}}
            </div>`;
          }}
        }}
        root.innerHTML = html;
      }});
    function tryGet(path, id) {{
      const pre = document.getElementById("out-" + id);
      pre.style.display = "block";
      pre.textContent = "Fetching " + path + "...";
      fetch(path).then(async r => {{
        const ct = r.headers.get("content-type") || "";
        const body = ct.includes("json") ? JSON.stringify(await r.json(), null, 2) : await r.text();
        pre.textContent = "HTTP " + r.status + "\\n" + body.slice(0, 1800);
      }});
    }}
  </script>
</body>
</html>"""
