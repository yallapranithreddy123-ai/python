"""Verified SQLite database backup, restoration, and corruption recovery."""

from __future__ import annotations

import shutil
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from backend.database import DatabaseManager
from backend.repository import AuditLogRepository, BusPassRepository, SettingsRepository
from backend.security import ensure_confined_path, sanitize_filename
from backend.storage import FilePersistenceService
from config import AppConfig


class BackupVerificationError(ValueError):
    """Raised when a backup archive is missing, invalid, or fails SQLite integrity checks."""


class BackupService:
    """Manages online SQLite backups, verification, restore, and recovery."""

    def __init__(
        self,
        config: AppConfig,
        db: DatabaseManager,
        pass_repo: BusPassRepository,
        settings_repo: SettingsRepository,
        audit_repo: AuditLogRepository,
        file_service: FilePersistenceService,
    ) -> None:
        self.config = config
        self.db = db
        self.pass_repo = pass_repo
        self.settings_repo = settings_repo
        self.audit_repo = audit_repo
        self.file_service = file_service

    def create_backup(self, prefix: str = "backup") -> Dict[str, Any]:
        """Create an atomic, integrity-verified SQLite backup inside backups/."""
        self.config.ensure_directories()
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
        safe_prefix = sanitize_filename(f"{prefix}_{ts}.db", allowed_extensions=[".db"])
        target_path = ensure_confined_path(self.config.backup_dir, safe_prefix)

        fd, tmp_name = tempfile.mkstemp(prefix=".bak_", suffix=".db", dir=str(self.config.backup_dir))
        tmp_path = Path(tmp_name)
        try:
            # Close raw fd; sqlite3.connect opens it by path
            import os
            os.close(fd)

            with self.db.connection() as source_conn:
                dest_conn = sqlite3.connect(str(tmp_path))
                try:
                    source_conn.backup(dest_conn)
                    dest_conn.commit()
                finally:
                    dest_conn.close()

            self._verify_sqlite_file(tmp_path)
            shutil.move(str(tmp_path), str(target_path))
        except Exception:
            if tmp_path.exists():
                tmp_path.unlink(missing_ok=True)
            raise

        size_bytes = target_path.stat().st_size
        self.audit_repo.record(
            action="BACKUP_CREATE",
            entity_type="database",
            entity_id=target_path.name,
            description=f"Created verified SQLite backup '{target_path.name}' ({size_bytes} bytes).",
        )
        self.file_service.append_audit_log_file(
            "BACKUP_CREATE",
            "database",
            target_path.name,
            f"Verified backup created ({size_bytes} bytes).",
        )
        return {
            "filename": target_path.name,
            "size_bytes": size_bytes,
            "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "verified": True,
        }

    def list_backups(self) -> List[Dict[str, Any]]:
        """List available backup files inside backups/ sorted newest first."""
        self.config.ensure_directories()
        entries: List[Dict[str, Any]] = []
        for path in sorted(self.config.backup_dir.glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True):
            stat = path.stat()
            entries.append(
                {
                    "filename": path.name,
                    "size_bytes": stat.st_size,
                    "modified_at": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).strftime(
                        "%Y-%m-%dT%H:%M:%SZ"
                    ),
                }
            )
        return entries

    def restore_backup(self, filename: str) -> Dict[str, Any]:
        """Verify backup integrity, create a pre-restore safety snapshot, and restore SQLite DB."""
        safe_name = sanitize_filename(filename, allowed_extensions=[".db"])
        backup_path = ensure_confined_path(self.config.backup_dir, safe_name)
        if not backup_path.exists():
            raise FileNotFoundError(f"Backup file '{safe_name}' does not exist.")

        self._verify_sqlite_file(backup_path)

        # Create pre-restore safety backup if live DB is healthy
        pre_restore_name = None
        if self.db.db_path.exists() and self.db.check_integrity().get("ok"):
            pre_info = self.create_backup(prefix="pre_restore")
            pre_restore_name = pre_info["filename"]

        # Restore using SQLite online backup API into live database
        src_conn = sqlite3.connect(str(backup_path))
        try:
            with self.db.connection() as live_conn:
                src_conn.backup(live_conn)
                live_conn.commit()
        finally:
            src_conn.close()

        # Re-sync flat files and log recovery
        self.db.initialize()
        settings = self.settings_repo.get()
        passes = self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC")
        self.file_service.sync_files(passes, mode=settings.storage_sync_mode)
        self.audit_repo.record(
            action="BACKUP_RESTORE",
            entity_type="database",
            entity_id=safe_name,
            description=f"Restored database from verified backup '{safe_name}' ({len(passes)} pass records).",
        )
        self.file_service.append_audit_log_file(
            "BACKUP_RESTORE",
            "database",
            safe_name,
            f"Database restored ({len(passes)} records).",
        )
        return {
            "restored_from": safe_name,
            "pre_restore_backup": pre_restore_name,
            "record_count": len(passes),
            "integrity": self.db.check_integrity(),
        }

    def verify_and_recover_startup(self) -> List[str]:
        """Check SQLite integrity on startup and automatically recover from valid backup or JSON/CSV if damaged."""
        notes: List[str] = []
        if self.db.db_path.exists():
            integrity = self.db.check_integrity()
            if not integrity.get("ok"):
                quarantined = self.db.quarantine_corrupted_db()
                notes.append(
                    f"Corrupted database preserved at '{quarantined.name if quarantined else 'quarantine'}'."
                )
                self.db.initialize()
                # Attempt recovery from newest verified backup, else JSON/CSV
                recovered = False
                for candidate in self.list_backups():
                    try:
                        res = self.restore_backup(candidate["filename"])
                        notes.append(f"Recovered {res['record_count']} record(s) from backup '{candidate['filename']}'.")
                        recovered = True
                        break
                    except Exception:
                        continue
                if not recovered and self.config.json_path.exists():
                    try:
                        loaded, _ = self.file_service.load_json_records(self.config.json_path)
                        self.pass_repo.replace_all(loaded)
                        notes.append(f"Recovered {len(loaded)} record(s) from local JSON fallback.")
                    except Exception:
                        pass
        else:
            self.db.initialize()

        # Ensure CSV/JSON files are healthy too
        settings = self.settings_repo.get()
        passes = self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC")
        notes.extend(self.file_service.recover_if_corrupted(passes, mode=settings.storage_sync_mode))
        return notes

    @staticmethod
    def _verify_sqlite_file(path: Path) -> None:
        """Open a SQLite file and verify PRAGMA integrity_check and required schema tables."""
        try:
            conn = sqlite3.connect(str(path))
            try:
                rows = conn.execute("PRAGMA integrity_check;").fetchall()
                if not rows or str(rows[0][0]).lower() != "ok":
                    raise BackupVerificationError("Backup failed SQLite PRAGMA integrity_check.")
                tables = {
                    str(r[0])
                    for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()
                }
                if "bus_passes" not in tables:
                    raise BackupVerificationError("Backup file does not contain the 'bus_passes' table.")
            finally:
                conn.close()
        except sqlite3.DatabaseError as exc:
            raise BackupVerificationError(f"Backup file is not a valid SQLite database: {exc}") from exc
