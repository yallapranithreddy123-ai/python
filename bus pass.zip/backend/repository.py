"""SQLite Data Access Layer repositories using parameterized queries."""

from __future__ import annotations

import math
import sqlite3
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

from backend.database import DatabaseManager
from backend.models import AppSettings, AuditLogEntry, BusPass, PaginationResult


class DuplicatePassError(ValueError):
    """Raised when inserting a pass with an existing unique pass_id."""


class PassNotFoundError(LookupError):
    """Raised when a requested bus pass does not exist."""


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _row_to_bus_pass(row: sqlite3.Row) -> BusPass:
    return BusPass(
        id=int(row["id"]),
        pass_id=str(row["pass_id"]),
        holder_name=str(row["holder_name"]),
        mobile_number=str(row["mobile_number"]),
        route=str(row["route"]),
        category=str(row["category"]),
        issue_date=str(row["issue_date"]),
        expiry_date=str(row["expiry_date"]),
        fee=float(row["fee"]),
        notes=str(row["notes"]),
        created_at=str(row["created_at"]),
        updated_at=str(row["updated_at"]),
    )


class BusPassRepository:
    """Repository for parameterized SQLite CRUD, search, and paginated queries."""

    ALLOWED_SORT_COLUMNS: Dict[str, str] = {
        "pass_id": "pass_id",
        "holder_name": "holder_name",
        "route": "route",
        "category": "category",
        "issue_date": "issue_date",
        "expiry_date": "expiry_date",
        "fee": "fee",
        "created_at": "created_at",
        "updated_at": "updated_at",
    }

    def __init__(self, db: DatabaseManager) -> None:
        self.db = db

    def create(self, bus_pass: BusPass) -> BusPass:
        """Insert a new bus pass atomically, guarding against duplicate pass_id."""
        now_iso = _utc_now_iso()
        created_at = bus_pass.created_at or now_iso
        updated_at = bus_pass.updated_at or now_iso

        try:
            with self.db.transaction() as conn:
                cursor = conn.execute(
                    """
                    INSERT INTO bus_passes (
                        pass_id, holder_name, mobile_number, route, category,
                        issue_date, expiry_date, fee, notes, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                    """,
                    (
                        bus_pass.pass_id,
                        bus_pass.holder_name,
                        bus_pass.mobile_number,
                        bus_pass.route,
                        bus_pass.category,
                        bus_pass.issue_date,
                        bus_pass.expiry_date,
                        round(float(bus_pass.fee), 2),
                        bus_pass.notes,
                        created_at,
                        updated_at,
                    ),
                )
                new_id = cursor.lastrowid
                row = conn.execute("SELECT * FROM bus_passes WHERE id = ?;", (new_id,)).fetchone()
                return _row_to_bus_pass(row)
        except sqlite3.IntegrityError as exc:
            if "unique" in str(exc).lower() or "pass_id" in str(exc).lower():
                raise DuplicatePassError(f"Bus pass '{bus_pass.pass_id}' already exists.") from exc
            raise

    def bulk_insert_ignore_duplicates(self, passes: List[BusPass]) -> Tuple[List[BusPass], List[str]]:
        """Insert multiple passes in a single transaction, returning inserted passes and duplicate IDs."""
        now_iso = _utc_now_iso()
        inserted: List[BusPass] = []
        duplicates: List[str] = []

        with self.db.transaction() as conn:
            for item in passes:
                existing = conn.execute(
                    "SELECT 1 FROM bus_passes WHERE pass_id = ?;",
                    (item.pass_id,),
                ).fetchone()
                if existing:
                    duplicates.append(item.pass_id)
                    continue

                created_at = item.created_at or now_iso
                updated_at = item.updated_at or now_iso
                cursor = conn.execute(
                    """
                    INSERT INTO bus_passes (
                        pass_id, holder_name, mobile_number, route, category,
                        issue_date, expiry_date, fee, notes, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                    """,
                    (
                        item.pass_id,
                        item.holder_name,
                        item.mobile_number,
                        item.route,
                        item.category,
                        item.issue_date,
                        item.expiry_date,
                        round(float(item.fee), 2),
                        item.notes,
                        created_at,
                        updated_at,
                    ),
                )
                row = conn.execute("SELECT * FROM bus_passes WHERE id = ?;", (cursor.lastrowid,)).fetchone()
                inserted.append(_row_to_bus_pass(row))

        return inserted, duplicates

    def get_by_pass_id(self, pass_id: str) -> Optional[BusPass]:
        with self.db.connection() as conn:
            row = conn.execute("SELECT * FROM bus_passes WHERE pass_id = ?;", (pass_id.upper(),)).fetchone()
            return _row_to_bus_pass(row) if row else None

    def update(self, pass_id: str, fields: Dict[str, Any]) -> BusPass:
        """Update an existing bus pass by pass_id inside a transaction."""
        now_iso = _utc_now_iso()
        with self.db.transaction() as conn:
            existing = conn.execute("SELECT * FROM bus_passes WHERE pass_id = ?;", (pass_id.upper(),)).fetchone()
            if not existing:
                raise PassNotFoundError(f"Bus pass '{pass_id}' was not found.")

            conn.execute(
                """
                UPDATE bus_passes
                SET holder_name = ?,
                    mobile_number = ?,
                    route = ?,
                    category = ?,
                    issue_date = ?,
                    expiry_date = ?,
                    fee = ?,
                    notes = ?,
                    updated_at = ?
                WHERE pass_id = ?;
                """,
                (
                    fields["holder_name"],
                    fields["mobile_number"],
                    fields["route"],
                    fields["category"],
                    fields["issue_date"],
                    fields["expiry_date"],
                    round(float(fields["fee"]), 2),
                    fields.get("notes", ""),
                    now_iso,
                    pass_id.upper(),
                ),
            )
            updated = conn.execute("SELECT * FROM bus_passes WHERE pass_id = ?;", (pass_id.upper(),)).fetchone()
            return _row_to_bus_pass(updated)

    def delete(self, pass_id: str) -> BusPass:
        """Delete a bus pass by pass_id and return the deleted record."""
        with self.db.transaction() as conn:
            existing = conn.execute("SELECT * FROM bus_passes WHERE pass_id = ?;", (pass_id.upper(),)).fetchone()
            if not existing:
                raise PassNotFoundError(f"Bus pass '{pass_id}' was not found.")
            conn.execute("DELETE FROM bus_passes WHERE pass_id = ?;", (pass_id.upper(),))
            return _row_to_bus_pass(existing)

    def count_all(self) -> int:
        with self.db.connection() as conn:
            row = conn.execute("SELECT COUNT(*) AS cnt FROM bus_passes;").fetchone()
            return int(row["cnt"]) if row else 0

    def list_all(self, order_by: str = "expiry_date", sort_dir: str = "ASC") -> List[BusPass]:
        col = self.ALLOWED_SORT_COLUMNS.get(order_by, "expiry_date")
        direction = "DESC" if str(sort_dir).upper() == "DESC" else "ASC"
        with self.db.connection() as conn:
            rows = conn.execute(f"SELECT * FROM bus_passes ORDER BY {col} {direction}, pass_id ASC;").fetchall()
            return [_row_to_bus_pass(r) for r in rows]

    def query_paginated(
        self,
        *,
        page: int = 1,
        page_size: int = 15,
        query: str = "",
        category: str = "",
        status: str = "",
        expiry_from: str = "",
        expiry_to: str = "",
        sort_by: str = "expiry_date",
        sort_dir: str = "asc",
        warning_days: int = 7,
        reference_date: Optional[date] = None,
    ) -> PaginationResult:
        """Execute indexed SQL filtering, sorting, and LIMIT/OFFSET pagination."""
        safe_page = max(1, int(page))
        safe_page_size = max(1, min(100, int(page_size)))
        col = self.ALLOWED_SORT_COLUMNS.get(sort_by, "expiry_date")
        direction = "DESC" if str(sort_dir).lower() == "desc" else "ASC"

        today = reference_date or date.today()
        today_str = today.strftime("%Y-%m-%d")
        warn_cutoff_str = (today + timedelta(days=warning_days)).strftime("%Y-%m-%d")

        clauses: List[str] = []
        params: List[Any] = []

        if query.strip():
            like_val = f"%{query.strip()}%"
            clauses.append(
                "(pass_id LIKE ? OR holder_name LIKE ? OR mobile_number LIKE ? OR route LIKE ?)"
            )
            params.extend([like_val, like_val, like_val, like_val])

        if category.strip() and category.strip().lower() != "all":
            clauses.append("LOWER(category) = LOWER(?)")
            params.append(category.strip())

        if expiry_from.strip():
            clauses.append("expiry_date >= ?")
            params.append(expiry_from.strip())

        if expiry_to.strip():
            clauses.append("expiry_date <= ?")
            params.append(expiry_to.strip())

        norm_status = status.strip().lower()
        if norm_status and norm_status != "all":
            if norm_status == "expired":
                clauses.append("expiry_date < ?")
                params.append(today_str)
            elif norm_status in {"expires today", "expires_today"}:
                clauses.append("expiry_date = ?")
                params.append(today_str)
            elif norm_status in {"expiring soon", "expiring_soon"}:
                clauses.append("expiry_date > ? AND expiry_date <= ?")
                params.extend([today_str, warn_cutoff_str])
            elif norm_status == "active":
                clauses.append("expiry_date > ?")
                params.append(warn_cutoff_str)

        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        offset = (safe_page - 1) * safe_page_size

        with self.db.connection() as conn:
            count_row = conn.execute(
                f"SELECT COUNT(*) AS cnt FROM bus_passes {where_sql};",
                params,
            ).fetchone()
            total_count = int(count_row["cnt"]) if count_row else 0
            total_pages = max(1, math.ceil(total_count / safe_page_size)) if total_count > 0 else 1

            # Clamp requested page if it exceeds total_pages
            if safe_page > total_pages:
                safe_page = total_pages
                offset = (safe_page - 1) * safe_page_size

            rows = conn.execute(
                f"""
                SELECT * FROM bus_passes
                {where_sql}
                ORDER BY {col} {direction}, id ASC
                LIMIT ? OFFSET ?;
                """,
                [*params, safe_page_size, offset],
            ).fetchall()

        return PaginationResult(
            items=[_row_to_bus_pass(r) for r in rows],
            total_count=total_count,
            page=safe_page,
            page_size=safe_page_size,
            total_pages=total_pages,
        )

    def replace_all(self, passes: List[BusPass]) -> int:
        """Atomically replace all rows in bus_passes (used during verified backup/restore)."""
        now_iso = _utc_now_iso()
        with self.db.transaction() as conn:
            conn.execute("DELETE FROM bus_passes;")
            for item in passes:
                conn.execute(
                    """
                    INSERT INTO bus_passes (
                        pass_id, holder_name, mobile_number, route, category,
                        issue_date, expiry_date, fee, notes, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                    """,
                    (
                        item.pass_id,
                        item.holder_name,
                        item.mobile_number,
                        item.route,
                        item.category,
                        item.issue_date,
                        item.expiry_date,
                        round(float(item.fee), 2),
                        item.notes,
                        item.created_at or now_iso,
                        item.updated_at or now_iso,
                    ),
                )
        return len(passes)


class SettingsRepository:
    """Repository for application configuration stored in SQLite."""

    def __init__(self, db: DatabaseManager) -> None:
        self.db = db

    def get(self) -> AppSettings:
        with self.db.connection() as conn:
            row = conn.execute("SELECT * FROM application_settings WHERE id = 1;").fetchone()
            if not row:
                return AppSettings(updated_at=_utc_now_iso())
            return AppSettings(
                expiry_warning_days=int(row["expiry_warning_days"]),
                storage_sync_mode=str(row["storage_sync_mode"]),
                default_page_size=int(row["default_page_size"]),
                updated_at=str(row["updated_at"]),
            )

    def update(self, settings: Dict[str, Any]) -> AppSettings:
        now_iso = _utc_now_iso()
        with self.db.transaction() as conn:
            conn.execute(
                """
                UPDATE application_settings
                SET expiry_warning_days = ?,
                    storage_sync_mode = ?,
                    default_page_size = ?,
                    updated_at = ?
                WHERE id = 1;
                """,
                (
                    int(settings["expiry_warning_days"]),
                    str(settings["storage_sync_mode"]),
                    int(settings["default_page_size"]),
                    now_iso,
                ),
            )
        return self.get()


class AuditLogRepository:
    """Repository for system operation audit trail."""

    def __init__(self, db: DatabaseManager) -> None:
        self.db = db

    def record(self, action: str, entity_type: str, entity_id: str, description: str) -> AuditLogEntry:
        ts = _utc_now_iso()
        with self.db.transaction() as conn:
            cursor = conn.execute(
                """
                INSERT INTO audit_logs (action, entity_type, entity_id, description, timestamp)
                VALUES (?, ?, ?, ?, ?);
                """,
                (action, entity_type, entity_id, description, ts),
            )
            return AuditLogEntry(
                id=cursor.lastrowid,
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                description=description,
                timestamp=ts,
            )

    def list_recent(self, limit: int = 50) -> List[AuditLogEntry]:
        safe_limit = max(1, min(500, int(limit)))
        with self.db.connection() as conn:
            rows = conn.execute(
                "SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?;",
                (safe_limit,),
            ).fetchall()
            return [
                AuditLogEntry(
                    id=int(r["id"]),
                    action=str(r["action"]),
                    entity_type=str(r["entity_type"]),
                    entity_id=str(r["entity_id"]),
                    description=str(r["description"]),
                    timestamp=str(r["timestamp"]),
                )
                for r in rows
            ]
