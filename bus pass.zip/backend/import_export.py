"""Bulk CSV/JSON import with row-by-row error diagnostics and atomic export."""

from __future__ import annotations

import csv
import io
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Tuple

from backend.models import BusPass, ImportResult, ImportRowError
from backend.repository import AuditLogRepository, BusPassRepository, SettingsRepository
from backend.storage import CorruptedStorageError, FilePersistenceService
from backend.validation import ValidationException, ValidationService
from config import AppConfig


class ImportExportService:
    """Handles validated bulk CSV imports and standardized CSV/JSON exports."""

    def __init__(
        self,
        config: AppConfig,
        pass_repo: BusPassRepository,
        settings_repo: SettingsRepository,
        audit_repo: AuditLogRepository,
        file_service: FilePersistenceService,
    ) -> None:
        self.config = config
        self.pass_repo = pass_repo
        self.settings_repo = settings_repo
        self.audit_repo = audit_repo
        self.file_service = file_service

    def import_csv_text(self, csv_text: str) -> ImportResult:
        """Validate CSV headers and every row individually, inserting valid non-duplicate records."""
        if not csv_text or not csv_text.strip():
            raise CorruptedStorageError("CSV content is empty.")

        try:
            reader = csv.DictReader(io.StringIO(csv_text))
            ValidationService.validate_csv_headers(list(reader.fieldnames) if reader.fieldnames else None)
        except (csv.Error, ValueError) as exc:
            raise CorruptedStorageError(str(exc)) from exc

        total_rows = 0
        valid_candidates: List[BusPass] = []
        row_errors: List[ImportRowError] = []
        seen_in_file: set[str] = set()
        skipped_duplicates = 0

        try:
            for row_idx, raw_row in enumerate(reader, start=2):
                total_rows += 1
                normalized: Dict[str, Any] = {
                    (k.strip().lower() if isinstance(k, str) else ""): v
                    for k, v in raw_row.items()
                    if k is not None
                }
                raw_pid = ValidationService.sanitize_text(normalized.get("pass_id", "")).upper() or f"ROW-{row_idx}"

                try:
                    cleaned = ValidationService.validate_pass_payload(normalized)
                except ValidationException as exc:
                    row_errors.append(
                        ImportRowError(
                            row_number=row_idx,
                            pass_id=raw_pid,
                            errors=list(exc.field_errors.values()),
                        )
                    )
                    continue

                if cleaned["pass_id"] in seen_in_file:
                    skipped_duplicates += 1
                    row_errors.append(
                        ImportRowError(
                            row_number=row_idx,
                            pass_id=cleaned["pass_id"],
                            errors=[f"Duplicate pass_id '{cleaned['pass_id']}' within uploaded CSV."],
                        )
                    )
                    continue

                seen_in_file.add(cleaned["pass_id"])
                valid_candidates.append(
                    BusPass(
                        pass_id=cleaned["pass_id"],
                        holder_name=cleaned["holder_name"],
                        mobile_number=cleaned["mobile_number"],
                        route=cleaned["route"],
                        category=cleaned["category"],
                        issue_date=cleaned["issue_date"],
                        expiry_date=cleaned["expiry_date"],
                        fee=cleaned["fee"],
                        notes=cleaned["notes"],
                        created_at=ValidationService.sanitize_text(normalized.get("created_at", "")),
                        updated_at=ValidationService.sanitize_text(normalized.get("updated_at", "")),
                    )
                )
        except csv.Error as exc:
            raise CorruptedStorageError(f"Malformed CSV syntax encountered: {exc}") from exc

        inserted, db_duplicates = self.pass_repo.bulk_insert_ignore_duplicates(valid_candidates)
        for dup_id in db_duplicates:
            skipped_duplicates += 1
            row_errors.append(
                ImportRowError(
                    row_number=0,
                    pass_id=dup_id,
                    errors=[f"Pass ID '{dup_id}' already exists in database."],
                )
            )

        if inserted:
            settings = self.settings_repo.get()
            all_passes = self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC")
            self.file_service.sync_files(all_passes, mode=settings.storage_sync_mode)
            self.audit_repo.record(
                action="BULK_IMPORT_CSV",
                entity_type="bus_pass",
                entity_id=f"{len(inserted)}_records",
                description=f"Imported {len(inserted)} pass(es) from CSV; {len(row_errors)} row issue(s).",
            )
            self.file_service.append_audit_log_file(
                "BULK_IMPORT_CSV",
                "bus_pass",
                f"{len(inserted)}_records",
                f"Imported {len(inserted)} pass(es); {len(row_errors)} error(s).",
            )

        return ImportResult(
            total_rows=total_rows,
            imported_count=len(inserted),
            failed_count=len(row_errors),
            skipped_duplicates=skipped_duplicates,
            row_errors=row_errors,
            imported_pass_ids=[p.pass_id for p in inserted],
        )

    def import_json_text(self, json_text: str) -> ImportResult:
        """Validate JSON dataset and insert valid non-duplicate records."""
        if not json_text or not json_text.strip():
            raise CorruptedStorageError("JSON content is empty.")
        try:
            parsed = json.loads(json_text)
            records = ValidationService.validate_json_records_schema(parsed)
        except (json.JSONDecodeError, ValueError) as exc:
            raise CorruptedStorageError(f"Invalid JSON dataset: {exc}") from exc

        total_rows = len(records)
        valid_candidates: List[BusPass] = []
        row_errors: List[ImportRowError] = []
        seen_in_file: set[str] = set()
        skipped_duplicates = 0

        for idx, rec in enumerate(records, start=1):
            raw_pid = ValidationService.sanitize_text(rec.get("pass_id", "")).upper() or f"ITEM-{idx}"
            try:
                cleaned = ValidationService.validate_pass_payload(rec)
            except ValidationException as exc:
                row_errors.append(
                    ImportRowError(row_number=idx, pass_id=raw_pid, errors=list(exc.field_errors.values()))
                )
                continue

            if cleaned["pass_id"] in seen_in_file:
                skipped_duplicates += 1
                row_errors.append(
                    ImportRowError(
                        row_number=idx,
                        pass_id=cleaned["pass_id"],
                        errors=[f"Duplicate pass_id '{cleaned['pass_id']}' within uploaded JSON."],
                    )
                )
                continue

            seen_in_file.add(cleaned["pass_id"])
            valid_candidates.append(
                BusPass(
                    pass_id=cleaned["pass_id"],
                    holder_name=cleaned["holder_name"],
                    mobile_number=cleaned["mobile_number"],
                    route=cleaned["route"],
                    category=cleaned["category"],
                    issue_date=cleaned["issue_date"],
                    expiry_date=cleaned["expiry_date"],
                    fee=cleaned["fee"],
                    notes=cleaned["notes"],
                    created_at=ValidationService.sanitize_text(rec.get("created_at", "")),
                    updated_at=ValidationService.sanitize_text(rec.get("updated_at", "")),
                )
            )

        inserted, db_duplicates = self.pass_repo.bulk_insert_ignore_duplicates(valid_candidates)
        for dup_id in db_duplicates:
            skipped_duplicates += 1
            row_errors.append(
                ImportRowError(
                    row_number=0,
                    pass_id=dup_id,
                    errors=[f"Pass ID '{dup_id}' already exists in database."],
                )
            )

        if inserted:
            settings = self.settings_repo.get()
            all_passes = self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC")
            self.file_service.sync_files(all_passes, mode=settings.storage_sync_mode)
            self.audit_repo.record(
                action="BULK_IMPORT_JSON",
                entity_type="bus_pass",
                entity_id=f"{len(inserted)}_records",
                description=f"Imported {len(inserted)} pass(es) from JSON; {len(row_errors)} row issue(s).",
            )

        return ImportResult(
            total_rows=total_rows,
            imported_count=len(inserted),
            failed_count=len(row_errors),
            skipped_duplicates=skipped_duplicates,
            row_errors=row_errors,
            imported_pass_ids=[p.pass_id for p in inserted],
        )

    def export_csv(self) -> Tuple[str, str]:
        """Export current SQLite records to standardized CSV string."""
        all_passes = self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC")
        content = self.file_service.serialize_csv(all_passes)
        filename = f"bus_passes_export_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.csv"
        return filename, content

    def export_json(self) -> Tuple[str, str]:
        """Export current SQLite records to schema-versioned JSON string."""
        all_passes = self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC")
        content = self.file_service.serialize_json(all_passes)
        filename = f"bus_passes_export_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
        return filename, content
