"""Centralized defensive input and schema validation for Bus Pass Expiry Tracker."""

from __future__ import annotations

import math
import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from backend.models import CSV_FIELDNAMES, PASS_CATEGORIES, STORAGE_FORMATS


class ValidationException(ValueError):
    """Raised when domain validation fails, carrying field-level error diagnostics."""

    def __init__(self, field_errors: Dict[str, str], message: str = "Validation failed.") -> None:
        super().__init__(message)
        self.field_errors = field_errors
        self.message = message


class ValidationService:
    """Stateless reusable validators for forms, APIs, CSV rows, and JSON payloads."""

    PASS_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{2,31}$")
    HOLDER_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'-]{1,79}$")
    MOBILE_RE = re.compile(r"^\+?[0-9]{10,15}$")
    DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

    REQUIRED_IMPORT_COLUMNS = (
        "pass_id",
        "holder_name",
        "mobile_number",
        "route",
        "category",
        "issue_date",
        "expiry_date",
    )

    @classmethod
    def sanitize_text(cls, value: Any) -> str:
        """Normalize arbitrary input into stripped single-spaced text."""
        if value is None:
            return ""
        if not isinstance(value, str):
            value = str(value)
        return re.sub(r"\s+", " ", value).strip()

    @classmethod
    def validate_pass_id(cls, value: Any) -> str:
        text = cls.sanitize_text(value).upper()
        if not text:
            raise ValueError("Pass ID is required.")
        if not cls.PASS_ID_RE.match(text):
            raise ValueError(
                "Pass ID must be 3–32 characters using letters, numbers, hyphens, or underscores (e.g., BP-2026-001)."
            )
        return text

    @classmethod
    def validate_holder_name(cls, value: Any) -> str:
        text = cls.sanitize_text(value)
        if not text:
            raise ValueError("Pass holder's full name is required.")
        if len(text) < 2 or len(text) > 80:
            raise ValueError("Full name must be between 2 and 80 characters.")
        if not cls.HOLDER_NAME_RE.match(text):
            raise ValueError("Full name may only contain letters, spaces, periods, hyphens, and apostrophes.")
        return text

    @classmethod
    def validate_mobile_number(cls, value: Any) -> str:
        raw = cls.sanitize_text(value)
        if not raw:
            raise ValueError("Mobile number is required.")
        # Strip common visual separators like spaces, dashes, parentheses
        compact = re.sub(r"[\s()-]", "", raw)
        if not cls.MOBILE_RE.match(compact):
            raise ValueError("Mobile number must contain 10 to 15 digits (optional leading '+').")
        return compact

    @classmethod
    def validate_route(cls, value: Any) -> str:
        text = cls.sanitize_text(value)
        if not text:
            raise ValueError("Bus route or route information is required.")
        if len(text) < 2 or len(text) > 120:
            raise ValueError("Route description must be between 2 and 120 characters.")
        return text

    @classmethod
    def validate_category(cls, value: Any) -> str:
        text = cls.sanitize_text(value)
        if not text:
            raise ValueError("Pass category is required.")
        # Match case-insensitively to canonical category names
        lookup = {cat.lower(): cat for cat in PASS_CATEGORIES}
        canonical = lookup.get(text.lower())
        if not canonical:
            raise ValueError(f"Category must be one of: {', '.join(PASS_CATEGORIES)}.")
        return canonical

    @classmethod
    def validate_date_str(cls, value: Any, label: str) -> str:
        text = cls.sanitize_text(value)
        if not text:
            raise ValueError(f"{label} is required.")
        if not cls.DATE_RE.match(text):
            raise ValueError(f"{label} must use YYYY-MM-DD format (e.g., 2026-11-24).")
        try:
            parsed = datetime.strptime(text, "%Y-%m-%d").date()
        except ValueError as exc:
            raise ValueError(f"{label} is not a valid calendar date.") from exc

        if parsed.year < 2000 or parsed.year > 2100:
            raise ValueError(f"{label} year must be between 2000 and 2100.")
        return parsed.strftime("%Y-%m-%d")

    @classmethod
    def validate_fee(cls, value: Any) -> float:
        if value is None or (isinstance(value, str) and not value.strip()):
            return 0.0
        if isinstance(value, bool):
            raise ValueError("Pass fee must be a valid number.")
        try:
            fee = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError("Pass fee must be a valid non-negative number.") from exc

        if math.isnan(fee) or math.isinf(fee):
            raise ValueError("Pass fee must be a finite number.")
        if fee < 0:
            raise ValueError("Pass fee cannot be negative.")
        if fee > 100000:
            raise ValueError("Pass fee cannot exceed 100,000.")
        return round(fee, 2)

    @classmethod
    def validate_notes(cls, value: Any) -> str:
        if value is None:
            return ""
        text = cls.sanitize_text(value)
        if len(text) > 500:
            raise ValueError("Additional notes cannot exceed 500 characters.")
        return text

    @classmethod
    def validate_pass_payload(
        cls,
        payload: Dict[str, Any],
        is_update: bool = False,
        existing_pass_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Validate a complete bus pass dictionary, returning sanitized fields or raising ValidationException."""
        if not isinstance(payload, dict):
            raise ValidationException({"_form": "Payload must be a JSON object."})

        errors: Dict[str, str] = {}
        cleaned: Dict[str, Any] = {}

        if is_update and existing_pass_id:
            cleaned["pass_id"] = existing_pass_id
        else:
            try:
                cleaned["pass_id"] = cls.validate_pass_id(payload.get("pass_id"))
            except ValueError as exc:
                errors["pass_id"] = str(exc)

        validators = (
            ("holder_name", cls.validate_holder_name),
            ("mobile_number", cls.validate_mobile_number),
            ("route", cls.validate_route),
            ("category", cls.validate_category),
            ("fee", cls.validate_fee),
            ("notes", cls.validate_notes),
        )
        for key, fn in validators:
            try:
                cleaned[key] = fn(payload.get(key))
            except ValueError as exc:
                errors[key] = str(exc)

        issue_valid: Optional[str] = None
        expiry_valid: Optional[str] = None
        try:
            issue_valid = cls.validate_date_str(payload.get("issue_date"), "Issue date")
            cleaned["issue_date"] = issue_valid
        except ValueError as exc:
            errors["issue_date"] = str(exc)

        try:
            expiry_valid = cls.validate_date_str(payload.get("expiry_date"), "Expiry date")
            cleaned["expiry_date"] = expiry_valid
        except ValueError as exc:
            errors["expiry_date"] = str(exc)

        if issue_valid and expiry_valid:
            issue_dt = datetime.strptime(issue_valid, "%Y-%m-%d").date()
            expiry_dt = datetime.strptime(expiry_valid, "%Y-%m-%d").date()
            if expiry_dt < issue_dt:
                errors["expiry_date"] = "Expiry date cannot be earlier than the issue date."
            elif (expiry_dt - issue_dt).days > 3660:
                errors["expiry_date"] = "Pass validity span cannot exceed 10 years (3660 days)."

        if errors:
            raise ValidationException(errors, message="One or more bus pass fields failed validation.")

        return cleaned

    @classmethod
    def validate_csv_headers(cls, fieldnames: Optional[List[str]]) -> List[str]:
        """Validate that an imported CSV file contains all mandatory headers."""
        if not fieldnames:
            raise ValueError("CSV file is missing a header row.")
        normalized = [h.strip().lower() for h in fieldnames if h is not None]
        missing = [col for col in cls.REQUIRED_IMPORT_COLUMNS if col not in normalized]
        if missing:
            raise ValueError(f"CSV is missing required column(s): {', '.join(missing)}.")
        return normalized

    @classmethod
    def validate_json_records_schema(cls, data: Any) -> List[Dict[str, Any]]:
        """Validate the top-level structure of an imported or stored JSON dataset."""
        if isinstance(data, dict) and "records" in data and isinstance(data["records"], list):
            records = data["records"]
        elif isinstance(data, list):
            records = data
        else:
            raise ValueError("JSON dataset must be a list of pass objects or an object containing a 'records' list.")

        for idx, item in enumerate(records, start=1):
            if not isinstance(item, dict):
                raise ValueError(f"JSON record at index {idx} must be an object.")
        return records

    @classmethod
    def validate_settings_payload(cls, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Validate configurable application settings."""
        if not isinstance(payload, dict):
            raise ValidationException({"_form": "Settings payload must be a JSON object."})

        errors: Dict[str, str] = {}
        cleaned: Dict[str, Any] = {}

        raw_warn = payload.get("expiry_warning_days", 7)
        try:
            if isinstance(raw_warn, bool):
                raise ValueError("Warning threshold must be an integer.")
            warn_days = int(raw_warn)
            if warn_days < 1 or warn_days > 90:
                raise ValueError("Expiry warning threshold must be between 1 and 90 days.")
            cleaned["expiry_warning_days"] = warn_days
        except (TypeError, ValueError) as exc:
            errors["expiry_warning_days"] = str(exc)

        raw_mode = cls.sanitize_text(payload.get("storage_sync_mode", "sqlite+csv+json")).lower()
        if raw_mode not in STORAGE_FORMATS:
            errors["storage_sync_mode"] = f"Storage sync mode must be one of: {', '.join(STORAGE_FORMATS)}."
        else:
            cleaned["storage_sync_mode"] = raw_mode

        raw_page = payload.get("default_page_size", 15)
        try:
            if isinstance(raw_page, bool):
                raise ValueError("Default page size must be an integer.")
            page_size = int(raw_page)
            if page_size < 5 or page_size > 100:
                raise ValueError("Default page size must be between 5 and 100.")
            cleaned["default_page_size"] = page_size
        except (TypeError, ValueError) as exc:
            errors["default_page_size"] = str(exc)

        if errors:
            raise ValidationException(errors, message="Invalid settings configuration.")
        return cleaned

    @classmethod
    def allowed_csv_columns(cls) -> Tuple[str, ...]:
        return CSV_FIELDNAMES
