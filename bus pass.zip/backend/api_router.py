"""Framework-agnostic Python HTTP API router for Bus Pass Expiry Tracker."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, unquote

from backend.analytics import AnalyticsService
from backend.backup import BackupVerificationError
from backend.database import DatabaseBusyError
from backend.models import PASS_CATEGORIES, PASS_STATUSES, STORAGE_FORMATS
from backend.openapi import build_openapi_spec, render_swagger_ui_html
from backend.repository import DuplicatePassError, PassNotFoundError
from backend.security import (
    SECURITY_HEADERS,
    CsrfManager,
    SecurityError,
    safe_error_message,
    validate_upload_payload,
)
from backend.services import ApplicationContainer
from backend.storage import CorruptedStorageError
from backend.validation import ValidationException


@dataclass
class ApiResponse:
    """Normalized HTTP response emitted by ApiRouter."""

    status_code: int
    body: bytes
    content_type: str = "application/json; charset=utf-8"
    headers: Dict[str, str] | None = None


def _json_response(status_code: int, payload: Any, extra_headers: Dict[str, str] | None = None) -> ApiResponse:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = dict(SECURITY_HEADERS)
    if extra_headers:
        headers.update(extra_headers)
    return ApiResponse(status_code=status_code, body=body, content_type="application/json; charset=utf-8", headers=headers)


def _error_response(
    status_code: int,
    message: str,
    field_errors: Optional[Dict[str, str]] = None,
) -> ApiResponse:
    payload: Dict[str, Any] = {"error": message, "code": status_code}
    if field_errors:
        payload["field_errors"] = field_errors
    return _json_response(status_code, payload)


def _parse_multipart_file(content_type: str, raw_body: bytes) -> Tuple[str, bytes]:
    """Extract (filename, bytes) from a multipart/form-data payload using Python stdlib only."""
    match = re.search(r'boundary=([^;\s]+)', content_type, flags=re.IGNORECASE)
    if not match:
        raise SecurityError("Missing multipart boundary.")
    boundary = match.group(1).strip('"').encode("utf-8")
    delimiter = b"--" + boundary
    parts = raw_body.split(delimiter)
    for part in parts[1:]:
        if part.startswith(b"--"):
            continue
        part = part.lstrip(b"\r\n")
        if b"\r\n\r\n" in part:
            header_blob, data_blob = part.split(b"\r\n\r\n", 1)
        elif b"\n\n" in part:
            header_blob, data_blob = part.split(b"\n\n", 1)
        else:
            continue
        headers_text = header_blob.decode("utf-8", errors="replace")
        if 'filename="' in headers_text:
            fn_match = re.search(r'filename="([^"]*)"', headers_text)
            filename = fn_match.group(1) if fn_match else "upload.csv"
            # Strip trailing CRLF before next boundary
            if data_blob.endswith(b"\r\n"):
                data_blob = data_blob[:-2]
            elif data_blob.endswith(b"\n"):
                data_blob = data_blob[:-1]
            return filename, data_blob
    raise SecurityError("No file field found in multipart upload.")


class ApiRouter:
    """Routes HTTP API calls to the Python Business Logic Layer."""

    MUTATING_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

    def __init__(self, container: ApplicationContainer, enforce_csrf: bool = True) -> None:
        self.container = container
        self.csrf = CsrfManager(container.config.secret_key)
        self.enforce_csrf = enforce_csrf

    def handle(
        self,
        method: str,
        raw_path: str,
        query_string: str,
        headers: Dict[str, str],
        raw_body: bytes,
    ) -> ApiResponse:
        upper_method = method.upper()
        path = raw_path.rstrip("/") or "/"
        params = parse_qs(query_string, keep_blank_values=False)

        # Normalize incoming headers case-insensitively
        norm_headers = {k.lower(): v for k, v in headers.items()}

        try:
            # Public/non-mutating GET routes
            if upper_method == "GET":
                return self._handle_get(path, params)

            # CSRF enforcement on state-changing routes
            if upper_method in self.MUTATING_METHODS and self.enforce_csrf:
                csrf_token = norm_headers.get("x-csrf-token")
                if not self.csrf.verify_token(csrf_token):
                    return _error_response(
                        403,
                        "Invalid or missing CSRF token. Refresh your session token via GET /api/csrf-token.",
                    )

            if upper_method == "POST":
                return self._handle_post(path, norm_headers, raw_body)
            if upper_method == "PUT":
                return self._handle_put(path, norm_headers, raw_body)
            if upper_method == "DELETE":
                return self._handle_delete(path)

            return _error_response(405, f"Method '{upper_method}' is not allowed.")

        except ValidationException as exc:
            return _error_response(422, exc.message, field_errors=exc.field_errors)
        except DuplicatePassError as exc:
            return _error_response(409, safe_error_message(exc), field_errors={"pass_id": safe_error_message(exc)})
        except PassNotFoundError as exc:
            return _error_response(404, safe_error_message(exc))
        except FileNotFoundError as exc:
            return _error_response(404, safe_error_message(exc))
        except (CorruptedStorageError, BackupVerificationError) as exc:
            return _error_response(400, safe_error_message(exc))
        except SecurityError as exc:
            return _error_response(400, safe_error_message(exc))
        except DatabaseBusyError as exc:
            return _error_response(503, safe_error_message(exc))
        except ValueError as exc:
            return _error_response(400, safe_error_message(exc))
        except Exception as exc:
            return _error_response(500, safe_error_message(exc))

    def _handle_get(self, path: str, params: Dict[str, List[str]]) -> ApiResponse:
        def q_str(key: str, default: str = "") -> str:
            vals = params.get(key)
            return vals[0] if vals else default

        def q_int(key: str, default: int) -> int:
            vals = params.get(key)
            if not vals:
                return default
            try:
                return int(vals[0])
            except ValueError as exc:
                raise ValueError(f"Query parameter '{key}' must be an integer.") from exc

        if path == "/api/health":
            integrity = self.container.db.check_integrity()
            return _json_response(
                200,
                {
                    "status": "healthy" if integrity.get("ok") else "degraded",
                    "app": self.container.config.app_name,
                    "version": self.container.config.app_version,
                    "database": integrity,
                    "total_records": self.container.pass_repo.count_all(),
                    "startup_notes": self.container.startup_notes,
                },
            )

        if path == "/api/csrf-token":
            return _json_response(200, {"csrf_token": self.csrf.generate_token()})

        if path == "/api/meta":
            return _json_response(
                200,
                {
                    "categories": list(PASS_CATEGORIES),
                    "statuses": list(PASS_STATUSES),
                    "storage_modes": list(STORAGE_FORMATS),
                    "matplotlib_available": AnalyticsService.is_matplotlib_available(),
                },
            )

        if path == "/openapi.json":
            return _json_response(200, build_openapi_spec())

        if path == "/docs":
            html = render_swagger_ui_html("/openapi.json").encode("utf-8")
            return ApiResponse(
                status_code=200,
                body=html,
                content_type="text/html; charset=utf-8",
                headers=dict(SECURITY_HEADERS),
            )

        if path == "/api/passes" or path == "/api/search":
            page = q_int("page", 1)
            raw_ps = params.get("page_size")
            page_size = q_int("page_size", 15) if raw_ps else None
            result = self.container.search_service.search_passes(
                query=q_str("q", ""),
                category=q_str("category", ""),
                status=q_str("status", ""),
                expiry_from=q_str("expiry_from", ""),
                expiry_to=q_str("expiry_to", ""),
                sort_by=q_str("sort_by", "expiry_date"),
                sort_dir=q_str("sort_dir", "asc"),
                page=page,
                page_size=page_size,
            )
            return _json_response(200, result.to_dict())

        if path.startswith("/api/passes/"):
            pass_id = unquote(path[len("/api/passes/") :])
            found = self.container.bus_pass_service.get_pass(pass_id)
            return _json_response(200, found.to_api_dict())

        if path == "/api/dashboard/summary":
            return _json_response(200, self.container.analytics_service.get_dashboard_summary())

        if path == "/api/analytics":
            return _json_response(200, self.container.analytics_service.get_full_analytics())

        if path == "/api/analytics/chart":
            chart_type = q_str("type", "status")
            png_bytes = self.container.analytics_service.generate_matplotlib_chart(chart_type=chart_type)
            if png_bytes is None:
                return _error_response(501, "Matplotlib is not installed in this Python runtime.")
            return ApiResponse(
                status_code=200,
                body=png_bytes,
                content_type="image/png",
                headers={**SECURITY_HEADERS, "Content-Disposition": f'inline; filename="chart_{chart_type}.png"'},
            )

        if path == "/api/expiry/upcoming":
            monitor = self.container.bus_pass_service.get_expiry_monitor()
            return _json_response(
                200,
                {
                    "warning_days": monitor["warning_days"],
                    "expires_today": monitor["expires_today"],
                    "expiring_soon": monitor["expiring_soon"],
                    "future": monitor["future"],
                    "counts": monitor["counts"],
                },
            )

        if path == "/api/expiry/expired":
            monitor = self.container.bus_pass_service.get_expiry_monitor()
            return _json_response(
                200,
                {
                    "count": monitor["counts"]["expired"],
                    "expired": monitor["expired"],
                },
            )

        if path == "/api/export/csv":
            filename, content = self.container.import_export_service.export_csv()
            return ApiResponse(
                status_code=200,
                body=content.encode("utf-8"),
                content_type="text/csv; charset=utf-8",
                headers={
                    **SECURITY_HEADERS,
                    "Content-Disposition": f'attachment; filename="{filename}"',
                },
            )

        if path == "/api/export/json":
            filename, content = self.container.import_export_service.export_json()
            return ApiResponse(
                status_code=200,
                body=content.encode("utf-8"),
                content_type="application/json; charset=utf-8",
                headers={
                    **SECURITY_HEADERS,
                    "Content-Disposition": f'attachment; filename="{filename}"',
                },
            )

        if path == "/api/reports/markdown":
            filename, content = self.container.report_service.generate_markdown_report()
            return ApiResponse(
                status_code=200,
                body=content.encode("utf-8"),
                content_type="text/markdown; charset=utf-8",
                headers={
                    **SECURITY_HEADERS,
                    "Content-Disposition": f'attachment; filename="{filename}"',
                },
            )

        if path == "/api/reports/audit":
            filename, content = self.container.report_service.generate_audit_log_report()
            return ApiResponse(
                status_code=200,
                body=content.encode("utf-8"),
                content_type="text/plain; charset=utf-8",
                headers={
                    **SECURITY_HEADERS,
                    "Content-Disposition": f'attachment; filename="{filename}"',
                },
            )

        if path == "/api/reports/csv":
            filename, content = self.container.report_service.generate_csv_report()
            return ApiResponse(
                status_code=200,
                body=content.encode("utf-8"),
                content_type="text/csv; charset=utf-8",
                headers={
                    **SECURITY_HEADERS,
                    "Content-Disposition": f'attachment; filename="{filename}"',
                },
            )

        if path == "/api/settings":
            return _json_response(200, self.container.bus_pass_service.get_settings().to_dict())

        if path == "/api/backups":
            return _json_response(200, {"backups": self.container.backup_service.list_backups()})

        if path == "/api/audit-logs":
            limit = q_int("limit", 50)
            entries = self.container.audit_repo.list_recent(limit=limit)
            return _json_response(200, {"logs": [e.to_dict() for e in entries]})

        return _error_response(404, f"Endpoint '{path}' not found.")

    def _parse_json_body(self, raw_body: bytes) -> Dict[str, Any]:
        if not raw_body:
            return {}
        try:
            parsed = json.loads(raw_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError(f"Malformed JSON request body: {exc}") from exc
        if not isinstance(parsed, dict):
            raise ValueError("JSON request body must be an object.")
        return parsed

    def _handle_post(self, path: str, headers: Dict[str, str], raw_body: bytes) -> ApiResponse:
        if path == "/api/passes":
            payload = self._parse_json_body(raw_body)
            created = self.container.bus_pass_service.create_pass(payload)
            return _json_response(201, created.to_api_dict())

        if path == "/api/import/csv":
            content_type = headers.get("content-type", "")
            if "multipart/form-data" in content_type:
                filename, file_bytes = _parse_multipart_file(content_type, raw_body)
                _, csv_text = validate_upload_payload(
                    filename,
                    file_bytes,
                    allowed_extensions=[".csv"],
                    max_bytes=self.container.config.max_upload_bytes,
                )
            elif "application/json" in content_type:
                body = self._parse_json_body(raw_body)
                csv_text = str(body.get("csv_text") or "")
                filename = str(body.get("filename") or "inline_upload.csv")
                validate_upload_payload(
                    filename,
                    csv_text.encode("utf-8"),
                    allowed_extensions=[".csv"],
                    max_bytes=self.container.config.max_upload_bytes,
                )
            else:
                _, csv_text = validate_upload_payload(
                    "upload.csv",
                    raw_body,
                    allowed_extensions=[".csv"],
                    max_bytes=self.container.config.max_upload_bytes,
                )

            result = self.container.import_export_service.import_csv_text(csv_text)
            return _json_response(200, result.to_dict())

        if path == "/api/import/json":
            content_type = headers.get("content-type", "")
            if "multipart/form-data" in content_type:
                filename, file_bytes = _parse_multipart_file(content_type, raw_body)
                _, json_text = validate_upload_payload(
                    filename,
                    file_bytes,
                    allowed_extensions=[".json"],
                    max_bytes=self.container.config.max_upload_bytes,
                )
            else:
                json_text = raw_body.decode("utf-8", errors="strict")
            result = self.container.import_export_service.import_json_text(json_text)
            return _json_response(200, result.to_dict())

        if path == "/api/backups":
            info = self.container.backup_service.create_backup()
            return _json_response(201, info)

        if path == "/api/backups/restore":
            payload = self._parse_json_body(raw_body)
            filename = str(payload.get("filename") or "")
            if not filename:
                raise ValueError("Backup filename is required.")
            res = self.container.backup_service.restore_backup(filename)
            return _json_response(200, res)

        if path == "/api/system/reset-sample":
            count = self.container.bus_pass_service.reset_to_sample_dataset()
            return _json_response(200, {"message": f"Reset dataset to {count} sample records.", "count": count})

        return _error_response(404, f"Endpoint '{path}' not found.")

    def _handle_put(self, path: str, headers: Dict[str, str], raw_body: bytes) -> ApiResponse:
        if path.startswith("/api/passes/"):
            pass_id = unquote(path[len("/api/passes/") :])
            payload = self._parse_json_body(raw_body)
            updated = self.container.bus_pass_service.update_pass(pass_id, payload)
            return _json_response(200, updated.to_api_dict())

        if path == "/api/settings":
            payload = self._parse_json_body(raw_body)
            updated = self.container.bus_pass_service.update_settings(payload)
            return _json_response(200, updated.to_dict())

        return _error_response(404, f"Endpoint '{path}' not found.")

    def _handle_delete(self, path: str) -> ApiResponse:
        if path.startswith("/api/passes/"):
            pass_id = unquote(path[len("/api/passes/") :])
            deleted = self.container.bus_pass_service.delete_pass(pass_id)
            return _json_response(200, {"deleted": True, "pass_id": deleted.pass_id})

        return _error_response(404, f"Endpoint '{path}' not found.")
