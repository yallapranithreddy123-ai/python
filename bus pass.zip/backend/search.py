"""Search and filtering service combining indexed SQL pagination with expiry enrichment."""

from __future__ import annotations

from datetime import date
from typing import Optional

from backend.expiry import ExpiryService
from backend.models import PaginationResult
from backend.repository import BusPassRepository, SettingsRepository


class SearchService:
    """High-level query and filter facade backed by SQLite LIMIT/OFFSET pagination."""

    def __init__(self, pass_repo: BusPassRepository, settings_repo: SettingsRepository) -> None:
        self.pass_repo = pass_repo
        self.settings_repo = settings_repo

    def search_passes(
        self,
        *,
        query: str = "",
        category: str = "",
        status: str = "",
        expiry_from: str = "",
        expiry_to: str = "",
        sort_by: str = "expiry_date",
        sort_dir: str = "asc",
        page: int = 1,
        page_size: Optional[int] = None,
        reference_date: Optional[date] = None,
    ) -> PaginationResult:
        settings = self.settings_repo.get()
        effective_page_size = page_size if page_size is not None else settings.default_page_size
        result = self.pass_repo.query_paginated(
            page=page,
            page_size=effective_page_size,
            query=query,
            category=category,
            status=status,
            expiry_from=expiry_from,
            expiry_to=expiry_to,
            sort_by=sort_by,
            sort_dir=sort_dir,
            warning_days=settings.expiry_warning_days,
            reference_date=reference_date,
        )
        ExpiryService.enrich_many(
            result.items,
            warning_days=settings.expiry_warning_days,
            reference_date=reference_date,
        )
        return result
