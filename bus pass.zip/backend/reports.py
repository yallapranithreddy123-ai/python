"""Multi-format report generation (Markdown, plain-text audit log, CSV)."""

from __future__ import annotations

import csv
import io
from datetime import datetime, timezone
from pathlib import Path
from typing import Tuple

from backend.analytics import AnalyticsService
from backend.expiry import ExpiryService
from backend.models import CSV_FIELDNAMES
from backend.repository import AuditLogRepository, BusPassRepository, SettingsRepository
from backend.storage import FilePersistenceService
from config import AppConfig


class ReportService:
    """Generates downloadable Markdown, plain-text audit, and CSV reports."""

    def __init__(
        self,
        config: AppConfig,
        pass_repo: BusPassRepository,
        settings_repo: SettingsRepository,
        audit_repo: AuditLogRepository,
        analytics_service: AnalyticsService,
    ) -> None:
        self.config = config
        self.pass_repo = pass_repo
        self.settings_repo = settings_repo
        self.audit_repo = audit_repo
        self.analytics_service = analytics_service

    def generate_markdown_report(self) -> Tuple[str, str]:
        """Build a structured Markdown executive & operational report."""
        analytics = self.analytics_service.get_full_analytics()
        settings = self.settings_repo.get()
        passes = ExpiryService.enrich_many(
            self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC"),
            warning_days=settings.expiry_warning_days,
        )
        kpis = analytics["kpis"]
        generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

        lines = [
            f"# {self.config.app_name} — Executive Summary Report",
            "",
            f"- **Generated At:** {generated_at}",
            f"- **Reference Date:** {analytics['current_date']}",
            f"- **Warning Threshold:** {settings.expiry_warning_days} days",
            f"- **Storage Mode:** `{settings.storage_sync_mode}`",
            "",
            "## Summary Statistics",
            "",
            "| Metric | Value |",
            "| --- | ---: |",
            f"| Total Registered Passes | {kpis['total_passes']} |",
            f"| Active Passes | {kpis['active_passes']} |",
            f"| Expiring Soon (1–{settings.expiry_warning_days} days) | {kpis['expiring_soon']} |",
            f"| Expires Today | {kpis['expires_today']} |",
            f"| Expired Passes | {kpis['expired_passes']} |",
            f"| Average Remaining Validity (Active) | {kpis['avg_remaining_days_active']} days |",
            f"| Total Pass Fee Revenue | {kpis['total_fee_collected']:.2f} |",
            "",
            "## Key Observations & Warnings",
            "",
        ]

        if analytics["warnings"]:
            for w in analytics["warnings"]:
                lines.append(f"- **[{w['severity'].upper()}] {w['title']}**: {w['message']}")
        else:
            lines.append("- All monitored bus passes are within normal operating thresholds.")

        lines.extend(
            [
                "",
                "## Category Distribution",
                "",
                "| Category | Total | Valid/Pending | Expired | Total Fee |",
                "| --- | ---: | ---: | ---: | ---: |",
            ]
        )
        for cat in analytics["category_distribution"]:
            lines.append(
                f"| {cat['category']} | {cat['count']} | {cat['active_or_pending']} | {cat['expired']} | {cat['total_fee']:.2f} |"
            )

        lines.extend(
            [
                "",
                "## Pass Registry Snapshot",
                "",
                "| Pass ID | Holder Name | Route | Category | Expiry Date | Days Remaining | Status |",
                "| --- | --- | --- | --- | --- | ---: | --- |",
            ]
        )
        for p in passes[:200]:
            lines.append(
                f"| {p.pass_id} | {p.holder_name} | {p.route} | {p.category} | {p.expiry_date} | {p.days_remaining} | {p.status} |"
            )
        if len(passes) > 200:
            lines.append(f"\n*Showing first 200 of {len(passes)} records. Export CSV for the complete dataset.*")

        content = "\n".join(lines) + "\n"
        filename = f"bus_pass_report_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.md"
        FilePersistenceService.atomic_write_text(self.config.exports_dir / filename, content, create_bak=False)
        return filename, content

    def generate_audit_log_report(self) -> Tuple[str, str]:
        """Build a plain-text audit trail report combining SQLite audit records and summary."""
        generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        entries = self.audit_repo.list_recent(limit=500)
        lines = [
            f"{self.config.app_name.upper()} — AUDIT TRAIL REPORT",
            f"Generated At: {generated_at}",
            f"Total Entries Returned: {len(entries)}",
            "=" * 78,
        ]
        if not entries:
            lines.append("No audit events recorded yet.")
        else:
            for entry in entries:
                lines.append(
                    f"[{entry.timestamp}] {entry.action:<16} | {entry.entity_type}:{entry.entity_id:<14} | {entry.description}"
                )

        content = "\n".join(lines) + "\n"
        filename = f"audit_report_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.txt"
        FilePersistenceService.atomic_write_text(self.config.exports_dir / filename, content, create_bak=False)
        return filename, content

    def generate_csv_report(self) -> Tuple[str, str]:
        """Generate a standardized CSV report including computed status and days remaining."""
        settings = self.settings_repo.get()
        passes = ExpiryService.enrich_many(
            self.pass_repo.list_all(order_by="expiry_date", sort_dir="ASC"),
            warning_days=settings.expiry_warning_days,
        )
        output = io.StringIO()
        headers = [*CSV_FIELDNAMES, "days_remaining", "status", "urgency"]
        writer = csv.DictWriter(output, fieldnames=headers, lineterminator="\n")
        writer.writeheader()
        for item in passes:
            row = item.to_storage_dict()
            row["days_remaining"] = item.days_remaining
            row["status"] = item.status
            row["urgency"] = item.urgency
            writer.writerow(row)

        content = output.getvalue()
        filename = f"bus_pass_report_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.csv"
        FilePersistenceService.atomic_write_text(self.config.exports_dir / filename, content, create_bak=False)
        return filename, content
