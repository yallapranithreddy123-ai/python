"""Core Python expiry calculation and status classification engine."""

from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Dict, Iterable, List, Optional

from backend.models import BusPass


class ExpiryService:
    """Pure Python datetime business logic for pass validity and expiry forecasting."""

    DATE_FORMAT = "%Y-%m-%d"

    @classmethod
    def parse_date(cls, value: str) -> date:
        """Parse an ISO YYYY-MM-DD date string into a datetime.date object."""
        return datetime.strptime(value.strip(), cls.DATE_FORMAT).date()

    @classmethod
    def calculate_days_remaining(cls, expiry_date_str: str, reference_date: Optional[date] = None) -> int:
        """Calculate signed integer days remaining until expiry_date_str."""
        today = reference_date or date.today()
        expiry_dt = cls.parse_date(expiry_date_str)
        return (expiry_dt - today).days

    @staticmethod
    def classify_status(days_remaining: int, warning_days: int = 7) -> str:
        """Determine semantic status from signed days remaining and warning threshold."""
        if days_remaining < 0:
            return "Expired"
        if days_remaining == 0:
            return "Expires Today"
        if days_remaining <= warning_days:
            return "Expiring Soon"
        return "Active"

    @staticmethod
    def calculate_urgency(days_remaining: int, warning_days: int = 7) -> str:
        """Determine actionable renewal urgency tier."""
        if days_remaining < 0:
            return "Overdue"
        if days_remaining == 0:
            return "Critical"
        if days_remaining <= max(1, warning_days // 2):
            return "High"
        if days_remaining <= warning_days:
            return "Medium"
        return "Normal"

    @classmethod
    def calculate_renewal_deadline(cls, expiry_date_str: str) -> str:
        """Return recommended renewal deadline (1 day prior to expiry or expiry date if issued same day)."""
        expiry_dt = cls.parse_date(expiry_date_str)
        recommended = expiry_dt - timedelta(days=1)
        return recommended.strftime(cls.DATE_FORMAT)

    @classmethod
    def enrich_pass(
        cls,
        bus_pass: BusPass,
        warning_days: int = 7,
        reference_date: Optional[date] = None,
    ) -> BusPass:
        """Populate computed expiry fields on a BusPass instance in-place and return it."""
        days_rem = cls.calculate_days_remaining(bus_pass.expiry_date, reference_date=reference_date)
        bus_pass.days_remaining = days_rem
        bus_pass.status = cls.classify_status(days_rem, warning_days=warning_days)
        bus_pass.urgency = cls.calculate_urgency(days_rem, warning_days=warning_days)
        bus_pass.renewal_deadline = cls.calculate_renewal_deadline(bus_pass.expiry_date)
        return bus_pass

    @classmethod
    def enrich_many(
        cls,
        passes: Iterable[BusPass],
        warning_days: int = 7,
        reference_date: Optional[date] = None,
    ) -> List[BusPass]:
        """Enrich a sequence of BusPass objects using the configured warning threshold."""
        ref = reference_date or date.today()
        return [cls.enrich_pass(p, warning_days=warning_days, reference_date=ref) for p in passes]

    @classmethod
    def partition_for_monitor(
        cls,
        passes: Iterable[BusPass],
        warning_days: int = 7,
        reference_date: Optional[date] = None,
    ) -> Dict[str, List[BusPass]]:
        """Group enriched passes into monitor buckets sorted by nearest deadline."""
        enriched = cls.enrich_many(passes, warning_days=warning_days, reference_date=reference_date)
        buckets: Dict[str, List[BusPass]] = {
            "expires_today": [],
            "expiring_soon": [],
            "expired": [],
            "future": [],
        }
        for p in enriched:
            if p.status == "Expires Today":
                buckets["expires_today"].append(p)
            elif p.status == "Expiring Soon":
                buckets["expiring_soon"].append(p)
            elif p.status == "Expired":
                buckets["expired"].append(p)
            else:
                buckets["future"].append(p)

        buckets["expiring_soon"].sort(key=lambda x: (x.days_remaining if x.days_remaining is not None else 0, x.pass_id))
        buckets["expired"].sort(key=lambda x: (x.days_remaining if x.days_remaining is not None else 0), reverse=True)
        buckets["future"].sort(key=lambda x: (x.days_remaining if x.days_remaining is not None else 0, x.pass_id))
        return buckets
