"""Security utilities: path confinement, CSRF tokens, upload checks, and safe errors."""

from __future__ import annotations

import hashlib
import hmac
import os
import re
import secrets
import time
from pathlib import Path
from typing import Dict, Iterable, Tuple


class SecurityError(ValueError):
    """Raised when a security constraint (path traversal, CSRF, file check) fails."""


ALLOWED_FILENAME_RE = re.compile(r"^[A-Za-z0-9._-]+$")

SECURITY_HEADERS: Dict[str, str] = {
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
    "Cache-Control": "no-store",
}


def ensure_confined_path(base_dir: Path | str, requested_path: Path | str) -> Path:
    """Resolve requested_path and verify it stays strictly inside base_dir.

    Prevents directory traversal attacks (e.g. '../../etc/passwd' or symlink escapes).
    """
    base = Path(base_dir).resolve()
    candidate_raw = Path(requested_path)
    if candidate_raw.is_absolute():
        resolved = candidate_raw.resolve()
    else:
        resolved = (base / candidate_raw).resolve()

    base_str = str(base)
    resolved_str = str(resolved)
    if resolved_str != base_str and not resolved_str.startswith(base_str + os.sep):
        raise SecurityError("Access denied: requested path escapes allowed directory.")
    return resolved


def sanitize_filename(filename: str, allowed_extensions: Iterable[str] | None = None) -> str:
    """Strip directory components and reject unsafe or unexpected filenames."""
    if not isinstance(filename, str) or not filename.strip():
        raise SecurityError("Filename cannot be empty.")

    # Take only the final path segment across POSIX and Windows separators
    cleaned = filename.replace("\\", "/").split("/")[-1].strip()
    if not cleaned or cleaned in {".", ".."}:
        raise SecurityError("Invalid filename.")

    cleaned = re.sub(r"[^A-Za-z0-9._-]", "_", cleaned)
    if not ALLOWED_FILENAME_RE.match(cleaned):
        raise SecurityError("Filename contains unsupported characters.")

    if allowed_extensions is not None:
        normalized_exts = {ext.lower() if ext.startswith(".") else f".{ext.lower()}" for ext in allowed_extensions}
        suffix = Path(cleaned).suffix.lower()
        if suffix not in normalized_exts:
            raise SecurityError(f"Unsupported file extension '{suffix}'. Allowed: {', '.join(sorted(normalized_exts))}")

    return cleaned


def validate_upload_payload(
    filename: str,
    raw_bytes: bytes,
    allowed_extensions: Iterable[str],
    max_bytes: int,
) -> Tuple[str, str]:
    """Validate uploaded file name, extension, byte limit, and UTF-8 decodability."""
    safe_name = sanitize_filename(filename, allowed_extensions=allowed_extensions)

    if not raw_bytes:
        raise SecurityError("Uploaded file is empty.")
    if len(raw_bytes) > max_bytes:
        max_mb = round(max_bytes / (1024 * 1024), 2)
        raise SecurityError(f"Uploaded file exceeds maximum allowed size of {max_mb} MB.")
    if b"\x00" in raw_bytes:
        raise SecurityError("Uploaded file appears to contain binary null bytes and is not valid text.")

    try:
        decoded_text = raw_bytes.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise SecurityError("Uploaded file must be UTF-8 encoded text.") from exc

    return safe_name, decoded_text


class CsrfManager:
    """Stateless HMAC-SHA256 CSRF token issuer and verifier."""

    def __init__(self, secret_key: str, ttl_seconds: int = 86400) -> None:
        self._secret_bytes = secret_key.encode("utf-8")
        self._ttl_seconds = ttl_seconds

    def generate_token(self) -> str:
        """Create a signed CSRF token with embedded timestamp and random nonce."""
        issued_at = str(int(time.time()))
        nonce = secrets.token_hex(16)
        payload = f"{issued_at}.{nonce}"
        signature = hmac.new(self._secret_bytes, payload.encode("utf-8"), hashlib.sha256).hexdigest()
        return f"{payload}.{signature}"

    def verify_token(self, token: str | None) -> bool:
        """Verify HMAC signature and expiration without leaking timing info."""
        if not token or not isinstance(token, str):
            return False
        parts = token.strip().split(".")
        if len(parts) != 3:
            return False

        issued_str, nonce, provided_sig = parts
        if not issued_str.isdigit() or not nonce or not provided_sig:
            return False

        payload = f"{issued_str}.{nonce}"
        expected_sig = hmac.new(self._secret_bytes, payload.encode("utf-8"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(provided_sig, expected_sig):
            return False

        age = int(time.time()) - int(issued_str)
        if age < -60 or age > self._ttl_seconds:
            return False
        return True


def safe_error_message(exc: Exception, fallback: str = "An unexpected server error occurred.") -> str:
    """Return user-safe error text without exposing internal filesystem paths or stack traces."""
    message = str(exc) if exc else fallback
    if "/" in message or "\\" in message:
        # Strip potential server directory paths
        message = re.sub(r"([A-Za-z]:)?([\\/][^\\/\s]+){2,}", "[restricted-path]", message)
    return message or fallback
