"""Tests for the interactive Python CLI workflows and table formatting."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from backend.services import ApplicationContainer
from cli import BusPassCLI, format_passes_table
from config import AppConfig


class TestCliWorkflows(unittest.TestCase):
    def test_cli_add_search_summary_and_exit(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = AppConfig.for_directory(Path(tmp))
            container = ApplicationContainer(cfg, seed_if_empty=False)

            # Sequence of interactive inputs:
            # 1 -> Add pass (with one intentional blank pass_id first to verify retry loop)
            # 8 -> Summary
            # 3 -> Search
            # 10 -> Exit
            scripted_inputs = iter(
                [
                    "1",
                    "",            # Intentional invalid blank pass_id
                    "BP-CLI-001",  # Valid pass_id
                    "Devansh Rao",
                    "+919876543210",
                    "Route 101 - Campus",
                    "Student",
                    "2026-11-01",
                    "2026-12-20",
                    "450",
                    "CLI test pass",
                    "8",
                    "3",
                    "Devansh",
                    "",
                    "",
                    "10",
                ]
            )
            outputs = []
            cli = BusPassCLI(
                container=container,
                input_fn=lambda _prompt: next(scripted_inputs),
                output_fn=lambda msg: outputs.append(msg),
            )
            cli.run()

            joined = "\n".join(outputs)
            self.assertIn("Invalid input:", joined)
            self.assertIn("Registered pass BP-CLI-001", joined)
            self.assertIn("Total Registered Passes : 1", joined)
            self.assertIn("Devansh Rao", joined)
            self.assertIn("Goodbye!", joined)

            # Verify record persisted to SQLite
            saved = container.bus_pass_service.get_pass("BP-CLI-001")
            self.assertEqual(saved.holder_name, "Devansh Rao")

    def test_format_passes_table_handles_empty_and_long_values(self):
        self.assertIn("No bus pass records", format_passes_table([]))


if __name__ == "__main__":
    unittest.main()
