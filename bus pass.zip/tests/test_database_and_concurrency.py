"""Integration tests for SQLite CRUD, transactions, concurrency, and 10,000-row pagination."""

from __future__ import annotations

import concurrent.futures
import tempfile
import unittest
from pathlib import Path

from backend.repository import DuplicatePassError, PassNotFoundError
from backend.seed import generate_synthetic_passes
from backend.services import ApplicationContainer
from config import AppConfig


class TestDatabaseAndConcurrency(unittest.TestCase):
    def _sample_payload(self, pass_id: str = "BP-2026-500"):
        return {
            "pass_id": pass_id,
            "holder_name": "Meera Iyer",
            "mobile_number": "+919900112233",
            "route": "Route 305 - Civic Hospital",
            "category": "Senior Citizen",
            "issue_date": "2026-11-01",
            "expiry_date": "2026-12-15",
            "fee": 250.0,
            "notes": "Verified ID",
        }

    def test_crud_and_persistence_across_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = AppConfig.for_directory(Path(tmp))
            c1 = ApplicationContainer(cfg, seed_if_empty=False)

            created = c1.bus_pass_service.create_pass(self._sample_payload("BP-2026-501"))
            self.assertEqual(created.pass_id, "BP-2026-501")

            with self.assertRaises(DuplicatePassError):
                c1.bus_pass_service.create_pass(self._sample_payload("BP-2026-501"))

            updated = c1.bus_pass_service.update_pass(
                "BP-2026-501",
                {**self._sample_payload("BP-2026-501"), "route": "Route 999 - Updated"},
            )
            self.assertEqual(updated.route, "Route 999 - Updated")

            # Simulate restart with fresh ApplicationContainer pointing at same directory
            c2 = ApplicationContainer(cfg, seed_if_empty=False)
            reloaded = c2.bus_pass_service.get_pass("BP-2026-501")
            self.assertEqual(reloaded.route, "Route 999 - Updated")

            c2.bus_pass_service.delete_pass("BP-2026-501")
            with self.assertRaises(PassNotFoundError):
                c2.bus_pass_service.get_pass("BP-2026-501")

    def test_transaction_rollback_on_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = AppConfig.for_directory(Path(tmp))
            c = ApplicationContainer(cfg, seed_if_empty=False)
            c.bus_pass_service.create_pass(self._sample_payload("BP-2026-600"))

            with self.assertRaises(RuntimeError):
                with c.db.transaction() as conn:
                    conn.execute(
                        "UPDATE bus_passes SET route = 'ShouldRollback' WHERE pass_id = 'BP-2026-600';"
                    )
                    raise RuntimeError("Simulated mid-transaction failure")

            fetched = c.bus_pass_service.get_pass("BP-2026-600")
            self.assertEqual(fetched.route, "Route 305 - Civic Hospital")

    def test_concurrent_inserts_prevent_duplicate_pass_ids(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = AppConfig.for_directory(Path(tmp))
            c = ApplicationContainer(cfg, seed_if_empty=False)

            def attempt_create(worker_idx: int):
                try:
                    c.bus_pass_service.create_pass(self._sample_payload("BP-RACE-001"))
                    return "created"
                except DuplicatePassError:
                    return "duplicate"

            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
                outcomes = list(pool.map(attempt_create, range(8)))

            self.assertEqual(outcomes.count("created"), 1)
            self.assertEqual(outcomes.count("duplicate"), 7)
            self.assertEqual(c.pass_repo.count_all(), 1)

    def test_large_dataset_10000_records_pagination_and_search(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = AppConfig.for_directory(Path(tmp))
            c = ApplicationContainer(cfg, seed_if_empty=False)

            synthetic = generate_synthetic_passes(10000)
            inserted, duplicates = c.pass_repo.bulk_insert_ignore_duplicates(synthetic)
            self.assertEqual(len(inserted), 10000)
            self.assertEqual(len(duplicates), 0)

            page1 = c.search_service.search_passes(page=1, page_size=25)
            self.assertEqual(page1.total_count, 10000)
            self.assertEqual(page1.total_pages, 400)
            self.assertEqual(len(page1.items), 25)

            filtered = c.search_service.search_passes(
                query="SYN-005000",
                category="Student",
                page=1,
                page_size=10,
            )
            self.assertLessEqual(filtered.total_count, 1)


if __name__ == "__main__":
    unittest.main()
