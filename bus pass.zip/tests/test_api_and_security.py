"""API router tests verifying HTTP status codes, CSRF enforcement, OpenAPI spec, and exports."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from backend.api_router import ApiRouter
from backend.services import ApplicationContainer
from config import AppConfig


class TestApiRouter(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.cfg = AppConfig.for_directory(Path(self._tmp.name))
        self.container = ApplicationContainer(self.cfg, seed_if_empty=True)
        self.router = ApiRouter(self.container, enforce_csrf=True)

        token_res = self.router.handle("GET", "/api/csrf-token", "", {}, b"")
        self.csrf_token = json.loads(token_res.body)["csrf_token"]

    def tearDown(self):
        self._tmp.cleanup()

    def test_health_and_openapi_docs(self):
        health = self.router.handle("GET", "/api/health", "", {}, b"")
        self.assertEqual(health.status_code, 200)
        self.assertEqual(json.loads(health.body)["total_records"], 40)

        spec_res = self.router.handle("GET", "/openapi.json", "", {}, b"")
        self.assertEqual(spec_res.status_code, 200)
        spec = json.loads(spec_res.body)
        self.assertEqual(spec["openapi"], "3.0.3")
        self.assertIn("/api/passes", spec["paths"])

        docs_res = self.router.handle("GET", "/docs", "", {}, b"")
        self.assertEqual(docs_res.status_code, 200)
        self.assertIn(b"OpenAPI 3.0.3 Reference", docs_res.body)

    def test_csrf_protection_and_crud_status_codes(self):
        payload = json.dumps(
            {
                "pass_id": "BP-API-901",
                "holder_name": "Neha Kapoor",
                "mobile_number": "+919811223344",
                "route": "Route 402 - Express",
                "category": "Express Route",
                "issue_date": "2026-11-01",
                "expiry_date": "2026-12-31",
                "fee": 1500,
                "notes": "API test",
            }
        ).encode("utf-8")

        # Missing CSRF -> 403
        blocked = self.router.handle("POST", "/api/passes", "", {"Content-Type": "application/json"}, payload)
        self.assertEqual(blocked.status_code, 403)

        # Valid CSRF -> 201 Created
        created = self.router.handle(
            "POST",
            "/api/passes",
            "",
            {"Content-Type": "application/json", "X-CSRF-Token": self.csrf_token},
            payload,
        )
        self.assertEqual(created.status_code, 201)

        # Duplicate -> 409 Conflict
        dup = self.router.handle(
            "POST",
            "/api/passes",
            "",
            {"Content-Type": "application/json", "X-CSRF-Token": self.csrf_token},
            payload,
        )
        self.assertEqual(dup.status_code, 409)

        # Invalid input -> 422
        invalid = self.router.handle(
            "POST",
            "/api/passes",
            "",
            {"Content-Type": "application/json", "X-CSRF-Token": self.csrf_token},
            b'{"pass_id": ""}',
        )
        self.assertEqual(invalid.status_code, 422)

        # GET single -> 200, missing -> 404
        fetched = self.router.handle("GET", "/api/passes/BP-API-901", "", {}, b"")
        self.assertEqual(fetched.status_code, 200)
        missing = self.router.handle("GET", "/api/passes/BP-MISSING-999", "", {}, b"")
        self.assertEqual(missing.status_code, 404)

        # PUT -> 200
        upd = self.router.handle(
            "PUT",
            "/api/passes/BP-API-901",
            "",
            {"Content-Type": "application/json", "X-CSRF-Token": self.csrf_token},
            json.dumps(
                {
                    "holder_name": "Neha Kapoor",
                    "mobile_number": "+919811223344",
                    "route": "Route 402 - Updated",
                    "category": "Express Route",
                    "issue_date": "2026-11-01",
                    "expiry_date": "2026-12-31",
                    "fee": 1550,
                    "notes": "Updated via API",
                }
            ).encode("utf-8"),
        )
        self.assertEqual(upd.status_code, 200)

        # DELETE -> 200
        deleted = self.router.handle(
            "DELETE",
            "/api/passes/BP-API-901",
            "",
            {"X-CSRF-Token": self.csrf_token},
            b"",
        )
        self.assertEqual(deleted.status_code, 200)

    def test_search_monitor_exports_and_multipart_upload(self):
        search_res = self.router.handle("GET", "/api/search", "q=Route&page=1&page_size=5", {}, b"")
        self.assertEqual(search_res.status_code, 200)
        self.assertEqual(len(json.loads(search_res.body)["items"]), 5)

        upcoming = self.router.handle("GET", "/api/expiry/upcoming", "", {}, b"")
        self.assertEqual(upcoming.status_code, 200)
        expired = self.router.handle("GET", "/api/expiry/expired", "", {}, b"")
        self.assertEqual(expired.status_code, 200)

        # Multipart CSV import
        boundary = "----TestBoundary123"
        csv_bytes = (
            "pass_id,holder_name,mobile_number,route,category,issue_date,expiry_date,fee\n"
            "BP-MP-001,Samira Khan,+919876543211,Route 12,General Commuter,2026-11-01,2026-12-25,650\n"
        ).encode("utf-8")
        multipart_body = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="file"; filename="batch.csv"\r\n'
            f"Content-Type: text/csv\r\n\r\n"
        ).encode("utf-8") + csv_bytes + f"\r\n--{boundary}--\r\n".encode("utf-8")

        imp_res = self.router.handle(
            "POST",
            "/api/import/csv",
            "",
            {
                "Content-Type": f"multipart/form-data; boundary={boundary}",
                "X-CSRF-Token": self.csrf_token,
            },
            multipart_body,
        )
        self.assertEqual(imp_res.status_code, 200)
        self.assertEqual(json.loads(imp_res.body)["imported_count"], 1)

        for export_path in (
            "/api/export/csv",
            "/api/export/json",
            "/api/reports/markdown",
            "/api/reports/audit",
            "/api/reports/csv",
        ):
            r = self.router.handle("GET", export_path, "", {}, b"")
            self.assertEqual(r.status_code, 200)
            self.assertGreater(len(r.body), 20)


if __name__ == "__main__":
    unittest.main()
