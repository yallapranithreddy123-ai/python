"""Unit and integration tests for expiry calculations, analytics, and report generation."""

from __future__ import annotations

import tempfile
import unittest
from datetime import date
from pathlib import Path

from backend.expiry import ExpiryService
from backend.models import BusPass
from backend.services import ApplicationContainer
from config import AppConfig


class TestExpiryAndAnalytics(unittest.TestCase):
    def test_expiry_boundary_classifications(self):
        ref = date(2026, 11, 24)
        cases = [
            ("2026-11-23", -1, "Expired"),
            ("2026-11-24", 0, "Expires Today"),
            ("2026-11-25", 1, "Expiring Soon"),
            ("2026-12-01", 7, "Expiring Soon"),
            ("2026-12-02", 8, "Active"),
        ]
        for exp_str, expected_days, expected_status in cases:
            days = ExpiryService.calculate_days_remaining(exp_str, reference_date=ref)
            self.assertEqual(days, expected_days)
            self.assertEqual(ExpiryService.classify_status(days, warning_days=7), expected_status)

    def test_month_year_and_leap_year_transitions(self):
        # Year rollover
        self.assertEqual(
            ExpiryService.calculate_days_remaining("2027-01-02", reference_date=date(2026, 12, 30)),
            3,
        )
        # Leap-year February to March
        self.assertEqual(
            ExpiryService.calculate_days_remaining("2024-03-01", reference_date=date(2024, 2, 28)),
            2,
        )
        # Non-leap February to March
        self.assertEqual(
            ExpiryService.calculate_days_remaining("2026-03-01", reference_date=date(2026, 2, 28)),
            1,
        )

    def test_configurable_warning_threshold(self):
        p = BusPass(
            pass_id="BP-2026-777",
            holder_name="Test User",
            mobile_number="+919876543210",
            route="Route 101",
            category="Student",
            issue_date="2026-11-01",
            expiry_date="2026-12-04",
        )
        ref = date(2026, 11, 24)  # 10 days remaining
        ExpiryService.enrich_pass(p, warning_days=7, reference_date=ref)
        self.assertEqual(p.status, "Active")

        ExpiryService.enrich_pass(p, warning_days=14, reference_date=ref)
        self.assertEqual(p.status, "Expiring Soon")

    def test_analytics_and_reports_use_real_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = AppConfig.for_directory(Path(tmp))
            container = ApplicationContainer(cfg, seed_if_empty=True)

            summary = container.analytics_service.get_full_analytics()
            self.assertEqual(summary["kpis"]["total_passes"], 40)
            self.assertEqual(
                summary["kpis"]["active_passes"]
                + summary["kpis"]["expiring_soon"]
                + summary["kpis"]["expires_today"]
                + summary["kpis"]["expired_passes"],
                40,
            )
            self.assertTrue(len(summary["category_distribution"]) >= 4)
            self.assertTrue(len(summary["monthly_expiry_trend"]) == 6)

            md_name, md_content = container.report_service.generate_markdown_report()
            self.assertTrue((cfg.exports_dir / md_name).exists())
            self.assertIn("Total Registered Passes | 40", md_content)

            txt_name, txt_content = container.report_service.generate_audit_log_report()
            self.assertTrue((cfg.exports_dir / txt_name).exists())
            self.assertIn("SEED_INITIAL", txt_content)

            csv_name, csv_content = container.report_service.generate_csv_report()
            self.assertTrue((cfg.exports_dir / csv_name).exists())
            self.assertIn("days_remaining,status,urgency", csv_content)


if __name__ == "__main__":
    unittest.main()
