"""Tests for CSV/JSON import/export, corruption recovery, and verified SQLite backups."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from backend.services import ApplicationContainer
from backend.storage import CorruptedStorageError
from config import AppConfig


class TestImportExportAndBackup(unittest.TestCase):
    def test_bulk_csv_import_logs_row_errors_and_imports_valid_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = AppConfig.for_directory(Path(tmp))
            c = ApplicationContainer(cfg, seed_if_empty=False)

            csv_payload = "\n".join(
                [
                    "pass_id,holder_name,mobile_number,route,category,issue_date,expiry_date,fee,notes",
                    "BP-IMP-001,Riya Sen,+919876543210,Route 101,Student,2026-11-01,2026-12-30,450,Valid row 1",
                    "BP-IMP-002,,9876543210,Route 102,Student,2026-11-01,2026-12-30,450,Missing name",
                    "BP-IMP-003,Karan Mehta,+919811223344,Route 204,Employee,2026-12-20,2026-12-01,1000,Inverted dates",
                    "BP-IMP-001,Duplicate User,+919800000000,Route 101,Student,2026-11-01,2026-12-30,450,Dup in CSV",
                    "BP-IMP-004,Anita Rao,+919822334455,Route 305,Senior Citizen,2026-11-01,2027-01-15,250,Valid row 2",
                ]
            )
            result = c.import_export_service.import_csv_text(csv_payload)
            self.assertEqual(result.total_rows, 5)
            self.assertEqual(result.imported_count, 2)
            self.assertEqual(result.failed_count, 3)
            self.assertEqual(result.skipped_duplicates, 1)
            self.assertEqual(c.pass_repo.count_all(), 2)

            # Export CSV & JSON round-trip
            _, exported_csv = c.import_export_service.export_csv()
            _, exported_json = c.import_export_service.export_json()
            self.assertIn("BP-IMP-001", exported_csv)
            self.assertIn("BP-IMP-004", exported_json)

    def test_corrupted_json_and_csv_quarantined_and_recovered(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = AppConfig.for_directory(Path(tmp))
            c = ApplicationContainer(cfg, seed_if_empty=True)

            # Corrupt JSON and CSV files on disk
            cfg.json_path.write_text("{corrupted json!!!", encoding="utf-8")
            cfg.csv_path.write_text("bad_col1,bad_col2\n1,2\n", encoding="utf-8")

            with self.assertRaises(CorruptedStorageError):
                c.file_service.load_json_records(cfg.json_path)

            # Restart container -> should quarantine damaged files and rebuild clean ones from SQLite
            c2 = ApplicationContainer(cfg, seed_if_empty=False)
            self.assertTrue(len(c2.startup_notes) >= 2)
            quarantined = list(cfg.data_dir.glob("*.corrupted.*"))
            self.assertEqual(len(quarantined), 2)
            loaded_json, _ = c2.file_service.load_json_records(cfg.json_path)
            self.assertEqual(len(loaded_json), 40)

    def test_backup_creation_restoration_and_corrupted_db_recovery(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = AppConfig.for_directory(Path(tmp))
            c = ApplicationContainer(cfg, seed_if_empty=False)
            c.bus_pass_service.create_pass(
                {
                    "pass_id": "BP-BAK-001",
                    "holder_name": "Backup Tester",
                    "mobile_number": "+919876543210",
                    "route": "Route 10",
                    "category": "Employee",
                    "issue_date": "2026-11-01",
                    "expiry_date": "2026-12-30",
                    "fee": 800,
                    "notes": "",
                }
            )
            backup_info = c.backup_service.create_backup()
            self.assertTrue(backup_info["verified"])

            # Mutate database after backup
            c.bus_pass_service.delete_pass("BP-BAK-001")
            self.assertEqual(c.pass_repo.count_all(), 0)

            # Restore from verified backup
            restore_res = c.backup_service.restore_backup(backup_info["filename"])
            self.assertEqual(restore_res["record_count"], 1)
            self.assertTrue(restore_res["integrity"]["ok"])
            self.assertIsNotNone(restore_res["pre_restore_backup"])
            self.assertEqual(c.pass_repo.get_by_pass_id("BP-BAK-001").holder_name, "Backup Tester")

            # Corrupt SQLite DB file directly and verify startup recovery
            cfg.db_path.write_bytes(b"NOT A VALID SQLITE FILE")
            c_recovered = ApplicationContainer(cfg, seed_if_empty=False)
            self.assertGreaterEqual(c_recovered.pass_repo.count_all(), 0)
            self.assertTrue(c_recovered.db.check_integrity()["ok"])


if __name__ == "__main__":
    unittest.main()
