"""Unit tests for centralized defensive validation and security guards."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from backend.security import CsrfManager, SecurityError, ensure_confined_path, sanitize_filename, validate_upload_payload
from backend.validation import ValidationException, ValidationService


class TestValidationService(unittest.TestCase):
    def _valid_payload(self):
        return {
            "pass_id": "bp-2026-101",
            "holder_name": "Aarav Sharma",
            "mobile_number": "+91 98765-43210",
            "route": "Route 101 - Central Station",
            "category": "student",
            "issue_date": "2026-11-01",
            "expiry_date": "2026-12-01",
            "fee": "450.50",
            "notes": "Semester pass",
        }

    def test_valid_payload_normalizes_fields(self):
        cleaned = ValidationService.validate_pass_payload(self._valid_payload())
        self.assertEqual(cleaned["pass_id"], "BP-2026-101")
        self.assertEqual(cleaned["mobile_number"], "+919876543210")
        self.assertEqual(cleaned["category"], "Student")
        self.assertEqual(cleaned["fee"], 450.5)

    def test_rejects_blank_mandatory_fields(self):
        payload = {
            "pass_id": "   ",
            "holder_name": "",
            "mobile_number": "",
            "route": "",
            "category": "",
            "issue_date": "",
            "expiry_date": "",
        }
        with self.assertRaises(ValidationException) as ctx:
            ValidationService.validate_pass_payload(payload)
        for field in ("pass_id", "holder_name", "mobile_number", "route", "category", "issue_date", "expiry_date"):
            self.assertIn(field, ctx.exception.field_errors)

    def test_rejects_invalid_dates_and_inverted_range(self):
        bad_date = self._valid_payload()
        bad_date["issue_date"] = "2026-02-30"
        with self.assertRaises(ValidationException) as ctx:
            ValidationService.validate_pass_payload(bad_date)
        self.assertIn("issue_date", ctx.exception.field_errors)

        inverted = self._valid_payload()
        inverted["issue_date"] = "2026-12-10"
        inverted["expiry_date"] = "2026-12-01"
        with self.assertRaises(ValidationException) as ctx2:
            ValidationService.validate_pass_payload(inverted)
        self.assertIn("expiry_date", ctx2.exception.field_errors)

    def test_leap_year_date_accepted_and_non_leap_rejected(self):
        leap = self._valid_payload()
        leap["issue_date"] = "2024-02-29"
        leap["expiry_date"] = "2024-03-31"
        cleaned = ValidationService.validate_pass_payload(leap)
        self.assertEqual(cleaned["issue_date"], "2024-02-29")

        non_leap = self._valid_payload()
        non_leap["issue_date"] = "2026-02-29"
        with self.assertRaises(ValidationException):
            ValidationService.validate_pass_payload(non_leap)

    def test_rejects_invalid_fee_and_mobile(self):
        bad = self._valid_payload()
        bad["fee"] = -25
        bad["mobile_number"] = "abc123"
        with self.assertRaises(ValidationException) as ctx:
            ValidationService.validate_pass_payload(bad)
        self.assertIn("fee", ctx.exception.field_errors)
        self.assertIn("mobile_number", ctx.exception.field_errors)

        bool_fee = self._valid_payload()
        bool_fee["fee"] = True
        with self.assertRaises(ValidationException):
            ValidationService.validate_pass_payload(bool_fee)

    def test_settings_validation_bounds(self):
        valid = ValidationService.validate_settings_payload(
            {"expiry_warning_days": 14, "storage_sync_mode": "sqlite+json", "default_page_size": 25}
        )
        self.assertEqual(valid["expiry_warning_days"], 14)

        with self.assertRaises(ValidationException):
            ValidationService.validate_settings_payload(
                {"expiry_warning_days": 0, "storage_sync_mode": "invalid", "default_page_size": 500}
            )


class TestSecurityUtilities(unittest.TestCase):
    def test_ensure_confined_path_blocks_traversal(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp) / "exports"
            base.mkdir()
            safe = ensure_confined_path(base, "report.csv")
            self.assertTrue(str(safe).startswith(str(base.resolve())))

            with self.assertRaises(SecurityError):
                ensure_confined_path(base, "../../etc/passwd")

            with self.assertRaises(SecurityError):
                ensure_confined_path(base, "/etc/passwd")

    def test_sanitize_filename_and_upload_validation(self):
        self.assertEqual(sanitize_filename("../../evil/test.csv", [".csv"]), "test.csv")
        with self.assertRaises(SecurityError):
            sanitize_filename("malware.exe", [".csv"])

        name, text = validate_upload_payload("passes.csv", b"pass_id,holder_name\nBP-1,Aarav", [".csv"], 1024)
        self.assertEqual(name, "passes.csv")
        self.assertIn("BP-1", text)

        with self.assertRaises(SecurityError):
            validate_upload_payload("bad.csv", b"\x00\x01binary", [".csv"], 1024)

    def test_csrf_token_lifecycle(self):
        csrf = CsrfManager("test-secret-key-for-unit-tests")
        token = csrf.generate_token()
        self.assertTrue(csrf.verify_token(token))
        self.assertFalse(csrf.verify_token(token + "tamper"))
        self.assertFalse(csrf.verify_token(""))
        self.assertFalse(csrf.verify_token(None))


if __name__ == "__main__":
    unittest.main()
