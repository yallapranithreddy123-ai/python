"""Interactive menu-driven Python CLI for Bus Pass Expiry Tracker."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Callable, List, Optional

from backend.models import PASS_CATEGORIES, BusPass
from backend.repository import DuplicatePassError, PassNotFoundError
from backend.security import ensure_confined_path
from backend.services import ApplicationContainer
from backend.validation import ValidationException, ValidationService
from config import AppConfig


def _supports_ansi() -> bool:
    return sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


class Ansi:
    USE = _supports_ansi()
    RESET = "\033[0m" if USE else ""
    BOLD = "\033[1m" if USE else ""
    CYAN = "\033[36m" if USE else ""
    GREEN = "\033[32m" if USE else ""
    YELLOW = "\033[33m" if USE else ""
    RED = "\033[31m" if USE else ""
    DIM = "\033[2m" if USE else ""


def _status_color(status: Optional[str]) -> str:
    if status == "Active":
        return Ansi.GREEN
    if status in {"Expiring Soon", "Expires Today"}:
        return Ansi.YELLOW
    if status == "Expired":
        return Ansi.RED
    return ""


def _truncate(text: str, width: int) -> str:
    if len(text) <= width:
        return text
    return text[: max(1, width - 1)] + "…"


def format_passes_table(passes: List[BusPass]) -> str:
    """Format passes into fixed-width aligned columns suitable for large datasets."""
    if not passes:
        return "  (No bus pass records match this view.)"

    header = (
        f"{'PASS ID':<14} | {'HOLDER NAME':<20} | {'CATEGORY':<17} | "
        f"{'ROUTE':<26} | {'EXPIRY':<10} | {'DAYS':>5} | {'STATUS':<13}"
    )
    sep = "-" * len(header)
    lines = [header, sep]
    for p in passes:
        days_str = str(p.days_remaining) if p.days_remaining is not None else "-"
        status_str = p.status or "-"
        col = _status_color(status_str)
        lines.append(
            f"{_truncate(p.pass_id, 14):<14} | "
            f"{_truncate(p.holder_name, 20):<20} | "
            f"{_truncate(p.category, 17):<17} | "
            f"{_truncate(p.route, 26):<26} | "
            f"{p.expiry_date:<10} | "
            f"{days_str:>5} | "
            f"{col}{status_str:<13}{Ansi.RESET}"
        )
    return "\n".join(lines)


class BusPassCLI:
    """Interactive terminal interface sharing the exact same Python services as the web app."""

    def __init__(
        self,
        container: Optional[ApplicationContainer] = None,
        input_fn: Callable[[str], str] = input,
        output_fn: Callable[[str], None] = print,
    ) -> None:
        self.container = container or ApplicationContainer(AppConfig())
        self.input = input_fn
        self.output = output_fn

    def _prompt_validated(self, label: str, validator: Callable[[str], object], default: Optional[str] = None):
        while True:
            suffix = f" [{default}]" if default is not None and default != "" else ""
            raw = self.input(f"  {label}{suffix}: ").strip()
            if not raw and default is not None:
                raw = default
            try:
                return validator(raw)
            except ValueError as exc:
                self.output(f"  {Ansi.RED}Invalid input:{Ansi.RESET} {exc}")

    def show_banner(self) -> None:
        self.output(f"\n{Ansi.BOLD}{Ansi.CYAN}============================================================{Ansi.RESET}")
        self.output(f"{Ansi.BOLD}  BUS PASS EXPIRY TRACKER — TERMINAL CONSOLE{Ansi.RESET}")
        self.output(f"  {Ansi.DIM}Never Miss Your Bus Pass Renewal | SQLite + CSV/JSON{Ansi.RESET}")
        self.output(f"{Ansi.BOLD}{Ansi.CYAN}============================================================{Ansi.RESET}")
        for note in self.container.startup_notes:
            self.output(f"  {Ansi.YELLOW}[Recovery]{Ansi.RESET} {note}")

    def show_menu(self) -> None:
        self.output(f"\n{Ansi.BOLD}Main Menu:{Ansi.RESET}")
        self.output("   1. Add a bus pass")
        self.output("   2. View all passes (paginated)")
        self.output("   3. Search for a pass")
        self.output("   4. Update a pass")
        self.output("   5. Delete a pass")
        self.output("   6. View upcoming expiries")
        self.output("   7. View expired passes")
        self.output("   8. Generate executive summary")
        self.output("   9. Import / export records & backups")
        self.output("  10. Exit")

    def handle_add(self) -> None:
        self.output(f"\n{Ansi.BOLD}-- Register New Bus Pass --{Ansi.RESET}")
        self.output(f"  Categories: {', '.join(PASS_CATEGORIES)}")
        while True:
            pass_id = self._prompt_validated("Pass ID (e.g. BP-2026-101)", ValidationService.validate_pass_id)
            holder_name = self._prompt_validated("Holder Full Name", ValidationService.validate_holder_name)
            mobile = self._prompt_validated("Mobile Number", ValidationService.validate_mobile_number)
            route = self._prompt_validated("Bus Route", ValidationService.validate_route)
            category = self._prompt_validated("Category", ValidationService.validate_category)
            issue_date = self._prompt_validated(
                "Issue Date (YYYY-MM-DD)", lambda v: ValidationService.validate_date_str(v, "Issue date")
            )
            expiry_date = self._prompt_validated(
                "Expiry Date (YYYY-MM-DD)", lambda v: ValidationService.validate_date_str(v, "Expiry date")
            )
            fee = self._prompt_validated("Pass Fee (default 0.0)", ValidationService.validate_fee, default="0")
            notes = self._prompt_validated("Notes (optional)", ValidationService.validate_notes, default="")

            try:
                created = self.container.bus_pass_service.create_pass(
                    {
                        "pass_id": pass_id,
                        "holder_name": holder_name,
                        "mobile_number": mobile,
                        "route": route,
                        "category": category,
                        "issue_date": issue_date,
                        "expiry_date": expiry_date,
                        "fee": fee,
                        "notes": notes,
                    }
                )
                self.output(
                    f"\n  {Ansi.GREEN}Success:{Ansi.RESET} Registered pass {created.pass_id} "
                    f"(Status: {created.status}, {created.days_remaining} days remaining)."
                )
                return
            except (ValidationException, DuplicatePassError) as exc:
                self.output(f"\n  {Ansi.RED}Cannot save pass:{Ansi.RESET} {exc}")
                if isinstance(exc, ValidationException):
                    for field, msg in exc.field_errors.items():
                        self.output(f"    - {field}: {msg}")
                retry = self.input("  Try again? (y/n): ").strip().lower()
                if retry != "y":
                    return

    def handle_view_all(self) -> None:
        page = 1
        page_size = 10
        while True:
            res = self.container.bus_pass_service.list_passes_paginated(page=page, page_size=page_size)
            self.output(
                f"\n{Ansi.BOLD}-- All Bus Passes (Page {res.page}/{res.total_pages}, Total: {res.total_count}) --{Ansi.RESET}"
            )
            self.output(format_passes_table(res.items))
            if res.total_pages <= 1:
                break
            nav = self.input("\n  [n] Next page, [p] Previous page, [q] Back to menu: ").strip().lower()
            if nav == "n" and page < res.total_pages:
                page += 1
            elif nav == "p" and page > 1:
                page -= 1
            else:
                break

    def handle_search(self) -> None:
        self.output(f"\n{Ansi.BOLD}-- Search Bus Passes --{Ansi.RESET}")
        query = self.input("  Keyword (Pass ID, name, mobile, or route): ").strip()
        category = self.input("  Category filter (blank for All): ").strip()
        status = self.input("  Status filter (Active / Expiring Soon / Expires Today / Expired / blank): ").strip()
        res = self.container.search_service.search_passes(
            query=query,
            category=category,
            status=status,
            page=1,
            page_size=25,
        )
        self.output(f"\n  Found {res.total_count} matching record(s):")
        self.output(format_passes_table(res.items))

    def handle_update(self) -> None:
        self.output(f"\n{Ansi.BOLD}-- Update Bus Pass --{Ansi.RESET}")
        pass_id = self.input("  Enter Pass ID to update: ").strip()
        try:
            existing = self.container.bus_pass_service.get_pass(pass_id)
        except (ValueError, PassNotFoundError) as exc:
            self.output(f"  {Ansi.RED}Error:{Ansi.RESET} {exc}")
            return

        holder_name = self._prompt_validated(
            "Holder Full Name", ValidationService.validate_holder_name, default=existing.holder_name
        )
        mobile = self._prompt_validated(
            "Mobile Number", ValidationService.validate_mobile_number, default=existing.mobile_number
        )
        route = self._prompt_validated("Bus Route", ValidationService.validate_route, default=existing.route)
        category = self._prompt_validated("Category", ValidationService.validate_category, default=existing.category)
        issue_date = self._prompt_validated(
            "Issue Date (YYYY-MM-DD)",
            lambda v: ValidationService.validate_date_str(v, "Issue date"),
            default=existing.issue_date,
        )
        expiry_date = self._prompt_validated(
            "Expiry Date (YYYY-MM-DD)",
            lambda v: ValidationService.validate_date_str(v, "Expiry date"),
            default=existing.expiry_date,
        )
        fee = self._prompt_validated("Pass Fee", ValidationService.validate_fee, default=str(existing.fee))
        notes = self._prompt_validated("Notes", ValidationService.validate_notes, default=existing.notes)

        try:
            updated = self.container.bus_pass_service.update_pass(
                existing.pass_id,
                {
                    "holder_name": holder_name,
                    "mobile_number": mobile,
                    "route": route,
                    "category": category,
                    "issue_date": issue_date,
                    "expiry_date": expiry_date,
                    "fee": fee,
                    "notes": notes,
                },
            )
            self.output(f"  {Ansi.GREEN}Updated:{Ansi.RESET} {updated.pass_id} (Status: {updated.status}).")
        except ValidationException as exc:
            self.output(f"  {Ansi.RED}Update failed:{Ansi.RESET} {exc.field_errors}")

    def handle_delete(self) -> None:
        self.output(f"\n{Ansi.BOLD}-- Delete Bus Pass --{Ansi.RESET}")
        pass_id = self.input("  Enter Pass ID to delete: ").strip()
        try:
            existing = self.container.bus_pass_service.get_pass(pass_id)
        except (ValueError, PassNotFoundError) as exc:
            self.output(f"  {Ansi.RED}Error:{Ansi.RESET} {exc}")
            return

        confirm = self.input(
            f"  Confirm deletion of {existing.pass_id} ({existing.holder_name})? [yes/no]: "
        ).strip().lower()
        if confirm == "yes":
            self.container.bus_pass_service.delete_pass(existing.pass_id)
            self.output(f"  {Ansi.GREEN}Deleted:{Ansi.RESET} Pass {existing.pass_id} removed.")
        else:
            self.output("  Deletion cancelled.")

    def handle_upcoming(self) -> None:
        monitor = self.container.bus_pass_service.get_expiry_monitor()
        self.output(
            f"\n{Ansi.BOLD}-- Upcoming Expiries (Threshold: {monitor['warning_days']} days) --{Ansi.RESET}"
        )
        combined = [
            BusPass(**{k: v for k, v in item.items() if k in BusPass.__dataclass_fields__})
            for item in (monitor["expires_today"] + monitor["expiring_soon"])
        ]
        self.output(format_passes_table(combined))

    def handle_expired(self) -> None:
        monitor = self.container.bus_pass_service.get_expiry_monitor()
        self.output(f"\n{Ansi.BOLD}-- Expired Bus Passes ({monitor['counts']['expired']}) --{Ansi.RESET}")
        expired = [
            BusPass(**{k: v for k, v in item.items() if k in BusPass.__dataclass_fields__})
            for item in monitor["expired"]
        ]
        self.output(format_passes_table(expired))

    def handle_summary(self) -> None:
        summary = self.container.analytics_service.get_full_analytics()
        kpis = summary["kpis"]
        self.output(f"\n{Ansi.BOLD}-- Executive Summary ({summary['current_date']}) --{Ansi.RESET}")
        self.output(f"  Total Registered Passes : {kpis['total_passes']}")
        self.output(f"  Active Passes           : {Ansi.GREEN}{kpis['active_passes']}{Ansi.RESET}")
        self.output(f"  Expiring Soon           : {Ansi.YELLOW}{kpis['expiring_soon']}{Ansi.RESET}")
        self.output(f"  Expires Today           : {Ansi.YELLOW}{kpis['expires_today']}{Ansi.RESET}")
        self.output(f"  Expired Passes          : {Ansi.RED}{kpis['expired_passes']}{Ansi.RESET}")
        self.output(f"  Avg Remaining (Active)  : {kpis['avg_remaining_days_active']} days")
        self.output(f"  Total Fee Revenue       : {kpis['total_fee_collected']:.2f}")
        if summary["warnings"]:
            self.output(f"\n  {Ansi.BOLD}Active Alerts:{Ansi.RESET}")
            for w in summary["warnings"]:
                self.output(f"    - [{w['severity'].upper()}] {w['title']}")

    def handle_import_export(self) -> None:
        self.output(f"\n{Ansi.BOLD}-- Import / Export & Backups --{Ansi.RESET}")
        self.output("  1. Export CSV to exports/")
        self.output("  2. Export JSON to exports/")
        self.output("  3. Generate Markdown Report to exports/")
        self.output("  4. Import CSV file from project directory")
        self.output("  5. Create verified SQLite backup")
        choice = self.input("  Choose option (1-5): ").strip()

        if choice == "1":
            fn, content = self.container.import_export_service.export_csv()
            target = self.container.config.exports_dir / fn
            self.container.file_service.atomic_write_text(target, content, create_bak=False)
            self.output(f"  {Ansi.GREEN}Exported:{Ansi.RESET} exports/{fn}")
        elif choice == "2":
            fn, content = self.container.import_export_service.export_json()
            target = self.container.config.exports_dir / fn
            self.container.file_service.atomic_write_text(target, content, create_bak=False)
            self.output(f"  {Ansi.GREEN}Exported:{Ansi.RESET} exports/{fn}")
        elif choice == "3":
            fn, _ = self.container.report_service.generate_markdown_report()
            self.output(f"  {Ansi.GREEN}Report generated:{Ansi.RESET} exports/{fn}")
        elif choice == "4":
            rel_path = self.input("  CSV path inside project directory (e.g. sample_data/sample_bus_passes.csv): ").strip()
            try:
                safe_path = ensure_confined_path(self.container.config.base_dir, rel_path)
                if not safe_path.exists():
                    self.output(f"  {Ansi.RED}Error:{Ansi.RESET} File does not exist.")
                    return
                result = self.container.import_export_service.import_csv_text(safe_path.read_text(encoding="utf-8-sig"))
                self.output(
                    f"  {Ansi.GREEN}Import complete:{Ansi.RESET} {result.imported_count} imported, "
                    f"{result.failed_count} failed, {result.skipped_duplicates} duplicates."
                )
            except Exception as exc:
                self.output(f"  {Ansi.RED}Import error:{Ansi.RESET} {exc}")
        elif choice == "5":
            info = self.container.backup_service.create_backup()
            self.output(f"  {Ansi.GREEN}Backup created:{Ansi.RESET} backups/{info['filename']} ({info['size_bytes']} bytes)")
        else:
            self.output("  Invalid selection.")

    def run(self) -> None:
        self.show_banner()
        while True:
            self.show_menu()
            choice = self.input("\n  Select option (1-10): ").strip()
            if choice == "1":
                self.handle_add()
            elif choice == "2":
                self.handle_view_all()
            elif choice == "3":
                self.handle_search()
            elif choice == "4":
                self.handle_update()
            elif choice == "5":
                self.handle_delete()
            elif choice == "6":
                self.handle_upcoming()
            elif choice == "7":
                self.handle_expired()
            elif choice == "8":
                self.handle_summary()
            elif choice == "9":
                self.handle_import_export()
            elif choice == "10":
                self.output("\n  Goodbye! Keep your bus passes up to date.\n")
                break
            else:
                self.output(f"  {Ansi.RED}Invalid option.{Ansi.RESET} Please enter a number from 1 to 10.")


if __name__ == "__main__":
    BusPassCLI().run()
